SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;
SELECT account_id,
       json_extract(data,'$.username') AS username,
       json_extract(data,'$.displayName') AS displayName,
       json_extract(data,'$.isDeveloper') AS isDeveloper,
       json_extract(data,'$.isModerator') AS isModerator,
       json_extract(data,'$.isInfluencer') AS isInfluencer,
       json_extract(data,'$.hasPlus') AS hasPlus,
       json_extract(data,'$.banned') AS banned
FROM accounts ORDER BY account_id LIMIT 50;
