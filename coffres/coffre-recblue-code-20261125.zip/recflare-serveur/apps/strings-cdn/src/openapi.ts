import { resolver } from 'hono-openapi'
import { z } from 'zod'

/**
 * OpenAPI schemas for the strings-cdn worker.
 *
 * IMPORTANT: these are DESCRIPTIVE ONLY. They are passed to `describeRoute` to generate
 * the spec and are never wired into `hono-openapi`'s `validator()`. Same rationale as the
 * other workers: a reverse-engineered protocol, lenient handlers, no runtime validation.
 *
 * Do NOT add `.meta({ id })` to these schemas — with this hono-openapi + zod v4 setup a
 * meta'd schema used in a response emits a `$ref` the framework doesn't always hoist into
 * `components.schemas`, leaving a dangling reference. Leaving meta off inlines every
 * schema, which renders correctly in any tool.
 */

/** Emit a zod schema as an `application/json` response body. */
export function json(schema: z.ZodType, description: string) {
	return { description, content: { 'application/json': { schema: resolver(schema) } } }
}

// ---- Response schemas ------------------------------------------------------

/** `GET /` — the root health check. */
export const HealthResponse = z.object({
	service: z.literal('strings-cdn'),
	status: z.literal('ok'),
})

/**
 * `GET /strings` — the whole localisation document: one map per table, each mapping a
 * string key to its display text. `version` is the document's build tag; the client may
 * cache on it.
 */
export const StringsDocumentResponse = z.object({
	version: z.string().describe('Build tag of the document; changes when any text does'),
	tables: z
		.record(z.string(), z.record(z.string(), z.string()))
		.describe('Table name (e.g. `Player.Interaction`) → key (e.g. `EMOTES`) → text'),
})

/** `GET /strings/:table` — one table out of the same document. */
export const StringsTableResponse = z.object({
	version: z.string(),
	table: z.string(),
	strings: z.record(z.string(), z.string()),
})
