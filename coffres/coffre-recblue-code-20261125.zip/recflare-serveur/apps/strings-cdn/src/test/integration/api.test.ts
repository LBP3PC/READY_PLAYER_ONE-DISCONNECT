import { SELF } from 'cloudflare:test'
import { describe, expect, it } from 'vitest'

import '../../strings-cdn.app'

import type { Env } from '../../context'

declare module 'cloudflare:test' {
	interface ProvidedEnv extends Env {}
}

const ORIGIN = 'https://example.com'

describe('strings-cdn endpoints', () => {
	it('GET / reports service status', async () => {
		const res = await SELF.fetch(`${ORIGIN}/`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ service: 'strings-cdn', status: 'ok' })
	})

	it('GET /strings serves the document once text is configured', async () => {
		// An EMPTY tables map is the one payload that must not be sent: `{"tables": {}}`
		// makes the client's loader throw on a null collection and stall the loading screen,
		// which is why the route answers 404 instead while nothing is configured. With text
		// configured it answers the document.
		const res = await SELF.fetch(`${ORIGIN}/strings`)
		expect(res.status).toBe(200)
		expect(res.headers.get('content-type')).toContain('application/json')
		expect(await res.json()).toMatchObject({
			tables: { 'Player.Interaction': { EMOTES: 'Emotes' } },
		})
	})

	it('only uses the 2023 fallback for the observed client query', async () => {
		// The 2023 client wants scope -> numeric string id -> text for scopePrefix, not the
		// version/tables envelope. Handing it the envelope stalls its boot on "Downloading
		// data" — measured on real boots twice: with `tables` empty (2026-11-11) and with
		// the tables filled in (2026-11-12). So `{}` — "no overrides", which sends it back
		// to the tables compiled into the build — stays the answer until a payload it
		// parses is verified on a boot.
		const legacy = await SELF.fetch(`${ORIGIN}/strings?locale=fr-FR&scopePrefix=client.&eTag=20230414`)
		expect(legacy.status).toBe(200)
		expect(await legacy.json()).toEqual({})
		const scoped = await SELF.fetch(`${ORIGIN}/strings?locale=fr-FR&scope=client.LoadingScreen&eTag=20230414`)
		expect(scoped.status).toBe(200)
		expect(await scoped.json()).toEqual({})
		// The client appends a fetch stamp to its build tag (`20230414@23:14:55.661`). An
		// exact-match test missed that form, and the envelope it then received did not
		// deserialise (`Deserialization returned null` in the game console).
		const stamped = await SELF.fetch(
			`${ORIGIN}/strings?locale=fr-FR&scopePrefix=client.&eTag=20230414@23:14:55.661`
		)
		expect(stamped.status).toBe(200)
		expect(await stamped.json()).toEqual({})
		const other = await SELF.fetch(`${ORIGIN}/strings?locale=fr-FR&scopePrefix=client.&eTag=20250718`)
		expect(other.status).toBe(200)
		expect(await other.json()).toMatchObject({ tables: { 'Player.Interaction': { EMOTES: 'Emotes' } } })
	})

	it('GET /strings/:table returns one table and an empty map for an unknown name', async () => {
		const known = await SELF.fetch(`${ORIGIN}/strings/Player.Interaction`)
		expect(known.status).toBe(200)
		expect(await known.json()).toEqual({
			version: expect.any(String),
			table: 'Player.Interaction',
			strings: { EMOTES: 'Emotes' },
		})

		const unknown = await SELF.fetch(`${ORIGIN}/strings/Not.A.Table`)
		expect(unknown.status).toBe(200)
		expect(await unknown.json()).toHaveProperty('strings', {})
	})

	it('an unknown path is a 404', async () => {
		const res = await SELF.fetch(`${ORIGIN}/nope`)
		expect(res.status).toBe(404)
	})

	it('GET /openapi.json documents every route', async () => {
		const res = await SELF.fetch(`${ORIGIN}/openapi.json`)
		expect(res.status).toBe(200)
		const spec = (await res.json()) as {
			openapi: string
			paths: Record<string, Record<string, { summary?: string }>>
		}
		expect(spec.openapi).toMatch(/^3\.1/)

		// The spec route hides itself.
		expect(spec.paths['/openapi.json']).toBeUndefined()

		// Drift guard: a route added without a describeRoute() block fails here rather
		// than silently shipping an incomplete spec.
		const documented = new Set(
			Object.entries(spec.paths).flatMap(([path, ops]) =>
				Object.keys(ops).map((method) => `${method.toUpperCase()} ${path}`)
			)
		)
		expect([...documented].sort()).toEqual([
			'GET /',
			'GET /strings',
			'GET /strings/{table}',
		])

		for (const ops of Object.values(spec.paths)) {
			for (const op of Object.values(ops)) expect(op.summary).toBeTruthy()
		}

		// Schemas are inlined rather than $ref'd into components (see openapi.ts).
		expect(JSON.stringify(spec).includes('"$ref"')).toBe(false)
	})
})
