/**
 * The localisation document the game client fetches on load.
 *
 * The client ships the English tables inside the build, so an empty table here costs
 * nothing: a key the game asks for and this document doesn't carry falls back to the key
 * itself (that is what the "N missing keys" lines in `Player.log` are — the unpacked
 * `Player.Interaction` table showing key names it has no text for).
 *
 * Layout: table name → key → text. Table and key names are the client's own
 * (`Player.Interaction`, `EMOTES`, …), so text added here only renders when the names
 * match exactly.
 *
 * The entries below are the keys `Player.log` reports as missing on the 2023 client:
 * `EMOTES` in `Player.Interaction`, and `Preparing` / `Getting ready` / `Downloading` in
 * `LoadingScreen`. They carry the English the game shows, so a served document fixes the
 * warning without changing what a player reads. While this map was empty, `GET /strings`
 * answered 404 and the client logged "Failed to retrieve strings" on every boot.
 */
export const TABLES: Record<string, Record<string, string>> = {
	'Player.Interaction': {
		EMOTES: 'Emotes',
	},
	LoadingScreen: {
		Preparing: 'Preparing',
		'Getting ready': 'Getting ready',
		Downloading: 'Downloading',
	},
}

/** Build tag of the document. The client caches on it, so bump it with the text. */
export const STRINGS_VERSION = '2026-11-06.1'
