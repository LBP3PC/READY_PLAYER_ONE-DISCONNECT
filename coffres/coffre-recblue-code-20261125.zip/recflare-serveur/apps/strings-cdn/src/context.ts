import type { HonoApp } from '@repo/hono-helpers'
import type { SharedHonoEnv, SharedHonoVariables } from '@repo/hono-helpers/src/types'

/**
 * No bindings: the localisation document is static content served from the bundle, so
 * there is no D1, KV, R2 or secret to declare. `SharedHonoEnv` still carries the
 * deploy-time `ENVIRONMENT` / `SENTRY_RELEASE` vars every worker gets.
 */
export type Env = SharedHonoEnv

/** Variables can be extended */
export type Variables = SharedHonoVariables

export interface App extends HonoApp {
	Bindings: Env
	Variables: Variables
}
