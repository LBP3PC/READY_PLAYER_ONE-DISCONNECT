# strings-cdn

Localisation document worker, served on the `strings-cdn` subdomain. The game client
fetches it on load and logs `Failed to retrieve strings` when the host answers with
anything but the document.

- `GET /` — service status `{ "service": "strings-cdn", "status": "ok" }`.
- `GET /strings` — the whole document:
  `{ "version": "…", "tables": { "<table>": { "<key>": "<text>" } } }`. It serves
  version `2026-11-06.1` with the two tables listed under "Where the text lives".
  Public, no auth: the client fetches it before it has a session worth trusting, and
  nothing in it is per-player. **The `404` only applies while the tables are empty** (no
  entry in `TABLES`): an empty document is not a document — `{"tables": {}}` deserialises
  to a null collection on the client, whose loader then throws `ArgumentNullException:
  Value cannot be null` on boot and leaves the loading screen stuck on "Downloading data".
  A 404 sends the client back to the tables it ships in the build, which is the honest
  answer when there is no text to serve.
- `GET /strings/:table` — one table as `{ version, table, strings }`; an unknown table is
  an empty map, not a `404` (the client treats a miss as "no overrides", not an error).
- `GET /openapi.json` — the generated spec.

## Where the text lives

`src/strings-data.ts`, version `2026-11-06.1`, two tables:

- `Player.Interaction` — `EMOTES` → "Emotes";
- `LoadingScreen` — `Preparing`, `Getting ready`, `Downloading`, each its own text.

Those are the keys the 2023 client's `Player.log` reported as missing, and each carries the
English the game already shows: serving them clears the warnings without changing what a
player reads.

The client otherwise ships its own English tables inside the build, so a key with no entry
falls back to the key name (the `N missing keys` lines in `Player.log`). Add entries only
with the exact table/key names the client uses, and bump `STRINGS_VERSION` whenever the text
changes — the client caches on that tag. `/strings` answers `404` only while `TABLES` is
empty, so the first entry flips it back to the document: only add text once its shape is
known to parse.

## Development

```sh
pnpm dev     # wrangler dev
pnpm test
pnpm deploy  # from the repo root env: needs RECFLARE_DOMAIN (see .env.example)
```
