import { NEXT_UPDATE_SENTINEL } from './storefront-pricing'

/**
 * La vitrine tourne CHAQUE JOUR.
 *
 * Ce que la rotation fait, et ce qu'elle ne fait pas :
 *   - les articles restent TOUS au catalogue, mais leur ORDRE change à chaque minuit UTC. Les
 *     cases du tableau sont câblées sur des `PurchasableItemId` fixes côté client : retirer un
 *     article ferait une case vide et un achat en 404 (voir storefront-pricing.ts). Réordonner
 *     ne casse rien, et comme le client n'affiche que les premiers rayons, ce sont d'autres
 *     articles qu'on voit chaque jour ;
 *   - `NextUpdate` porte la PROCHAINE minuit au lieu de la sentinelle « qui n'arrive jamais » :
 *     la vitrine annonce donc un vrai renouvellement, et le compteur du jeu cesse d'afficher
 *     des dizaines de milliers de jours ;
 *   - l'ordre est une fonction pure du jour civil UTC : deux requêtes du même jour voient la
 *     même vitrine, celle du lendemain en voit une autre, et aucun état n'est stocké.
 *
 * L'évènement Halloween passe APRÈS cette rotation (voir `themedCatalog`) : sa sélection et sa
 * date de fin restent celles de l'évènement tant qu'il dure.
 */

/** Un storefront tel qu'il traverse le module : deux champs, le reste passe tel quel. */
export interface RotatableStorefront {
	StoreItems: unknown[]
	NextUpdate?: string | null
}

const DAY_MS = 86_400_000

/** Le numéro du jour civil UTC — la graine de la rotation, une par jour. */
export function utcDayNumber(now: Date = new Date()): number {
	return Math.floor(now.getTime() / DAY_MS)
}

/**
 * La prochaine minuit UTC, dans la forme que le client relit sans jeter la vitrine.
 *
 * Pas de millisecondes : une chaîne ISO complète (`…T00:00:00.000Z`) fait lever au client
 * « Year, Month, and Day parameters describe an un-representable DateTime » et vide TOUTES
 * les boutiques — même contrainte que la sentinelle de storefront-pricing.ts.
 */
export function nextDailyRefresh(now: Date = new Date()): string {
	const next = new Date((utcDayNumber(now) + 1) * DAY_MS)
	return `${next.toISOString().slice(0, 19)}Z`
}

/**
 * Un générateur pseudo-aléatoire déterministe (mulberry32) : même graine, même suite. C'est ce
 * qui rend la rotation reproductible sans rien stocker.
 */
function mulberry32(seed: number): () => number {
	let a = seed >>> 0
	return () => {
		a = (a + 0x6d2b79f5) >>> 0
		let t = a
		t = Math.imul(t ^ (t >>> 15), t | 1)
		t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
		return ((t ^ (t >>> 14)) >>> 0) / 4294967296
	}
}

/**
 * Les articles du jour : les mêmes, mélangés autrement. Le mélange est un Fisher-Yates amorcé
 * par le jour UTC, donc stable du premier au dernier instant de la journée.
 */
export function rotateForDay<T>(items: readonly T[], now: Date = new Date()): T[] {
	const out = [...items]
	const random = mulberry32(utcDayNumber(now))
	for (let i = out.length - 1; i > 0; i--) {
		const j = Math.floor(random() * (i + 1))
		const swap = out[i]
		out[i] = out[j] as T
		out[j] = swap as T
	}
	return out
}

/**
 * Le storefront prêt à servir : articles du jour, et la prochaine minuit comme échéance de
 * renouvellement. Ne touche ni aux prix ni au reste : c'est `basePriceStorefront` qui règle
 * les prix, et cet ordre de passage est celui de `loadStorefront`.
 */
export function dailyStorefront<T extends RotatableStorefront>(
	storefront: T,
	now: Date = new Date()
): T {
	return {
		...storefront,
		StoreItems: rotateForDay(storefront.StoreItems, now),
		NextUpdate: nextDailyRefresh(now),
	}
}

/** La sentinelle, réexportée pour que les appelants n'aient pas deux imports. */
export { NEXT_UPDATE_SENTINEL }
