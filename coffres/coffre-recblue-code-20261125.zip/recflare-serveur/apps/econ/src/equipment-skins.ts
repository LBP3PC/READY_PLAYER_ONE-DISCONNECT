import skinTable from '../static/db/skins.json'

/**
 * Quelles skins d'équipement le client sait réellement dessiner.
 *
 * `rec-blue-skins.json` rejoue dans la boutique la liste du magasin 2025 — 284 articles — alors
 * que la table du jeu (`static/db/skins.json`, « les skins que le magasin ne listait pas ») est
 * l'ensemble des modifications que la build connaît. Une skin absente de cette table n'existe
 * pas pour le client : il écrit `Failed to find skin <guid>` à chaque tuile et n'affiche rien.
 * Douze des 284 sont dans ce cas, et ce sont exactement celles que le log remonte (2026-11-24) :
 * Candyland Paintball Burst Rifle, Creator Expo 2025 Makerpen, Jingle Bell Paintball Grenade,
 * Cryptid Camera, Graffiti Camera, Fire Thorn Paintball Burst Rifle, Dodgeball (Beachball),
 * Jumbotron Maker Pen, SUPER PUMA Maker Pen…
 *
 * Une ligne de la table est de plus TRONQUÉE — `4d70545-cdf1-4fb1-924b-613de0327faf`, le vrai
 * guid est `c4d70545-…` — donc introuvable même pour une build qui connaît la skin (elle
 * double d'ailleurs « Crossbow (Vitton) » dans le magasin). Deux formes d'id sont légitimes :
 * un GUID, ou l'id base64 court d'avant (`Dc6StLFk60u5iUTrb3_C3w`).
 *
 * Servir une de ces lignes ne donne qu'une case vide, jamais une skin : elles ne sont pas
 * ajoutées au magasin. Une build dont le catalogue les liste déjà les reçoit par lui, et notre
 * prix continue de s'y appliquer (`byGuid` lit la liste complète).
 */
const TABLE = new Set(skinTable.map((skin) => skin.ModificationGuid))

const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
const SHORT_ID = /^[A-Za-z0-9_-]{19,28}$/

/** Vrai quand le client peut résoudre `guid` : la table le liste, et son id est bien formé. */
export function clientKnowsSkin(guid: string): boolean {
	return TABLE.has(guid) && (GUID.test(guid) || SHORT_ID.test(guid))
}

/**
 * Les ids que {@link clientKnowsSkin} accepte, dans l'ordre de la table — pour un `IN` SQL.
 *
 * Un worker qui lit les skins depuis la table `catalog` n'a pas de colonne « résolvable » : il
 * doit donc exclure par id. Cette liste est `skins.json` réduite aux ids bien formés, c'est-à-dire
 * exactement ce que `clientKnowsSkin` reconnaît, pour que les deux lectures ne divergent pas.
 */
export const CLIENT_KNOWN_SKIN_GUIDS: readonly string[] = [...TABLE].filter(
	(guid) => GUID.test(guid) || SHORT_ID.test(guid)
)
