import { describe, expect, it } from 'vitest'

import { dailyStorefront, nextDailyRefresh, rotateForDay, utcDayNumber } from '../daily-storefront'

const items = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']

describe('la vitrine qui tourne tous les jours', () => {
	it("change d'ordre d'un jour à l'autre", () => {
		const day1 = rotateForDay(items, new Date('2026-11-11T10:00:00Z'))
		const day2 = rotateForDay(items, new Date('2026-11-12T10:00:00Z'))
		expect(day1).not.toEqual(day2)
	})

	it('garde le même ordre du premier au dernier instant de la journée', () => {
		const morning = rotateForDay(items, new Date('2026-11-11T00:00:01Z'))
		const evening = rotateForDay(items, new Date('2026-11-11T23:59:59Z'))
		expect(morning).toEqual(evening)
	})

	it('ne retire ni ne duplique aucun article — un article absent serait une case vide', () => {
		const out = rotateForDay(items, new Date('2026-11-11T12:00:00Z'))
		expect(out).toHaveLength(items.length)
		expect([...out].sort()).toEqual([...items].sort())
	})

	it('annonce la prochaine minuit UTC, sans millisecondes', () => {
		expect(nextDailyRefresh(new Date('2026-11-11T00:00:00Z'))).toBe('2026-11-12T00:00:00Z')
		expect(nextDailyRefresh(new Date('2026-11-11T23:59:59Z'))).toBe('2026-11-12T00:00:00Z')
	})

	it('remplace la sentinelle « jamais » par cette échéance', () => {
		const storefront = dailyStorefront(
			{ StoreItems: items, NextUpdate: '2222-02-22T22:22:00Z' },
			new Date('2026-11-11T09:00:00Z')
		)
		expect(storefront.NextUpdate).toBe('2026-11-12T00:00:00Z')
		expect(storefront.StoreItems).toHaveLength(items.length)
	})

	it('compte un jour civil par 24 heures depuis l’époque', () => {
		expect(utcDayNumber(new Date('1970-01-01T00:00:00Z'))).toBe(0)
		expect(utcDayNumber(new Date('1970-01-02T00:00:00Z'))).toBe(1)
		expect(utcDayNumber(new Date('2026-11-11T23:59:59Z'))).toBe(
			utcDayNumber(new Date('2026-11-11T00:00:00Z'))
		)
	})

	it('laisse passer les autres champs du storefront intacts', () => {
		const source = {
			StoreItems: items,
			NextUpdate: '2222-02-22T22:22:00Z',
			StorefrontType: 1,
			SubscriberDiscountPercent: 10,
			StoreItems2: 'inchangé',
		}
		const out = dailyStorefront(source, new Date('2026-11-11T09:00:00Z'))
		expect(out.StorefrontType).toBe(1)
		expect(out.SubscriberDiscountPercent).toBe(10)
		expect(out.StoreItems2).toBe('inchangé')
	})
})
