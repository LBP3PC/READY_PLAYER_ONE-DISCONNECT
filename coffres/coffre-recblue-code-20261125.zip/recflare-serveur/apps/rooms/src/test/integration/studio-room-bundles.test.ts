// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import {
	publicStudioBundleFilename,
	putUnityAsset,
	seedRoomWithSubRooms,
	STUDIO_CLOUD_BUILD_SCHEMA_DDL,
} from '@repo/domain'

import { bearer, ORIGIN, setupSchema } from './support/harness'

beforeAll(setupSchema)

// A Rec Room Studio build is a unity asset on the save: `unity_asset` rows the studio
// worker wrote. The game loads the scene from `CurrentSave.DataBlob` and the bundles from
// `UnitySubAssets`. Maker-pen saves stay empty arrays, and a missing studio cloud-build
// table must not fail the room read.
describe('studio room bundles', () => {
	const ASSET = 'aa111111-2222-4333-8444-555555555555'
	const winName = publicStudioBundleFilename(9901, ASSET, 'windows', 'main')
	const androidName = publicStudioBundleFilename(9901, ASSET, 'android', 'main')
	const winHash = '47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU='
	const androidHash = 'ypeBEsobvcr6wjGzmiPcTaeG7/gUfE5yuYB3ha/uSLs='

	const save = (unityAssetId?: string) => ({
		UnitySubAssets: [],
		ReferencedUnityAssets: [],
		DataBlob: 'studio-scene-blob',
		DataBlobHash: null,
		ReferencedUnityAssetIds: [],
		PersistenceVersion: 1,
		OMVersion: 0,
		UgcSubVersion: 0,
		SavedByAccountId: 7,
		SavedOnPlatform: 0,
		SavedOnDeviceClass: 0,
		Description: '',
		Tags: [],
		ModerationState: 0,
		CreatedAt: '2026-10-03T00:00:00.000Z',
		...(unityAssetId
			? {
					UnityAssetId: unityAssetId,
					StudioSourceAsset: { Filename: 'source-manifest.json', Hash: 'source-hash' },
				}
			: {}),
	})

	async function reset() {
		await env.DB.prepare('DROP TABLE IF EXISTS studio_cloud_build').run()
		await env.DB.prepare('DELETE FROM unity_asset WHERE unity_asset_id = ?1').bind(ASSET).run()
		await env.DB.prepare('DELETE FROM subroom_save WHERE sub_room_id IN (99011, 99021)').run()
		await env.DB.prepare('DELETE FROM subroom WHERE room_id IN (9901, 9902)').run()
		await env.DB.prepare('DELETE FROM room WHERE room_id IN (9901, 9902)').run()
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 9901,
			Name: 'StudioLoadRoom',
			CreatorAccountId: 1,
			Accessibility: 1,
			IsDorm: false,
			SubRooms: [
				{
					SubRoomId: 99011,
					Name: 'Main',
					UnitySceneId: '76d98498-60a1-430c-ab76-b54a29b7a163',
					MaxPlayers: 20,
					Accessibility: 1,
					CurrentSave: save(ASSET),
				},
			],
		})
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 9902,
			Name: 'MakerPenRoom',
			CreatorAccountId: 1,
			Accessibility: 1,
			IsDorm: false,
			SubRooms: [
				{
					SubRoomId: 99021,
					Name: 'Sandbox',
					UnitySceneId: '76d98498-60a1-430c-ab76-b54a29b7a163',
					MaxPlayers: 20,
					Accessibility: 1,
					CurrentSave: save(),
				},
			],
		})
	}

	async function storeFiles() {
		for (const sql of STUDIO_CLOUD_BUILD_SCHEMA_DDL) await env.DB.prepare(sql).run()
		await env.DB.prepare(
			`INSERT INTO studio_cloud_build
				 (cloud_build_id, room_id, sub_room_id, sub_room_data_save_id, unity_asset_id,
				  created_by_account_id, started_at, completed_at, error)
				 VALUES ('build-1', 9901, 99011, 0, ?1, 42, '2026-10-03T00:00:00.000Z',
				         '2026-10-03T00:00:00.000Z', NULL)`
		)
			.bind(ASSET)
			.run()
		const insert = (target: number, kind: 'main' | 'stripped', filename: string, hash: string) =>
			putUnityAsset(
				env.DB,
				{ UnityAssetId: ASSET, Target: target, Version: 1, Filename: filename, Hash: hash },
				kind
			)
		await insert(0, 'main', winName, winHash)
		await insert(2, 'main', androidName, androidHash)
		await insert(
			0,
			'stripped',
			publicStudioBundleFilename(9901, ASSET, 'windows', 'stripped'),
			winHash
		)
	}

	it('serves partitioned prefab and shared-material exports as save dependencies', async () => {
		await reset()
		await storeFiles()
		const prefab = '00111111-2222-4333-8444-555555555555'
		const shared = '00222222-2222-4333-8444-555555555555'
		await env.DB.prepare(
			"UPDATE subroom_save SET data=json_set(data,'$.ServerData',json(?1)) WHERE sub_room_id=99011"
		)
			.bind(
				JSON.stringify({
					Exports: [
						{ e: 'prefab', u: prefab.toUpperCase() },
						{ e: 'shared', u: shared },
						{ e: 'duplicate', u: prefab },
					],
				})
			)
			.run()
		for (const id of [prefab, shared]) {
			for (const target of [0, 2]) {
				for (const kind of ['main', 'stripped'] as const) {
					await putUnityAsset(
						env.DB,
						{
							UnityAssetId: id,
							Target: target,
							Version: 5,
							Filename: publicStudioBundleFilename(
								9901,
								id,
								target === 0 ? 'windows' : 'android',
								kind
							),
							Hash: winHash,
						},
						kind
					)
				}
			}
		}
		for (const target of [0, 2]) {
			const response = await SELF.fetch(`${ORIGIN}/rooms/9901?unityAssetTarget=${target}`, {
				headers: await bearer('1', ['developer']),
			})
			const room = (await response.json()) as {
				SubRooms: Array<{
					CurrentSave: {
						SubRoomDataSaveId: number
						UnitySubAssets: Array<{ UnityAssetId: string; Target: number }>
					}
				}>
			}
			const current = room.SubRooms[0]!.CurrentSave
			expect(current.UnitySubAssets.map((asset) => asset.UnityAssetId).sort()).toEqual(
				[ASSET, prefab, shared].sort()
			)
			expect(current.UnitySubAssets.every((asset) => asset.Target === target)).toBe(true)
			const detailResponse = await SELF.fetch(
				`${ORIGIN}/rooms/9901/subrooms/99011/saves/${current.SubRoomDataSaveId}?unityAssetTarget=${target}`,
				{ headers: await bearer('1') }
			)
			expect(await detailResponse.json()).toMatchObject({
				UnityAsset: target === 0 ? winName : androidName,
				UnitySubAssets: [prefab, shared].map((id) => ({
					UnityAssetId: id,
					UnityAsset: publicStudioBundleFilename(
						9901,
						id,
						target === 0 ? 'windows' : 'android',
						'main'
					),
					UnityAssetHash: winHash,
				})),
			})
		}
		// In-game saves reuse the compiled Studio asset. They must keep the export
		// manifest when staging, saving again, and publishing the new scene data.
		for (const autoPublish of [false, false, true]) {
			const response = await SELF.fetch(`${ORIGIN}/rooms/9901/subrooms/99011/data`, {
				method: 'POST',
				headers: { ...(await bearer('1')), 'Content-Type': 'application/json' },
				body: JSON.stringify({
					UnityAssetId: ASSET.toUpperCase(),
					SubRoomData: { Filename: 'in-game-save' },
					AutoPublish: autoPublish,
				}),
			})
			const result = (await response.json()) as {
				success: boolean
				value: { subRoomDataSave: { subRoomDataSaveId: number; unityAsset: string } }
			}
			expect(result.success).toBe(true)
			expect(result.value.subRoomDataSave.unityAsset).toBe(winName)
			const detail = await SELF.fetch(
				`${ORIGIN}/rooms/9901/subrooms/99011/saves/${result.value.subRoomDataSave.subRoomDataSaveId}?unityAssetTarget=0`,
				{ headers: await bearer('1') }
			)
			expect(await detail.json()).toMatchObject({
				UnityAsset: winName,
				UnitySubAssets: [prefab, shared].map((UnityAssetId) => ({ UnityAssetId })),
			})
		}
		await env.DB.prepare('DELETE FROM unity_asset WHERE unity_asset_id IN (?1,?2)')
			.bind(prefab, shared)
			.run()
	})

	it('loads baked bundles onto the room and serves the unity asset', async () => {
		await reset()

		const before = (await (
			await SELF.fetch(`${ORIGIN}/rooms/9901`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			SubRooms: Array<{ CurrentSave: { UnitySubAssets: unknown[] } }>
		}
		expect(before.SubRooms[0]!.CurrentSave.UnitySubAssets).toEqual([])

		await storeFiles()

		type Baked = { Target: number; Filename: string; Hash: string; Version: number }
		const loaded = (await (
			await SELF.fetch(`${ORIGIN}/rooms/9901`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			SubRooms: Array<{
				CurrentSave: {
					UnitySubAssets: Baked[]
					ReferencedUnityAssets: unknown[]
					SubRoomDataSaveId: number
				}
			}>
		}
		const current = loaded.SubRooms[0]!.CurrentSave
		expect(current.ReferencedUnityAssets).toEqual([])
		expect(current.UnitySubAssets).toEqual([
			{
				UnityAssetId: ASSET,
				Target: 0,
				Version: 1,
				Filename: winName,
				Hash: winHash,
			},
			{
				UnityAssetId: ASSET,
				Target: 2,
				Version: 1,
				Filename: androidName,
				Hash: androidHash,
			},
		])

		const quest = (await (
			await SELF.fetch(`${ORIGIN}/rooms/9901?unityAssetTarget=2`, {
				headers: await bearer('1', ['developer']),
			})
		).json()) as typeof loaded
		expect(quest.SubRooms[0]!.CurrentSave.UnitySubAssets.map((asset) => asset.Target)).toEqual([2])

		const pc = (await (
			await SELF.fetch(`${ORIGIN}/rooms/9901?unityAssetTarget=0`, {
				headers: await bearer('1', ['developer']),
			})
		).json()) as typeof loaded
		expect(pc.SubRooms[0]!.CurrentSave.UnitySubAssets.map((asset) => asset.Filename)).toEqual([
			winName,
		])

		const maker = (await (
			await SELF.fetch(`${ORIGIN}/rooms/9902`, { headers: await bearer('1', ['developer']) })
		).json()) as typeof loaded
		expect(maker.SubRooms[0]!.CurrentSave.UnitySubAssets).toEqual([])

		const meta = await SELF.fetch(
			`${ORIGIN}/rooms/9901/subrooms/99011/unityasset?unityAssetId=${ASSET}`
		)
		expect(meta.status).toBe(200)
		expect(await meta.json()).toEqual({
			unityAssetId: ASSET,
			createdByAccountId: 42,
			bakedUnityAssets: [
				{ unityAssetId: ASSET, target: 0, version: 1, filename: winName },
				{ unityAssetId: ASSET, target: 2, version: 1, filename: androidName },
			],
			filename: 'source-manifest.json',
			hash: 'source-hash',
		})
		expect((await SELF.fetch(`${ORIGIN}/rooms/9901/subrooms/99011/unityasset`)).status).toBe(200)
		expect(
			(
				await SELF.fetch(
					`${ORIGIN}/rooms/9901/subrooms/99011/unityasset?unityAssetId=00000000-0000-4000-8000-000000000000`,
					{ headers: await bearer('1') }
				)
			).status
		).toBe(404)
		expect(
			(
				await SELF.fetch(`${ORIGIN}/rooms/9902/subrooms/99021/unityasset?unityAssetId=${ASSET}`, {
					headers: await bearer('1'),
				})
			).status
		).toBe(404)

		const detail = await SELF.fetch(
			`${ORIGIN}/rooms/9901/subrooms/99011/saves/${current.SubRoomDataSaveId}`,
			{ headers: await bearer('1') }
		)
		expect(detail.status).toBe(200)
		// The detail lifts the Windows bundle to the top level when no target is named, and
		// lists only dependencies in UnitySubAssets. Repeating the root there makes the
		// game load it twice and Unity rejects the second load with room error 8714.
		expect(await detail.json()).toMatchObject({
			UnityAsset: winName,
			UnityAssetHash: winHash,
			UnitySubAssets: [],
		})

		const questDetail = await SELF.fetch(
			`${ORIGIN}/rooms/9901/subrooms/99011/saves/${current.SubRoomDataSaveId}?unityAssetTarget=2`,
			{ headers: await bearer('1') }
		)
		expect(await questDetail.json()).toMatchObject({
			UnityAsset: androidName,
			UnityAssetHash: androidHash,
			UnitySubAssets: [],
		})

		const light = await SELF.fetch(`${ORIGIN}/rooms/9901/subrooms/99011/saves/no_unity_assets`, {
			headers: await bearer('1'),
		})
		const page = (await light.json()) as { Results: Array<Record<string, unknown>> }
		expect(page.Results[0]).not.toHaveProperty('UnitySubAssets')
		expect(page.Results[0]).not.toHaveProperty('ReferencedUnityAssets')

		const makerDetailId = maker.SubRooms[0]!.CurrentSave.SubRoomDataSaveId
		const makerDetail = await SELF.fetch(
			`${ORIGIN}/rooms/9902/subrooms/99021/saves/${makerDetailId}`,
			{ headers: await bearer('1') }
		)
		expect(await makerDetail.json()).toMatchObject({
			UnityAsset: null,
			UnityAssetHash: null,
			UnitySubAssets: [],
		})
	})

	it('never loads the main bundle again as a dependency, including mixed-case GUIDs', async () => {
		await reset()
		await storeFiles()
		await env.DB.prepare(
			"UPDATE subroom_save SET data=json_set(data, '$.UnityAssetId', ?1) WHERE sub_room_id=99011"
		)
			.bind(ASSET.toUpperCase())
			.run()
		const row = await env.DB.prepare(
			'SELECT current_save_id FROM subroom WHERE sub_room_id=99011'
		).first<{ current_save_id: number }>()
		for (const [query, filename] of [
			['', winName],
			['?unityAssetTarget=0', winName],
			['?unityAssetTarget=2', androidName],
			['?unityAssetTarget=1', null],
		] as const) {
			const response = await SELF.fetch(
				`${ORIGIN}/rooms/9901/subrooms/99011/saves/${row!.current_save_id}${query}`,
				{ headers: await bearer('1') }
			)
			expect(response.status).toBe(200)
			expect(await response.json()).toMatchObject({
				UnityAsset: filename,
				UnitySubAssets: [],
			})
		}
	})

	// A FIRST-PARTY room's bundle — captured from the official game and loaded by hand
	// under its `unity/<roomId>/` layout — shares `unity_asset` with Studio builds but is
	// not UGC, and must not be folded onto the save: the 2025 client handed it inline
	// takes it instead of asking the bulk lookup, cannot name it, and loads nothing (every
	// imported room broke when the splice moved from the Studio-only table to `unity_asset`).
	// The bulk lookup is where that client resolves it, and still serves it.
	it('leaves a first-party bundle to the bulk lookup rather than the room read', async () => {
		await reset()
		const firstParty = 'unity/9901/8iaf2yemao2d1zurblo875cn2.assetbundle'
		await putUnityAsset(env.DB, {
			UnityAssetId: ASSET,
			Target: 0,
			Version: 3,
			Filename: firstParty,
			Hash: winHash,
		})

		type Loaded = {
			SubRooms: Array<{ CurrentSave: { UnitySubAssets: unknown[]; SubRoomDataSaveId: number } }>
		}
		for (const query of ['', '?unityAssetTarget=0']) {
			const room = (await (await SELF.fetch(`${ORIGIN}/rooms/9901${query}`)).json()) as Loaded
			expect(room.SubRooms[0]!.CurrentSave.UnitySubAssets, query).toEqual([])
		}

		const saveId = (
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/9901`, { headers: await bearer('1', ['developer']) })
			).json()) as Loaded
		).SubRooms[0]!.CurrentSave.SubRoomDataSaveId
		const detail = await SELF.fetch(`${ORIGIN}/rooms/9901/subrooms/99011/saves/${saveId}`, {
			headers: await bearer('1'),
		})
		expect(await detail.json()).toMatchObject({
			UnityAsset: null,
			UnityAssetHash: null,
			UnitySubAssets: [],
		})

		const bulk = await SELF.fetch(`${ORIGIN}/unity_assets/baked/bulk`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams({ target: '0', version: '3', id: ASSET }).toString(),
		})
		expect(bulk.status).toBe(200)
		expect(await bulk.json()).toEqual([
			{ UnityAssetId: ASSET, Target: 0, Version: 3, Filename: firstParty, Hash: winHash },
		])
	})
})
