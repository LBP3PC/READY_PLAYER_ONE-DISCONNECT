// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { recordRoomVisit, seedRoomWithSubRooms } from '@repo/domain'

import { bearer, ORIGIN, setupSchema } from './support/harness'

beforeAll(setupSchema)

describe('rooms endpoints', () => {
	it('GET /rooms/:roomId/experience serves the room’s stored XP settings, no auth', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/2/experience`)
		expect(res.status).toBe(200)
		// A bare two-key object — no `{ success, error, value }` envelope around it. A room
		// nobody has configured is off with a 0 cap.
		expect(await res.json()).toEqual({ Enabled: false, DailyLimit: 0 })

		// A room that doesn't exist is a 404, and the id is digits-only like the other
		// room-scoped routes.
		expect((await SELF.fetch(`${ORIGIN}/rooms/99999/experience`)).status).toBe(404)
		expect((await SELF.fetch(`${ORIGIN}/rooms/abc/experience`)).status).toBe(404)
	})

	it('GET /rooms/ownedby/:id returns an account public rooms (no auth)', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/ownedby/1`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as Array<{
			RoomId: number
			Accessibility: number
			IsDorm?: boolean
			CreatorAccountId: number
		}>
		expect(body.length).toBeGreaterThan(0)
		// Only public, non-dorm rooms owned by account 1 — the private dorm (RoomId 1)
		// is excluded.
		expect(
			body.every((r) => r.Accessibility === 1 && r.IsDorm !== true && r.CreatorAccountId === 1)
		).toBe(true)
		expect(body.some((r) => r.RoomId === 1)).toBe(false)

		// An account that owns no public rooms → empty array.
		expect(await (await SELF.fetch(`${ORIGIN}/rooms/ownedby/999`)).json()).toEqual([])
	})

	it('GET /rooms/search returns a paginated { Results, TotalResults }', async () => {
		// Name-term search resolves a known public room.
		const res = await SELF.fetch(`${ORIGIN}/rooms/search?query=reccenter&skip=0&take=100`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as { Results: Array<{ Name: string }>; TotalResults: number }
		expect(body.TotalResults).toBeGreaterThanOrEqual(1)
		expect(body.Results.some((r) => r.Name === 'RecCenter')).toBe(true)
	})

	it('GET /rooms/search/name prefix-matches searchable rooms A–Z through the partial index', async () => {
		const search = async (query: string, extra = '') =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/search/name?query=${encodeURIComponent(query)}${extra}`)
			).json()) as Array<{ Name: string; IsDorm?: boolean; Stats: { VisitCount: number } }>

		// A bare array of whole rooms, case-insensitive, every name starting with the query, A–Z.
		const rec = await search('REC', '&take=10')
		expect(rec.some((r) => r.Name === 'RecCenter')).toBe(true)
		for (const r of rec) expect(r.Name.toLowerCase().startsWith('rec')).toBe(true)
		const names = rec.map((r) => r.Name.toLowerCase())
		expect(names).toEqual([...names].sort())
		expect(typeof rec[0]?.Stats.VisitCount).toBe('number')

		// A prefix, not a substring: "center" is inside RecCenter but doesn't start it.
		expect((await search('center')).some((r) => r.Name === 'RecCenter')).toBe(false)
		// `take` caps it, and is itself capped at 10; empty and wildcard queries find nothing.
		expect((await search('r', '&take=2')).length).toBeLessThanOrEqual(2)
		expect(await search('', '&take=500')).toEqual([])
		expect(await search('%')).toEqual([])
		expect((await search('r', '&take=500')).length).toBeLessThanOrEqual(10)
		// Dorms (named `@user's Dorm`) are never served.
		expect((await search('@')).every((r) => r.IsDorm !== true)).toBe(true)

		// The point of the endpoint: a SEEK on the partial index, so D1 reads only the rows it
		// returns. Fall back to a scan (or the unfiltered name index) and every call is billed
		// for every room again.
		const plan = await env.DB.prepare(
			`EXPLAIN QUERY PLAN SELECT data FROM room
			 WHERE is_dorm IS NOT 1 AND accessibility = 1 AND exclude_from_search IS NOT 1
			   AND name_lower >= ?1 AND name_lower < ?2 AND name_lower LIKE ?3 ESCAPE '\\'
			 ORDER BY name_lower LIMIT 5`
		)
			.bind('r', 'r\u{10FFFF}', 'r%')
			.all<{ detail: string }>()
		const detail = plan.results.map((r) => r.detail).join('\n')
		expect(detail).toContain('SEARCH room USING INDEX idx_room_search_name')
		expect(detail).not.toContain('TEMP B-TREE')
	})

	it('GET /rooms/autocomplete_search suggests names and tags as plain strings', async () => {
		const suggest = async (query: string, extra = '') =>
			(await (
				await SELF.fetch(
					`${ORIGIN}/rooms/autocomplete_search?query=${encodeURIComponent(query)}${extra}`
				)
			).json()) as string[]

		// A bare array of STRINGS — not rooms, not an envelope.
		const rec = await suggest('rec', '&take=4&searchSessionId=abc-123')
		expect(Array.isArray(rec)).toBe(true)
		for (const s of rec) expect(typeof s).toBe('string')
		expect(rec).toContain('RecCenter')
		expect(rec.length).toBeLessThanOrEqual(4)

		// Every suggestion finds something when submitted — the point of the endpoint.
		for (const term of rec) {
			const found = (await (
				await SELF.fetch(`${ORIGIN}/rooms/search?query=${encodeURIComponent(term)}`)
			).json()) as { TotalResults: number }
			expect(found.TotalResults, `"${term}" must find rooms`).toBeGreaterThan(0)
		}

		// Tags are suggested with their `#`, and a `#` query suggests tags only.
		const tags = await suggest('#rro')
		expect(tags).toEqual(['#rro'])
		expect(tags.every((t) => t.startsWith('#'))).toBe(true)

		// `take` caps the list; an empty query suggests nothing rather than everything.
		expect((await suggest('e', '&take=2')).length).toBeLessThanOrEqual(2)
		expect(await suggest('')).toEqual([])
		expect(await suggest('zzzznothingmatchesthis')).toEqual([])

		// Deterministic: the same query suggests the same things in the same order.
		expect(await suggest('rec')).toEqual(rec)

		// Dorms are excluded, exactly as they are from search.
		expect(await suggest('dormroom')).toEqual([])
	})

	it('GET /rooms/search excludes dorms and respects pagination shape', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/search?query=dormroom`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as { Results: unknown[]; TotalResults: number }
		// The dorm is non-public/dorm, so a name search for it returns nothing.
		expect(body).toEqual({ Results: [], TotalResults: 0 })
	})

	it('GET /rooms/search?query=#tag returns 200 (tag search)', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/search?query=%23Quest+%23recroomoriginal`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as { Results: unknown[]; TotalResults: number }
		expect(Array.isArray(body.Results)).toBe(true)
		expect(typeof body.TotalResults).toBe('number')
	})

	it('GET /rooms/search aliases #recroomoriginal to the rro tag', async () => {
		// Rooms are tagged `rro`, not `recroomoriginal` — the alias bridges them.
		const aliased = (await (
			await SELF.fetch(`${ORIGIN}/rooms/search?query=%23recroomoriginal`)
		).json()) as { TotalResults: number }
		const direct = (await (await SELF.fetch(`${ORIGIN}/rooms/search?query=%23rro`)).json()) as {
			TotalResults: number
		}
		expect(aliased.TotalResults).toBe(direct.TotalResults)
		expect(aliased.TotalResults).toBeGreaterThan(0)
	})

	it('GET /rooms/search?query=#community serves rooms the Coach account did not create', async () => {
		// The browse chip's word reaches search as a tag term, but no room CARRIES a
		// `community` tag — it is the same pseudo-tag `/rooms/hot?tag=community` applies, so it
		// filters on who MADE the room. Every seeded room belongs to Coach (account 1), so it
		// finds nothing until another account makes something.
		type Page = { Results: Array<{ Name: string }>; TotalResults: number }
		const search = async (query: string): Promise<Page> =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/search?query=${encodeURIComponent(query)}&take=100`)
			).json()) as Page

		expect(await search('#community')).toEqual({ Results: [], TotalResults: 0 })

		const seeded: number[] = []
		const seed = async (room: Record<string, unknown>) => {
			seeded.push(Number(room.RoomId))
			await seedRoomWithSubRooms(env.DB, {
				Accessibility: 1,
				IsDorm: false,
				CreatorAccountId: 2,
				...room,
			})
		}

		await seed({ RoomId: 9201, Name: 'CommunityHorrorHouse' })
		await seed({ RoomId: 9202, Name: 'CommunityArcade' })
		// Coach's own rooms stay out, and so do non-public ones as everywhere else in search.
		await seed({ RoomId: 9203, Name: 'CommunityCoachRoom', CreatorAccountId: 1 })
		await seed({ RoomId: 9204, Name: 'CommunityUnlisted', Accessibility: 2 })

		const found = await search('#community')
		expect(found.Results.map((r) => r.Name)).toEqual(['CommunityHorrorHouse', 'CommunityArcade'])
		expect(found.TotalResults).toBe(2)

		// The client sends the chip with a trailing space (`?query=%23community+`), which the
		// term split has to swallow rather than search for an empty second term.
		expect(await search('#community ')).toEqual(found)

		// It NARROWS the rest of the query rather than replacing it: a name term still applies,
		// and so does a real tag, which is still the SQL lookup it always was.
		expect((await search('#community arcade')).Results.map((r) => r.Name)).toEqual([
			'CommunityArcade',
		])
		expect(await search('#community #rro')).toEqual({ Results: [], TotalResults: 0 })

		// Leave the shared dataset as it was for the tests that follow.
		const ids = seeded.join(',')
		await env.DB.prepare(`DELETE FROM room WHERE room_id IN (${ids})`).run()
		await env.DB.prepare(`DELETE FROM subroom WHERE room_id IN (${ids})`).run()
	})

	it('GET /rooms/favoritedby/me returns a bare array of the caller favorited rooms (auth-scoped)', async () => {
		const headers = await bearer('777')

		// Auth-gated — no token is a 401, never account 1's favorites.
		expect((await SELF.fetch(`${ORIGIN}/rooms/favoritedby/me`)).status).toBe(401)

		// No favorites yet → empty array.
		const empty = (await (
			await SELF.fetch(`${ORIGIN}/rooms/favoritedby/me`, { headers })
		).json()) as unknown[]
		expect(empty).toEqual([])

		// Favorite two real rooms, then they come back.
		for (const id of [2, 12]) {
			await SELF.fetch(`${ORIGIN}/rooms/${id}/interactionby/me/favorite`, {
				method: 'PUT',
				headers,
			})
		}
		const body = (await (
			await SELF.fetch(`${ORIGIN}/rooms/favoritedby/me?skip=0&take=100`, { headers })
		).json()) as Array<{ RoomId: number }>
		expect(body.map((r) => r.RoomId).sort((a, b) => a - b)).toEqual([2, 12])

		// Un-favoriting one drops it from the list.
		await SELF.fetch(`${ORIGIN}/rooms/2/interactionby/me/favorite`, { method: 'PUT', headers })
		const afterUnfav = (await (
			await SELF.fetch(`${ORIGIN}/rooms/favoritedby/me`, { headers })
		).json()) as Array<{ RoomId: number }>
		expect(afterUnfav.map((r) => r.RoomId)).toEqual([12])

		// Scoped per player — a different account sees none.
		const other = (await (
			await SELF.fetch(`${ORIGIN}/rooms/favoritedby/me`, { headers: await bearer('778') })
		).json()) as unknown[]
		expect(other).toEqual([])
	})

	it('GET /rooms/visitedby/me returns a bare array of rooms the caller has visited (auth-scoped)', async () => {
		const headers = await bearer('779')

		// No visits yet → empty array.
		const empty = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/me`, { headers })
		).json()) as unknown[]
		expect(empty).toEqual([])

		// Cheering/favoriting is not a visit — only `match` entering the room stamps one.
		await SELF.fetch(`${ORIGIN}/rooms/2/interactionby/me/cheer`, { method: 'PUT', headers })
		await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/favorite`, { method: 'PUT', headers })
		const afterToggles = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/me`, { headers })
		).json()) as unknown[]
		expect(afterToggles).toEqual([])

		await recordRoomVisit(env.DB, 2, 779)
		await recordRoomVisit(env.DB, 12, 779)
		const body = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/me?skip=0&take=100`, { headers })
		).json()) as Array<{ RoomId: number }>
		expect(body.map((r) => r.RoomId).sort((a, b) => a - b)).toEqual([2, 12])

		// Un-cheering still counts as visited (the interaction row persists).
		await SELF.fetch(`${ORIGIN}/rooms/2/interactionby/me/cheer`, { method: 'PUT', headers })
		const afterUncheer = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/me`, { headers })
		).json()) as unknown[]
		expect(afterUncheer.length).toBe(2)

		// Scoped per player — a different account sees none.
		const other = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/me`, { headers: await bearer('780') })
		).json()) as unknown[]
		expect(other).toEqual([])
	})

	it('GET /rooms/visitedby/me/count answers the number of distinct rooms visited, as a bare int', async () => {
		const headers = await bearer('785')
		const count = async (h: HeadersInit) =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/visitedby/me/count`, { headers: h })
			).json()) as unknown

		expect(await count(headers)).toBe(0)

		// A favorite alone is not a visit.
		await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/favorite`, { method: 'PUT', headers })
		expect(await count(headers)).toBe(0)

		// Revisiting a room doesn't count it twice.
		await recordRoomVisit(env.DB, 2, 785)
		await recordRoomVisit(env.DB, 2, 785)
		await recordRoomVisit(env.DB, 12, 785)
		expect(await count(headers)).toBe(2)

		expect(await count(await bearer('786'))).toBe(0)
		expect((await SELF.fetch(`${ORIGIN}/rooms/visitedby/me/count`)).status).toBe(401)
	})

	it('GET /rooms/visitedby/:playerId serves any player’s visited rooms to any authed caller', async () => {
		// Give 790 a visit history.
		const subject = await bearer('790')
		await recordRoomVisit(env.DB, 2, 790)
		await recordRoomVisit(env.DB, 12, 790)

		// Anyone with a token reads it — a bare array. Friendship is not required: a
		// player's history is as public as the rooms on their profile.
		for (const viewer of ['791', '792', '793', '794']) {
			const res = await SELF.fetch(`${ORIGIN}/rooms/visitedby/790`, {
				headers: await bearer(viewer),
			})
			expect(res.status).toBe(200)
			const body = (await res.json()) as Array<{ RoomId: number }>
			expect(body.map((r) => r.RoomId).sort((a, b) => a - b)).toEqual([2, 12])
		}

		// Paginated via skip/take.
		const page = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/790?skip=0&take=1`, {
				headers: await bearer('791'),
			})
		).json()) as unknown[]
		expect(page.length).toBe(1)

		// Your own history is readable by id, not just via `me`.
		const own = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/790`, { headers: subject })
		).json()) as unknown[]
		expect(own.length).toBe(2)

		// No token at all → 401, never a fallback account.
		const anon = await SELF.fetch(`${ORIGIN}/rooms/visitedby/790`)
		expect(anon.status).toBe(401)

		// `visitedby/me` still routes to the literal handler, not the id pattern.
		const me = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/me`, { headers: subject })
		).json()) as unknown[]
		expect(me.length).toBe(2)
	})

	it('GET /rooms/visitedby/:playerId hides visits to unpublished rooms', async () => {
		// 790 has been to an UNPUBLISHED room (their own build), an unlisted one, and a room
		// that opted out of lists — each stamped as the most recent visit, ahead of the two
		// public rooms the test above recorded.
		const seed = (data: Record<string, unknown>) =>
			env.DB.prepare('INSERT INTO room (data) VALUES (?1)').bind(JSON.stringify(data)).run()
		await seed({
			RoomId: 30501,
			Name: 'VisitedUnpublished',
			CreatorAccountId: 790,
			Accessibility: 0,
			SubRooms: [],
		})
		await seed({ RoomId: 30502, Name: 'VisitedUnlisted', Accessibility: 2, SubRooms: [] })
		await seed({
			RoomId: 30503,
			Name: 'VisitedOptedOut',
			Accessibility: 1,
			ExcludeFromLists: true,
			SubRooms: [],
		})
		await env.DB.prepare(
			`INSERT INTO interaction (player_id, room_id, last_visited_at)
			 VALUES (790, 30501, '2030-01-03T00:00:00.000Z'),
			        (790, 30502, '2030-01-02T00:00:00.000Z'),
			        (790, 30503, '2030-01-01T00:00:00.000Z')`
		).run()
		try {
			const ids = async (headers: Record<string, string>, query = '') =>
				(
					(await (
						await SELF.fetch(`${ORIGIN}/rooms/visitedby/790${query}`, { headers })
					).json()) as Array<{ RoomId: number }>
				).map((r) => r.RoomId)

			// Anyone else sees only the listable rooms of the history — public, not opted
			// out — and a page is a page of THOSE: the first two are the two public rooms,
			// not two holes where the hidden ones sat.
			const sorted = (list: number[]) => [...list].sort((a, b) => a - b)
			const viewer = await bearer('794')
			expect(sorted(await ids(viewer))).toEqual([2, 12])
			expect(sorted(await ids(viewer, '?skip=0&take=2'))).toEqual([2, 12])

			// The player's own history, by id or as `me`, is the whole of it, newest first.
			const subject = await bearer('790')
			const own = await ids(subject)
			expect(own.slice(0, 3)).toEqual([30501, 30502, 30503])
			expect(sorted(own)).toEqual([2, 12, 30501, 30502, 30503])
			expect(
				(
					(await (
						await SELF.fetch(`${ORIGIN}/rooms/visitedby/me`, { headers: subject })
					).json()) as Array<{ RoomId: number }>
				).map((r) => r.RoomId)
			).toEqual(own)
		} finally {
			await env.DB.prepare('DELETE FROM room WHERE room_id BETWEEN 30501 AND 30503').run()
			await env.DB.prepare('DELETE FROM interaction WHERE room_id BETWEEN 30501 AND 30503').run()
		}
	})

	it('GET /rooms/hot returns a paginated { Results, TotalResults } of public rooms', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/hot?skip=0&take=100`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			Results: Array<{ RoomId: number; IsDorm?: boolean }>
			TotalResults: number
		}
		expect(body.Results.length).toBeGreaterThan(0)
		expect(body.TotalResults).toBeGreaterThanOrEqual(body.Results.length)
		// The dorm (RoomId 1) is non-public, so it's never in the feed.
		expect(body.Results.some((r) => r.RoomId === 1 || r.IsDorm === true)).toBe(false)
	})

	it('GET /rooms/hot?tag=rro filters to rro-tagged rooms', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/hot?tag=rro&skip=0&take=100`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			Results: Array<{ Name: string; Tags?: Array<{ Tag: string }> }>
			TotalResults: number
		}
		expect(body.Results.length).toBeGreaterThan(0)
		// Every result carries the rro tag, and a known rro room is present.
		expect(body.Results.every((r) => (r.Tags ?? []).some((t) => t.Tag === 'rro'))).toBe(true)
		expect(body.Results.some((r) => r.Name === 'RecCenter')).toBe(true)
	})

	it('GET /rooms/hot respects take pagination (TotalResults is the full count)', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/hot?tag=rro&skip=0&take=2`)
		const body = (await res.json()) as { Results: unknown[]; TotalResults: number }
		expect(body.Results.length).toBeLessThanOrEqual(2)
		expect(body.TotalResults).toBeGreaterThan(body.Results.length)
	})

	it('GET /rooms/hot ranks rooms by the live presence in their instances', async () => {
		const feed = async (): Promise<number[]> =>
			(
				(await (await SELF.fetch(`${ORIGIN}/rooms/hot?skip=0&take=100`)).json()) as {
					Results: Array<{ RoomId: number }>
				}
			).Results.map((r) => r.RoomId)

		// Two rooms from the tail of the engagement-ordered feed, so any move to the
		// front can only come from presence.
		const before = await feed()
		const busiest = before[before.length - 1]
		const quieter = before[before.length - 2]

		// Two players in two different instances of `busiest`, one in `quieter`, plus a
		// lobby presence (no instance) that must not count for anyone.
		const expiresAt = Math.floor(Date.now() / 1000) + 900
		const seed = env.DB.prepare('INSERT OR REPLACE INTO presence (data) VALUES (?1)')
		await env.DB.batch(
			[
				{ accountId: 90001, roomInstance: { roomInstanceId: 1000901, roomId: busiest } },
				{ accountId: 90002, roomInstance: { roomInstanceId: 1000902, roomId: busiest } },
				{ accountId: 90003, roomInstance: { roomInstanceId: 1000903, roomId: quieter } },
				{ accountId: 90004, roomInstance: null },
			].map((p) => seed.bind(JSON.stringify({ ...p, expiresAt })))
		)

		expect((await feed()).slice(0, 2)).toEqual([busiest, quieter])

		// Expired presence doesn't count — the feed falls back to engagement order.
		await env.DB.prepare(
			`UPDATE presence SET data = json_set(data, '$.expiresAt', ?1)
			 WHERE account_id IN (90001, 90002, 90003, 90004)`
		)
			.bind(Math.floor(Date.now() / 1000) - 1)
			.run()
		expect(await feed()).toEqual(before)

		await env.DB.prepare(
			'DELETE FROM presence WHERE account_id IN (90001, 90002, 90003, 90004)'
		).run()
	})

	it('GET /rooms/curated_playlists is an empty list, not a 404', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/curated_playlists`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])
	})

	it('GET /rooms/carousel/foryou serves the public hot feed with pagination', async () => {
		for (const query of ['?skip=0&take=2', '?skip=2&take=2']) {
			const recommended = await SELF.fetch(`${ORIGIN}/rooms/carousel/foryou${query}`)
			const hot = await SELF.fetch(`${ORIGIN}/rooms/hot${query}`)
			expect(recommended.status).toBe(200)
			expect(await recommended.json()).toEqual(await hot.json())
		}
	})

	it('GET /rooms/carousel/rising serves only rooms players are in, busiest first', async () => {
		const rising = async (qs = '?skip=0&take=100') =>
			(await (await SELF.fetch(`${ORIGIN}/rooms/carousel/rising${qs}`)).json()) as {
				Results: Array<{ RoomId: number; IsDorm?: boolean }>
				TotalResults: number
			}

		// Nobody is anywhere in the fixture, and an empty carousel is the honest answer —
		// this feed does NOT fall back to engagement the way /rooms/hot does.
		expect(await rising()).toEqual({ Results: [], TotalResults: 0 })

		// Pick from the tail of the hot feed so the order below can only come from presence.
		const hot = (
			(await (await SELF.fetch(`${ORIGIN}/rooms/hot?skip=0&take=100`)).json()) as {
				Results: Array<{ RoomId: number }>
			}
		).Results.map((r) => r.RoomId)
		const busiest = hot[hot.length - 1]
		const quieter = hot[hot.length - 2]

		const expiresAt = Math.floor(Date.now() / 1000) + 900
		const seed = env.DB.prepare('INSERT OR REPLACE INTO presence (data) VALUES (?1)')
		await env.DB.batch(
			[
				{ accountId: 90101, roomInstance: { roomInstanceId: 1001001, roomId: busiest } },
				{ accountId: 90102, roomInstance: { roomInstanceId: 1001002, roomId: busiest } },
				{ accountId: 90103, roomInstance: { roomInstanceId: 1001003, roomId: quieter } },
				// The dorm nobody may list, and a lobby presence in no room at all: neither
				// puts a room in the carousel.
				{ accountId: 90104, roomInstance: { roomInstanceId: 1001004, roomId: 1 } },
				{ accountId: 90105, roomInstance: null },
			].map((p) => seed.bind(JSON.stringify({ ...p, expiresAt })))
		)

		const busy = await rising()
		expect(busy.Results.map((r) => r.RoomId)).toEqual([busiest, quieter])
		expect(busy.TotalResults).toBe(2)
		expect(busy.Results.some((r) => r.RoomId === 1 || r.IsDorm === true)).toBe(false)

		// Paged like its sibling feeds: TotalResults stays the full count.
		expect(await rising('?skip=0&take=1')).toMatchObject({ TotalResults: 2 })
		expect((await rising('?skip=0&take=1')).Results.map((r) => r.RoomId)).toEqual([busiest])
		expect((await rising('?skip=1&take=100')).Results.map((r) => r.RoomId)).toEqual([quieter])

		// Presence that has expired is nobody standing there.
		await env.DB.prepare(
			`UPDATE presence SET data = json_set(data, '$.expiresAt', ?1)
			 WHERE account_id BETWEEN 90101 AND 90105`
		)
			.bind(Math.floor(Date.now() / 1000) - 1)
			.run()
		expect(await rising()).toEqual({ Results: [], TotalResults: 0 })

		await env.DB.prepare('DELETE FROM presence WHERE account_id BETWEEN 90101 AND 90105').run()
	})

	it('GET /rooms/hot aliases #recroomoriginal to the rro tag', async () => {
		const aliased = (await (
			await SELF.fetch(`${ORIGIN}/rooms/hot?tag=recroomoriginal`)
		).json()) as { TotalResults: number }
		const direct = (await (await SELF.fetch(`${ORIGIN}/rooms/hot?tag=rro`)).json()) as {
			TotalResults: number
		}
		expect(aliased.TotalResults).toBe(direct.TotalResults)
		expect(aliased.TotalResults).toBeGreaterThan(0)
	})

	it('GET /rooms/hot?tag=new serves player-made rooms newest-first (pseudo-tag)', async () => {
		type Feed = { Results: Array<{ Name: string }>; TotalResults: number }
		const feed = async (): Promise<Feed> =>
			(await (await SELF.fetch(`${ORIGIN}/rooms/hot?tag=new&skip=0&take=100`)).json()) as Feed
		const names = async (): Promise<string[]> => (await feed()).Results.map((r) => r.Name)

		// No room carries a `new` tag, and every seeded room is a Rec Room Original — so
		// the feed is empty until a player makes something.
		expect(await feed()).toEqual({ Results: [], TotalResults: 0 })

		const seeded: number[] = []
		const seed = async (room: Record<string, unknown>) => {
			seeded.push(Number(room.RoomId))
			await seedRoomWithSubRooms(env.DB, { Accessibility: 1, IsDorm: false, IsRRO: false, ...room })
		}

		// Two player-made public rooms and one that isn't public.
		await seed({ RoomId: 9001, Name: 'OlderPlayerRoom', CreatedAt: '2026-07-01T00:00:00Z' })
		await seed({ RoomId: 9002, Name: 'NewerPlayerRoom', CreatedAt: '2026-07-02T00:00:00Z' })
		await seed({
			RoomId: 9003,
			Name: 'UnlistedPlayerRoom',
			CreatedAt: '2026-07-03T00:00:00Z',
			Accessibility: 2,
		})

		// Newest first, and the non-public room is excluded as it is everywhere else.
		expect(await feed()).toMatchObject({
			Results: [{ Name: 'NewerPlayerRoom' }, { Name: 'OlderPlayerRoom' }],
			TotalResults: 2,
		})

		// An RRO stays out even when it's the newest room in the database — by the flag,
		// or by the auto-derived `rro` tag alone.
		await seed({
			RoomId: 9004,
			Name: 'BrandNewRRO',
			CreatedAt: '2026-07-04T00:00:00Z',
			IsRRO: true,
		})
		await seed({
			RoomId: 9005,
			Name: 'TaggedRRO',
			CreatedAt: '2026-07-05T00:00:00Z',
			Tags: [{ Tag: 'rro', Type: 2 }],
		})
		expect(await names()).toEqual(['NewerPlayerRoom', 'OlderPlayerRoom'])

		// Paging comes off the same order.
		const page = (await (
			await SELF.fetch(`${ORIGIN}/rooms/hot?tag=new&skip=1&take=1`)
		).json()) as Feed
		expect(page).toMatchObject({ Results: [{ Name: 'OlderPlayerRoom' }], TotalResults: 2 })

		// Leave the shared feeds as they were for the tests that follow.
		const ids = seeded.join(',')
		await env.DB.prepare(`DELETE FROM room WHERE room_id IN (${ids})`).run()
		await env.DB.prepare(`DELETE FROM subroom WHERE room_id IN (${ids})`).run()
	})

	it('GET /rooms/hot?tag=community serves rooms the Coach account did not create', async () => {
		type Feed = { Results: Array<{ Name: string }>; TotalResults: number }
		const feed = async (): Promise<Feed> =>
			(await (await SELF.fetch(`${ORIGIN}/rooms/hot?tag=community&skip=0&take=100`)).json()) as Feed
		const names = async (): Promise<string[]> => (await feed()).Results.map((r) => r.Name)

		// No room carries a `community` tag, and every seeded room belongs to Coach
		// (account 1) — so the feed is empty until another account makes something.
		expect(await feed()).toEqual({ Results: [], TotalResults: 0 })

		const seeded: number[] = []
		const seed = async (room: Record<string, unknown>) => {
			seeded.push(Number(room.RoomId))
			await seedRoomWithSubRooms(env.DB, {
				Accessibility: 1,
				IsDorm: false,
				CreatorAccountId: 2,
				...room,
			})
		}

		await seed({ RoomId: 9101, Name: 'CommunityOne' })
		await seed({ RoomId: 9102, Name: 'CommunityTwo' })
		// Coach's own rooms stay out, and so do non-public rooms as everywhere else.
		await seed({ RoomId: 9103, Name: 'CoachRoom', CreatorAccountId: 1 })
		await seed({ RoomId: 9104, Name: 'UnlistedCommunityRoom', Accessibility: 2 })

		// Nobody is in any of them and their stats are all zero, so the feed's normal
		// ordering falls through to RoomId.
		expect(await names()).toEqual(['CommunityOne', 'CommunityTwo'])

		// Creator, not RRO-ness, is what `community` filters on — unlike `new`, a
		// player-made room flagged as an RRO still belongs here.
		await seed({ RoomId: 9105, Name: 'PlayerMadeRRO', IsRRO: true })
		expect(await names()).toEqual(['CommunityOne', 'CommunityTwo', 'PlayerMadeRRO'])

		// Paging comes off the same order.
		const page = (await (
			await SELF.fetch(`${ORIGIN}/rooms/hot?tag=community&skip=1&take=1`)
		).json()) as Feed
		expect(page).toMatchObject({ Results: [{ Name: 'CommunityTwo' }], TotalResults: 3 })

		// Leave the shared feeds as they were for the tests that follow.
		const ids = seeded.join(',')
		await env.DB.prepare(`DELETE FROM room WHERE room_id IN (${ids})`).run()
		await env.DB.prepare(`DELETE FROM subroom WHERE room_id IN (${ids})`).run()
	})

	it('GET /rooms/base returns a bare array of base/template rooms (incl. non-public)', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/base`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as Array<{
			RoomId: number
			Accessibility: number
			Tags?: Array<{ Tag: string }>
		}>
		expect(Array.isArray(body)).toBe(true)
		expect(body.length).toBeGreaterThan(0)
		// Every result carries the `base` tag.
		expect(body.every((r) => (r.Tags ?? []).some((t) => t.Tag === 'base'))).toBe(true)
		// Includes rooms that aren't publicly listed (Accessibility != 1) — base
		// rooms bypass the public filter the feeds use.
		expect(body.some((r) => r.Accessibility !== 1)).toBe(true)
	})

	it('GET /rooms/base respects take pagination', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/base?skip=0&take=5`)
		const body = (await res.json()) as unknown[]
		expect(body.length).toBeLessThanOrEqual(5)
	})

	it('GET /rooms/recommendations returns a bare array of public rooms (split-test params ignored)', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/recommendations?splitTestId=1&splitTestValue=5`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as Array<{ RoomId: number; IsDorm?: boolean }>
		expect(Array.isArray(body)).toBe(true)
		expect(body.length).toBeGreaterThan(0)
		// The dorm (RoomId 1) is non-public, so it's never recommended.
		expect(body.some((r) => r.RoomId === 1 || r.IsDorm === true)).toBe(false)

		// The split-test params don't change the result.
		const plain = (await (await SELF.fetch(`${ORIGIN}/rooms/recommendations`)).json()) as Array<{
			RoomId: number
		}>
		expect(plain.map((r) => r.RoomId)).toEqual(body.map((r) => r.RoomId))
	})

	it('GET /rooms/recommendations respects take pagination', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/recommendations?skip=0&take=3`)
		const body = (await res.json()) as unknown[]
		expect(body.length).toBeLessThanOrEqual(3)
	})

	// The feeds narrow to the listable rooms in SQL (LISTABLE_WHERE, off idx_room_public)
	// rather than by parsing every room in the database. That predicate has to answer
	// exactly what the in-memory `isListable` answered, and the interesting case is the
	// MISSING key: `ExcludeFromLists !== true` accepts a blob that never carried the field,
	// so the SQL has to accept the NULL its generated column extracts.
	it('the feeds’ SQL filter treats a missing ExcludeFromLists as not-excluded', async () => {
		const seed = (data: Record<string, unknown>) =>
			env.DB.prepare('INSERT INTO room (data) VALUES (?1)').bind(JSON.stringify(data)).run()

		// No `ExcludeFromLists` key at all — the shape of every room seeded before the flag
		// existed.
		await seed({
			RoomId: 30801,
			Name: 'NoExcludeKey',
			CreatorAccountId: 830,
			Accessibility: 1,
			IsDorm: false,
			SubRooms: [],
		})
		// Same room, opted out of the feeds.
		await seed({
			RoomId: 30802,
			Name: 'OptedOut',
			CreatorAccountId: 830,
			Accessibility: 1,
			IsDorm: false,
			ExcludeFromLists: true,
			SubRooms: [],
		})
		// And one opted out of SEARCH instead — the other flag, which the feeds ignore.
		await seed({
			RoomId: 30803,
			Name: 'Unsearchable',
			CreatorAccountId: 830,
			Accessibility: 1,
			IsDorm: false,
			ExcludeFromSearch: true,
			SubRooms: [],
		})

		const namesIn = async (path: string) => {
			const body = (await (await SELF.fetch(`${ORIGIN}${path}`)).json()) as
				{ Results: Array<{ Name: string }> } | Array<{ Name: string }>
			return (Array.isArray(body) ? body : body.Results).map((r) => r.Name)
		}

		for (const feed of ['/rooms/hot?take=200', '/rooms/recommendations?take=200']) {
			expect(await namesIn(feed)).toContain('NoExcludeKey')
			expect(await namesIn(feed)).not.toContain('OptedOut')
			// `ExcludeFromSearch` is search's flag, not the feeds': the room still lists.
			expect(await namesIn(feed)).toContain('Unsearchable')
		}

		// SEARCH is its own filter (SEARCHABLE_WHERE): a room can opt out of the browse feeds
		// and still be findable by name, so this must not have narrowed with the feeds…
		expect(await namesIn('/rooms/search?query=optedout')).toContain('OptedOut')
		// …while a room opted out of SEARCH is not found, by name or by the missing key's
		// opposite — and the suggestion box, which draws from the same rooms, never offers it.
		expect(await namesIn('/rooms/search?query=unsearchable')).toEqual([])
		expect(await namesIn('/rooms/search?query=noexcludekey')).toContain('NoExcludeKey')
		expect(
			await (await SELF.fetch(`${ORIGIN}/rooms/autocomplete_search?query=unsearch&take=10`)).json()
		).toEqual([])

		await env.DB.prepare('DELETE FROM room WHERE room_id IN (30801, 30802, 30803)').run()
	})

	// Served only to the client builds that render it — the 2023 client's other room
	// listings start failing with NREs when it gets this payload, which is why the route
	// was parked entirely for a while (see FEATURED_ROOMS_VERSIONS in rooms.app.ts).
	it('GET /featuredrooms/current serves the group to a supported client build', async () => {
		const res = await SELF.fetch(`${ORIGIN}/featuredrooms/current`, {
			headers: await bearer('1', undefined, '20250718.01'),
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			FeaturedRoomGroupId: number
			name: string
			StartAt: string
			EndAt: string
			Rooms: Array<{ RoomId: number; RoomName: string; ImageName: string }>
		}
		expect(body.FeaturedRoomGroupId).toBe(1)
		expect(body.name).toBe('Featured Rooms')
		expect(body.Rooms.length).toBeGreaterThan(0)
		// Compact projection carries name + image, not the full room blob.
		expect(body.Rooms.every((r) => typeof r.RoomName === 'string')).toBe(true)
		// The dorm (RoomId 1) is non-public, so it's never featured.
		expect(body.Rooms.some((r) => r.RoomId === 1)).toBe(false)

		// The allow-list holds the BUILD (the bare date), so every point release of it is
		// served: a `.2` rebuild of the 2025 client renders the group the same as `.01`.
		for (const version of ['20250718.2', '20250718']) {
			const point = await SELF.fetch(`${ORIGIN}/featuredrooms/current`, {
				headers: await bearer('1', undefined, version),
			})
			expect(point.status, version).toBe(200)
		}
	})

	it('GET /featuredrooms/current serves at most 10 rooms', async () => {
		// Seed more eligible rooms than the cap, so the length is decided by the cap rather
		// than by how many rooms the suite happens to have.
		const ids = Array.from({ length: 14 }, (_, i) => 30900 + i)
		for (const RoomId of ids) {
			await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
				.bind(
					JSON.stringify({
						RoomId,
						Name: `Featurable${RoomId}`,
						CreatorAccountId: 831,
						Accessibility: 1,
						IsDorm: false,
						SubRooms: [],
					})
				)
				.run()
		}

		const res = await SELF.fetch(`${ORIGIN}/featuredrooms/current`, {
			headers: await bearer('1', undefined, '20250718.01'),
		})
		const body = (await res.json()) as { Rooms: Array<{ RoomId: number }> }
		// A featured group is a short selection, not the whole room list.
		expect(body.Rooms).toHaveLength(10)
		// The cap TRIMS the shuffled list rather than sampling with replacement, so no room
		// can appear twice in one group.
		expect(new Set(body.Rooms.map((r) => r.RoomId)).size).toBe(10)

		await env.DB.prepare(`DELETE FROM room WHERE room_id IN (${ids.join(', ')})`).run()
	})

	it('GET /featuredrooms/current withholds the group from other client builds', async () => {
		// The 2023 build gets the 404 it got while the route was parked — the state in which
		// its room listings work. Same for a token with no `rn.ver` at all.
		for (const version of ['20230414', '20231207', undefined]) {
			const res = await SELF.fetch(`${ORIGIN}/featuredrooms/current`, {
				headers: await bearer('1', undefined, version),
			})
			expect(res.status, `build ${version}`).toBe(404)
		}

		// And no token at all is a 401, not a 404: the build is read off the token.
		expect((await SELF.fetch(`${ORIGIN}/featuredrooms/current`)).status).toBe(401)
	})
})

it('GET /rooms/search matches every term, pages in creation order, and finds non-ASCII names', async () => {
		for (const [RoomId, Name] of [
			[97_201, 'ZZQSEARCH Alpha'],
			[97_202, 'CAFÉ Zzqsearch'],
			[97_203, 'Zzqsearch Gamma'],
			[97_204, 'Zzqother Alpha'],
		] as const) {
			await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
				.bind(JSON.stringify({ RoomId, Name, CreatorAccountId: 1, Accessibility: 1 }))
				.run()
		}
		const search = async (query: string, page = '') => {
			const res = await SELF.fetch(
				`${ORIGIN}/rooms/search?query=${encodeURIComponent(query)}${page}`
			)
			const body = (await res.json()) as {
				Results: Array<{ RoomId: number; Name: string; SubRooms: unknown[] }>
				TotalResults: number
			}
			return { ids: body.Results.map((r) => r.RoomId), total: body.TotalResults, body }
		}

		// Case-insensitive substring, in the order the rooms were created.
		const all = await search('zzqsearch')
		expect(all.ids).toEqual([97_201, 97_202, 97_203])
		expect(all.total).toBe(3)
		// What comes back is the whole hydrated room, not the scan's id-and-name row.
		expect(all.body.Results[0]).toMatchObject({ Name: 'ZZQSEARCH Alpha', SubRooms: [] })
		// Every term has to match.
		expect((await search('zzqsearch alpha')).ids).toEqual([97_201])
		// A page is cut from the matches; the total still counts them all.
		expect(await search('zzqsearch', '&skip=1&take=1')).toMatchObject({ ids: [97_202], total: 3 })
		// A non-ASCII term can't be matched by SQLite's `lower()`; it still finds the room.
		expect((await search('café')).ids).toEqual([97_202])
		expect((await search('café zzqsearch')).ids).toEqual([97_202])
		// The total is the count of matches even past the last page, and with nothing to serve.
		expect(await search('zzqsearch', '&skip=50&take=10')).toMatchObject({ ids: [], total: 3 })
		expect(await search('zzqnothing')).toMatchObject({ ids: [], total: 0 })

		// The feed tests below count the public rooms; leave them as they were.
		await env.DB.prepare('DELETE FROM room WHERE room_id BETWEEN 97201 AND 97204').run()
	})

it('GET /rooms/hot?tag=rro ignores a user-added rro tag (only Type 2 counts)', async () => {
		const hot = async () => {
			const res = await SELF.fetch(`${ORIGIN}/rooms/hot?tag=rro&skip=0&take=100`)
			expect(res.status).toBe(200)
			return ((await res.json()) as { Results: Array<{ Name: string }> }).Results
		}
		expect((await hot()).some((r) => r.Name === 'RecCenter')).toBe(true)
		// Downgrade RecCenter's rro to a user tag: anyone can add one of those to their room.
		const demote = (type: number) =>
			env.DB.prepare(
				`UPDATE room_tag SET type = ?1 WHERE tag = 'rro'
				 AND room_id = (SELECT room_id FROM room WHERE name_lower = 'reccenter')`
			)
				.bind(type)
				.run()
		await demote(0)
		try {
			expect((await hot()).some((r) => r.Name === 'RecCenter')).toBe(false)
		} finally {
			await demote(2)
		}
	})
