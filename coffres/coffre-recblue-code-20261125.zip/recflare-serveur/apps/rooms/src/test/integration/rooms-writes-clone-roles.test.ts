// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { getRoomById, seedRoomWithSubRooms } from '@repo/domain'

import { NotificationType } from '../../../../notify/src/notification-types'
import makerTemplates from '../../../migrations/0035_maker_templates.sql?raw'
import templateImages from '../../../migrations/0036_maker_template_images.sql?raw'
import templateDescriptions from '../../../migrations/0037_maker_template_descriptions.sql?raw'
import {
	bearer,
	bodyOf,
	clearPresence,
	envOf,
	ORIGIN,
	putForm,
	putInRoom,
	setupSchema,
	storedRoleOf,
} from './support/harness'

import type { Room } from '@repo/domain'

beforeAll(setupSchema)

describe('rooms endpoints', () => {
	it('GET /rooms/:id/similar returns { Results, TotalResults } of tag-sharing rooms (excluding self)', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/2/similar`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			Results: Array<{ RoomId: number; Tags?: Array<{ Tag: string }> }>
			TotalResults: number
		}
		expect(body.Results.length).toBeGreaterThan(0)
		expect(body.TotalResults).toBeGreaterThanOrEqual(body.Results.length)
		// Never includes the target room itself.
		expect(body.Results.some((r) => r.RoomId === 2)).toBe(false)
		// Every result shares the `rro` tag RecCenter (room 2) carries.
		expect(body.Results.every((r) => (r.Tags ?? []).some((t) => t.Tag === 'rro'))).toBe(true)
	})

	it('GET /rooms/:id/similar respects take pagination', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/2/similar?skip=0&take=3`)
		const body = (await res.json()) as { Results: unknown[]; TotalResults: number }
		expect(body.Results.length).toBeLessThanOrEqual(3)
		expect(body.TotalResults).toBeGreaterThan(body.Results.length)
	})

	it('GET /rooms/:id/similar returns an empty result for a room not in D1', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/99999/similar`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ Results: [], TotalResults: 0 })
	})

	it('POST /rooms/:id/clone clones a base room into a new owned room', async () => {
		const headers = {
			...(await bearer('801')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		const post = async (id: number, name: string) =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/${id}/clone`, {
					method: 'POST',
					headers,
					body: new URLSearchParams({ name }).toString(),
				})
			).json()) as {
				success: boolean
				error: string
				value: {
					RoomId: number
					Name: string
					CreatorAccountId: number
					Tags?: Array<{ Tag: string }>
					IsRRO: boolean
					IsDeveloperOwned: boolean
					CloningAllowed: boolean
					Accessibility: number
					Roles: Array<{ AccountId: number; Role: number; InvitedRole: number }>
					Stats: Record<string, number>
				} | null
			}

		// Give the source every flag and counter the clone must NOT inherit.
		await env.DB.prepare(
			`UPDATE room SET data = json_set(data, '$.IsDeveloperOwned', json('true'),
				'$.CloningAllowed', json('true'), '$.Stats.VisitorCount', 42) WHERE room_id = 24`
		).run()
		// And every kind of tag: an owner tag flagged as the genre (Type 0), the server's
		// `rro` (Type 2), and the two system tags the client derives (Type 1).
		await env.DB.batch([
			env.DB.prepare(
				`INSERT OR REPLACE INTO room_tag (room_id, tag, type, is_primary_genre)
				 VALUES (24, 'hangout', 0, 1), (24, 'rro', 2, 0), (24, 'beta', 1, 0), (24, 'limitsv2', 1, 0)`
			),
		])

		// Clone MakerRoom (base, RoomId 24) → a fresh room owned by the caller (801).
		const ok = await post(24, 'MyMakerClone')
		expect(ok.success).toBe(true)
		expect(ok.error).toBe('')
		expect(ok.value).not.toBeNull()
		expect(ok.value!.Name).toBe('MyMakerClone')
		expect(ok.value!.CreatorAccountId).toBe(801)
		expect(ok.value!.RoomId).toBeGreaterThan(51)
		// Only the system tags (Type 1) carry over — the scene needs them to run. The
		// owner's tags, the `base` template tag, the derived `rro` and the genre flag don't.
		expect(ok.value!.Tags).toEqual([
			{ Tag: 'beta', Type: 1 },
			{ Tag: 'limitsv2', Type: 1 },
		])
		// IsRRO is cleared so the client doesn't render a virtual "RRO" tag on the clone.
		expect(ok.value!.IsRRO).toBe(false)
		// Nor is it developer-owned, and the new owner opts it into cloning themselves.
		expect(ok.value!.IsDeveloperOwned).toBe(false)
		expect(ok.value!.CloningAllowed).toBe(false)
		// No engagement carries over — not even the blob-stored VisitorCount.
		expect(ok.value!.Stats).toEqual({
			CheerCount: 0,
			FavoriteCount: 0,
			VisitorCount: 0,
			VisitCount: 0,
		})
		// A new room is unpublished: Private (0), never the source's visibility.
		expect(ok.value!.Accessibility).toBe(0)
		// Ownership is reset to the cloner: sole owner (Role 255), and none of the
		// source base room's roles (accounts 1/2) carry over.
		expect(ok.value!.Roles).toEqual([
			{ AccountId: 801, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 },
		])

		// It persists and is fetchable by its new id.
		const fetched = (await (
			await SELF.fetch(`${ORIGIN}/rooms/${ok.value!.RoomId}`, {
				headers: await bearer('1', ['developer']),
			})
		).json()) as {
			Name: string
			Tags: unknown[]
			IsDeveloperOwned: boolean
			CloningAllowed: boolean
			Stats: Record<string, number>
		}
		expect(fetched.Name).toBe('MyMakerClone')
		// The system tags were written to `room_tag`, so they survive a re-read.
		expect(fetched.Tags).toEqual([
			{ Tag: 'beta', Type: 1 },
			{ Tag: 'limitsv2', Type: 1 },
		])
		expect(fetched.IsDeveloperOwned).toBe(false)
		expect(fetched.CloningAllowed).toBe(false)
		expect(fetched.Stats.VisitorCount).toBe(0)

		// Duplicate name is rejected.
		const dup = await post(24, 'MyMakerClone')
		expect(dup).toMatchObject({ success: false, value: null })
		expect(dup.error).toMatch(/already exists/i)
	})

	it('modern maker templates clone into independent R1 and R2 rooms', async () => {
		// Run the actual migrations twice, checking that they remain safe to reapply.
		for (let pass = 0; pass < 2; pass++) {
			for (const sql of [makerTemplates, templateImages, templateDescriptions]) {
				for (const stmt of sql.replace(/--[^\n]*/g, '').split(';')) {
					if (stmt.trim()) await env.DB.prepare(stmt).run()
				}
			}
		}
		const templates = await (await SELF.fetch(`${ORIGIN}/rooms/base`)).json<Room[]>()
		for (const [name, version, scene] of [
			['DefaultMakerRoom', 1, 'a75f7547-79eb-47c6-8986-6767abcb4f92'],
			['AdvancedMakerRoom', 2, '5d4e40d8-f289-4295-a6e1-4f907835007d'],
		] as const) {
			const matches = templates.filter((r) => r.Name === name)
			expect(matches).toHaveLength(1)
			const template = matches[0]!
			expect(template.ImageName).toBe(
				version === 1 ? '3ss6lkjmuddib0maid1bay1jp.png' : '1d2nvft6te5npx362qx9f098s.png'
			)
			expect(template.Description).toContain(
				version === 1 ? 'Previously called: MakerRoom (R1)' : 'Previously called: MakerRoom2 (R2)'
			)
			const response = await SELF.fetch(`${ORIGIN}/rooms/${template.RoomId}/clone`, {
				method: 'POST',
				headers: { ...(await bearer('893')), 'Content-Type': 'application/x-www-form-urlencoded' },
				body: new URLSearchParams({ name: `Clone${name}` }),
			})
			const result = await response.json<{ success: boolean; value: Room }>()
			expect(result.success).toBe(true)
			expect(result.value).toMatchObject({
				UgcVersion: version,
				CreatorAccountId: 893,
				Accessibility: 0,
			})
			const room = await getRoomById(env.DB, Number(result.value.RoomId))
			const sub = (room!.SubRooms as Array<Record<string, unknown>>)[0]!
			expect(sub.UnitySceneId).toBe(scene)
			expect(sub.SubRoomId).not.toBe(
				(template.SubRooms as Array<Record<string, unknown>>)[0]!.SubRoomId
			)
			if (version === 2) {
				expect(sub.CurrentSave).toMatchObject({
					OMVersion: 198,
					DataBlob: null,
					SubRoomId: sub.SubRoomId,
				})
			}
		}
	})

	it('POST /rooms/:id/clone gives a Plus subscriber the Plus room cap', async () => {
		const clone = async (sub: string, name: string, plus: boolean) =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/24/clone`, {
					method: 'POST',
					headers: {
						...(await bearer(sub, undefined, undefined, plus)),
						'Content-Type': 'application/x-www-form-urlencoded',
					},
					body: new URLSearchParams({ name }).toString(),
				})
			).json()) as { success: boolean; error: string; value: unknown }

		const original = env.MAX_ROOMS_PER_ACCOUNT
		const originalPlus = env.MAX_ROOMS_PER_ACCOUNT_PLUS
		try {
			env.MAX_ROOMS_PER_ACCOUNT = 1
			env.MAX_ROOMS_PER_ACCOUNT_PLUS = 2
			// A plain player stops at the base cap…
			expect(await clone('811', 'PlainOne', false)).toMatchObject({ success: true })
			expect((await clone('811', 'PlainTwo', false)).error).toMatch(/only have 1 rooms/i)
			// …a subscriber at the Plus one.
			expect(await clone('812', 'PlusOne', true)).toMatchObject({ success: true })
			expect(await clone('812', 'PlusTwo', true)).toMatchObject({ success: true })
			expect((await clone('812', 'PlusThree', true)).error).toMatch(/only have 2 rooms/i)

			// Plus never lowers the cap below the base one.
			env.MAX_ROOMS_PER_ACCOUNT = 3
			expect(await clone('812', 'PlusThreeForReal', true)).toMatchObject({ success: true })

			// 0 lifts the cap for subscribers only.
			env.MAX_ROOMS_PER_ACCOUNT = 1
			env.MAX_ROOMS_PER_ACCOUNT_PLUS = 0
			expect(await clone('812', 'PlusUncapped', true)).toMatchObject({ success: true })
			expect((await clone('811', 'PlainStillCapped', false)).success).toBe(false)
		} finally {
			env.MAX_ROOMS_PER_ACCOUNT = original
			env.MAX_ROOMS_PER_ACCOUNT_PLUS = originalPlus
		}
	})

	it('POST /rooms/:id/clone of a PUBLIC source stays out of the public feeds', async () => {
		// Park (RoomId 25) is the one seeded base room that is itself public
		// (Accessibility 1). Cloning used to inherit that, so a room appeared in
		// hot/search/recommendations the instant it was created — before its owner had
		// published anything.
		const res = await SELF.fetch(`${ORIGIN}/rooms/25/clone`, {
			method: 'POST',
			headers: {
				...(await bearer('802')),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: new URLSearchParams({ name: 'ParkCloneUnpublished' }).toString(),
		})
		const { value } = (await res.json()) as { value: { RoomId: number; Accessibility: number } }
		expect(value.Accessibility).toBe(0)

		const namesIn = async (path: string) => {
			const body = (await (await SELF.fetch(`${ORIGIN}${path}`)).json()) as
				{ Results: Array<{ Name: string }> } | Array<{ Name: string }>
			return (Array.isArray(body) ? body : body.Results).map((r) => r.Name)
		}
		expect(await namesIn('/rooms/hot?take=200')).not.toContain('ParkCloneUnpublished')
		expect(await namesIn('/rooms/hot?tag=new&take=200')).not.toContain('ParkCloneUnpublished')
		expect(await namesIn('/rooms/recommendations?take=200')).not.toContain('ParkCloneUnpublished')
		expect(await namesIn('/rooms/search?query=parkcloneunpublished')).not.toContain(
			'ParkCloneUnpublished'
		)

		// Publishing it (owner sets Accessibility to Public) puts it in the feed.
		await putForm('/rooms/' + value.RoomId + '/accessibility', { accessibility: '1' }, '802')
		expect(await namesIn('/rooms/hot?take=200')).toContain('ParkCloneUnpublished')
	})

	it('POST /rooms/:id/clone requires auth (401, no account-1 fallback)', async () => {
		// No Authorization header → hard 401, and nothing is created.
		const res = await SELF.fetch(`${ORIGIN}/rooms/24/clone`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams({ name: 'UnauthedClone' }).toString(),
		})
		expect(res.status).toBe(401)
		expect(await res.json()).toMatchObject({ success: false, value: null })

		// An invalid/garbage token is also rejected.
		const bad = await SELF.fetch(`${ORIGIN}/rooms/24/clone`, {
			method: 'POST',
			headers: {
				Authorization: 'Bearer not.a.jwt',
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: new URLSearchParams({ name: 'UnauthedClone' }).toString(),
		})
		expect(bad.status).toBe(401)

		// The room was never created.
		const lookup = await SELF.fetch(`${ORIGIN}/rooms?name=UnauthedClone`)
		expect(await lookup.json()).toEqual({})
	})

	it('POST /rooms/:id/clone validates name and cloneability', async () => {
		const headers = {
			...(await bearer('802')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		const post = async (id: number, body?: string) =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/${id}/clone`, { method: 'POST', headers, body })
			).json()) as { success: boolean; error: string; value: unknown }

		// Missing name.
		const noName = await post(24, new URLSearchParams({ name: '' }).toString())
		expect(noName).toMatchObject({ success: false, value: null })
		expect(noName.error).toMatch(/must enter a name/i)

		// The dorm (RoomId 1) disallows cloning.
		const notCloneable = await post(1, new URLSearchParams({ name: 'CannotCloneDorm' }).toString())
		expect(notCloneable).toMatchObject({ success: false, value: null })
		expect(notCloneable.error).toMatch(/can't clone/i)

		// A source room not in D1.
		const missing = await post(99999, new URLSearchParams({ name: 'CloneOfNothing' }).toString())
		expect(missing).toMatchObject({ success: false, value: null })
	})

	it('POST /rooms/:id/clone enforces the per-account room cap', async () => {
		const headers = {
			...(await bearer('803')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		const clone = async (name: string) =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/24/clone`, {
					method: 'POST',
					headers,
					body: new URLSearchParams({ name }).toString(),
				})
			).json()) as { success: boolean; error: string; value: unknown }

		// The cap an operator actually runs is the `MAX_ROOMS_PER_ACCOUNT` var; the
		// constant in the worker is only the fallback.
		const original = env.MAX_ROOMS_PER_ACCOUNT
		try {
			env.MAX_ROOMS_PER_ACCOUNT = 2
			expect(await clone('CapOne')).toMatchObject({ success: true })
			expect(await clone('CapTwo')).toMatchObject({ success: true })

			const rejected = await clone('CapThree')
			expect(rejected).toMatchObject({ success: false, value: null })
			expect(rejected.error).toMatch(/only have 2 rooms/i)

			// A dorm doesn't count against the cap — it's auto-provisioned, not made.
			await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
				.bind(
					JSON.stringify({
						RoomId: 30303,
						Name: '^Dorm803',
						CreatorAccountId: 803,
						IsDorm: true,
						SubRooms: [],
						Roles: [],
					})
				)
				.run()
			env.MAX_ROOMS_PER_ACCOUNT = 3
			expect(await clone('CapThreeForReal')).toMatchObject({ success: true })

			// 0 lifts the cap entirely.
			env.MAX_ROOMS_PER_ACCOUNT = 0
			expect(await clone('Uncapped')).toMatchObject({ success: true })
		} finally {
			env.MAX_ROOMS_PER_ACCOUNT = original
		}
	})

	// The 2026 client makes custom dorms by cloning one, so the clone stays a dorm. The
	// player's own dorm is still their OLDEST, and the custom one counts against the cap.
	it('POST /rooms/:id/clone of a dorm keeps IsDorm without replacing the player’s dorm', async () => {
		const headers = {
			...(await bearer('877')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		const dormId = (await (
			await SELF.fetch(`${ORIGIN}/dormroom/me`, { headers: await bearer('877') })
		).json()) as number
		// A provisioned dorm inherits the template's CloningAllowed; open it up explicitly.
		await env.DB.prepare(
			`UPDATE room SET data = json_set(data, '$.CloningAllowed', json('true')) WHERE room_id = ?1`
		)
			.bind(dormId)
			.run()

		const original = env.MAX_ROOMS_PER_ACCOUNT
		try {
			env.MAX_ROOMS_PER_ACCOUNT = 1
			const res = await SELF.fetch(`${ORIGIN}/rooms/${dormId}/clone`, {
				method: 'POST',
				headers,
				body: new URLSearchParams({ name: 'MyCustomDorm' }).toString(),
			})
			const cloned = (await res.json()) as {
				success: boolean
				value: { RoomId: number; IsDorm: boolean } | null
			}
			expect(cloned).toMatchObject({ success: true })
			expect(cloned.value!.IsDorm).toBe(true)
			expect(cloned.value!.RoomId).not.toBe(dormId)

			// Their dorm is still the one provisioned for them, not the clone.
			const dormAfter = (await (
				await SELF.fetch(`${ORIGIN}/dormroom/me`, { headers: await bearer('877') })
			).json()) as number
			expect(dormAfter).toBe(dormId)

			// The provisioned dorm is free; the custom one used the only slot.
			const capped = await SELF.fetch(`${ORIGIN}/rooms/${dormId}/clone`, {
				method: 'POST',
				headers,
				body: new URLSearchParams({ name: 'MyCustomDormTwo' }).toString(),
			})
			expect(await capped.json()).toMatchObject({ success: false, value: null })
		} finally {
			env.MAX_ROOMS_PER_ACCOUNT = original
		}
	})

	it('PUT /rooms/:id/description is auth-gated, owner-only, and persists', async () => {
		// No token → 401 (auth gate).
		expect((await putForm('/rooms/2/description', { description: 'x' })).status).toBe(401)
		// Not the owner (RecCenter is owned by account 1) → 200 envelope, Success:false.
		expect(
			await bodyOf(await putForm('/rooms/2/description', { description: 'x' }, '999'))
		).toMatchObject({ Success: false, ErrorId: 'Rooms.NotOwner' })
		// Unknown room → Rooms.DoesntExist envelope.
		expect(
			await bodyOf(await putForm('/rooms/99999/description', { description: 'x' }, '1'))
		).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.DoesntExist',
			Error: 'This room does not exist!',
		})

		// Owner updates it, and it persists.
		const ok = await putForm('/rooms/2/description', { description: 'blah blah blah' }, '1')
		expect(ok.status).toBe(200)
		expect(await bodyOf(ok)).toMatchObject({
			Success: true,
			Value: null,
			ErrorId: null,
			Error: null,
		})
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as { Description: string }
		expect(room.Description).toBe('blah blah blah')
	})

	it('PUT /rooms/:id/image is auth-gated, owner-only, and persists', async () => {
		const imageName = '644064b03bd64a8291cde284629e9ca9.jpg'
		// No token → 401 (auth gate).
		expect((await putForm('/rooms/2/image', { imageName })).status).toBe(401)
		// Not the owner (RecCenter is owned by account 1) → 200 envelope, Success:false.
		expect(await bodyOf(await putForm('/rooms/2/image', { imageName }, '999'))).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.NotOwner',
		})
		// Unknown room → Rooms.DoesntExist envelope.
		expect(await bodyOf(await putForm('/rooms/99999/image', { imageName }, '1'))).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.DoesntExist',
		})
		// Empty image → Success:false.
		expect(await bodyOf(await putForm('/rooms/2/image', { imageName: '  ' }, '1'))).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.InvalidImage',
		})

		// Owner sets it, and it persists.
		const ok = await putForm('/rooms/2/image', { imageName }, '1')
		expect(ok.status).toBe(200)
		expect(await bodyOf(ok)).toMatchObject({ Success: true })
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as { ImageName: string }
		expect(room.ImageName).toBe(imageName)
	})

	it('DELETE /rooms/:id is auth-gated, owner-only, and removes the room + its CDN image', async () => {
		// Throwaway room owned by account 1, with its image object in the CDN bucket and
		// a player interaction row.
		const ImageName = 'test/2026-07-17/delete-me.jpg'
		await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					RoomId: 9500,
					Name: 'DeleteMe',
					CreatorAccountId: 1,
					IsDorm: false,
					Accessibility: 1,
					ImageName,
					SubRooms: [],
				})
			)
			.run()
		await env.CDN_ASSETS.put(`room/${ImageName}`, new Uint8Array([1, 2, 3]))
		await env.DB.prepare(
			'INSERT INTO interaction (player_id, room_id, cheered, favorited) VALUES (7, 9500, 1, 1)'
		).run()

		const del = async (sub?: string) =>
			SELF.fetch(`${ORIGIN}/rooms/9500`, {
				method: 'DELETE',
				headers: sub ? await bearer(sub) : {},
			})
		const roomExists = async () =>
			(await env.DB.prepare('SELECT 1 FROM room WHERE room_id = 9500').first()) !== null

		// No token → 401. A non-owner → Success:false (room untouched).
		expect((await del()).status).toBe(401)
		expect(await bodyOf(await del('2'))).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.NotOwner',
		})
		expect(await roomExists()).toBe(true)

		// Owner → Success:true; the room, its interactions, and the CDN image are gone.
		expect(await bodyOf(await del('1'))).toMatchObject({ Success: true })
		expect(await roomExists()).toBe(false)
		expect(await env.CDN_ASSETS.get(`room/${ImageName}`)).toBeNull()
		const interactions = await env.DB.prepare(
			'SELECT COUNT(*) AS n FROM interaction WHERE room_id = 9500'
		).first<{ n: number }>()
		expect(interactions!.n).toBe(0)
	})

	it('DELETE /rooms/:id also lets staff through — the website’s takedown — but only there', async () => {
		// Somebody else's room. A developer token may delete it (a moderator's may not); the same token
		// may NOT rename it, which is what a misapplied check once allowed.
		await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					RoomId: 9501,
					Name: 'TakeMeDown',
					CreatorAccountId: 1,
					IsDorm: false,
					Accessibility: 1,
					ImageName: '',
					SubRooms: [],
				})
			)
			.run()
		const staff = await bearer('999', ['gameClient', 'developer'])
		const roomExists = async () =>
			(await env.DB.prepare('SELECT 1 FROM room WHERE room_id = 9501').first()) !== null

		const rename = await SELF.fetch(`${ORIGIN}/rooms/9501/name`, {
			method: 'PUT',
			headers: { ...staff, 'content-type': 'application/x-www-form-urlencoded' },
			body: 'name=Renamed',
		})
		expect(await bodyOf(rename)).toMatchObject({ Success: false, ErrorId: 'Rooms.NotOwner' })

		// A plain player is refused; the developer gets through.
		const del = async (headers: Record<string, string>, roomId = 9501) =>
			bodyOf(await SELF.fetch(`${ORIGIN}/rooms/${roomId}`, { method: 'DELETE', headers }))
		expect(await del(await bearer('2', ['gameClient']))).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.NotOwner',
		})
		expect(await roomExists()).toBe(true)
		expect(await del(staff)).toMatchObject({ Success: true })
		expect(await roomExists()).toBe(false)

		// A moderator is refused: deleting a room is developer-only.
		await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					RoomId: 9502,
					Name: 'ModCannotTakeMeDown',
					CreatorAccountId: 1,
					IsDorm: false,
					Accessibility: 1,
					ImageName: '',
					SubRooms: [],
				})
			)
			.run()
		expect(await del(await bearer('998', ['gameClient', 'moderator']), 9502)).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.NotOwner',
		})
		expect(await env.DB.prepare('SELECT 1 FROM room WHERE room_id = 9502').first()).not.toBeNull()
		await env.DB.prepare('DELETE FROM room WHERE room_id = 9502').run()

		// The takedown is the only row in the audit log: the owner's own deletion in the
		// test above wrote none, and the refused attempts wrote none. Each names the actor and
		// keeps enough of the room to say which one it was, now that the room itself is gone.
		const { results: audit } = await env.DB.prepare(
			'SELECT player_id, action, data FROM audit_log WHERE action = ?1 ORDER BY audit_log_id'
		)
			.bind('room_delete')
			.all<{ player_id: number; action: string; data: string }>()
		expect(audit).toHaveLength(1)
		expect(audit[0].player_id).toBe(999)
		expect(JSON.parse(audit[0].data)).toEqual({
			roomId: 9501,
			name: 'TakeMeDown',
			creatorAccountId: 1,
			accessibility: 1,
		})
	})

	it('PUT /rooms/:id/exclude is the staff listing toggle — both flags, together, staff only', async () => {
		// A public room its owner lists. Not a game endpoint: the real service set these two
		// flags from an admin tool, so the website's room page calls this with a staff token.
		await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					RoomId: 9502,
					Name: 'Delisted',
					CreatorAccountId: 1,
					IsDorm: false,
					Accessibility: 1,
					ImageName: '',
					SubRooms: [],
				})
			)
			.run()
		const put = async (excluded: string, headers: Record<string, string>) =>
			SELF.fetch(`${ORIGIN}/rooms/9502/exclude`, {
				method: 'PUT',
				headers: { ...headers, 'content-type': 'application/x-www-form-urlencoded' },
				body: `excluded=${excluded}`,
			})
		const flags = async () => {
			const row = await env.DB.prepare('SELECT data FROM room WHERE room_id = 9502').first<{
				data: string
			}>()
			const room = JSON.parse(row!.data) as Record<string, unknown>
			return { lists: room.ExcludeFromLists, search: room.ExcludeFromSearch }
		}

		// No token is a 401; the OWNER is refused like any other player — this is moderation,
		// not a room setting they have.
		expect((await put('true', {})).status).toBe(401)
		expect((await put('true', await bearer('1', ['gameClient']))).status).toBe(403)
		expect(await flags()).toEqual({ lists: undefined, search: undefined })

		const staff = await bearer('999', ['gameClient', 'moderator'])
		const hidden = await put('true', staff)
		expect(hidden.status).toBe(200)
		expect(await hidden.json()).toMatchObject({
			success: true,
			error: '',
			value: { RoomId: 9502, ExcludeFromLists: true, ExcludeFromSearch: true },
		})
		// Proper JSON booleans, not 1/0 — the virtual columns and the feeds read them as such.
		expect(await flags()).toEqual({ lists: true, search: true })

		// Hidden means hidden from search too, not just the feeds.
		const search = await SELF.fetch(`${ORIGIN}/rooms/search?query=Delisted`)
		const found = ((await search.json()) as { Results: Array<{ RoomId: number }> }).Results
		expect(found.find((r) => r.RoomId === 9502)).toBeUndefined()

		// And it flips back, both at once.
		expect(await (await put('false', staff)).json()).toMatchObject({
			success: true,
			value: { ExcludeFromLists: false, ExcludeFromSearch: false },
		})
		expect(await flags()).toEqual({ lists: false, search: false })

		// Anything but true/false is a rejection in the envelope, and writes nothing.
		expect(await (await put('maybe', staff)).json()).toMatchObject({ success: false })
		expect(await flags()).toEqual({ lists: false, search: false })

		// Each staff write is audited against the moderator, with what it did.
		const { results: audit } = await env.DB.prepare(
			'SELECT player_id, data FROM audit_log WHERE action = ?1 ORDER BY audit_log_id'
		)
			.bind('room_exclude')
			.all<{ player_id: number; data: string }>()
		expect(audit.map((row) => ({ by: row.player_id, ...JSON.parse(row.data) }))).toEqual([
			{ by: 999, roomId: 9502, name: 'Delisted', creatorAccountId: 1, excluded: true },
			{ by: 999, roomId: 9502, name: 'Delisted', creatorAccountId: 1, excluded: false },
		])
	})

	it('PUT /rooms/:id/roles/:accountId grants a helper role outright, but never co-owner', async () => {
		type Role = {
			AccountId: number
			Role: number
			InvitedRole: number
			LastChangedByAccountId: number | null
		}
		const roleOf = async (accountId: number): Promise<Role | undefined> =>
			((await (await SELF.fetch(`${ORIGIN}/rooms/2/roles`)).json()) as Role[]).find(
				(r) => r.AccountId === accountId
			)

		// RecCenter (room 2) is owned by account 1, with account 2 as co-owner.
		// No token → 401; a valid token with no standing in the room → 403.
		expect((await putForm('/rooms/2/roles/860', { role: '20' })).status).toBe(401)
		expect((await putForm('/rooms/2/roles/860', { role: '20' }, '999')).status).toBe(403)

		// The owner grants Moderator, which takes effect immediately — no invite, no accept.
		const ok = await putForm('/rooms/2/roles/860', { role: '20' }, '1')
		expect(ok.status).toBe(200)
		expect(await envOf(ok)).toMatchObject({ success: true, error: '' })
		expect(await roleOf(860)).toMatchObject({
			Role: 20,
			InvitedRole: 0,
			LastChangedByAccountId: 1,
		})

		// A co-owner may hand out the helper tiers too, updating the entry in place rather
		// than adding a second.
		expect((await putForm('/rooms/2/roles/860', { role: '10' }, '2')).status).toBe(200)
		const roles = (await (await SELF.fetch(`${ORIGIN}/rooms/2/roles`)).json()) as Role[]
		expect(roles.filter((r) => r.AccountId === 860)).toHaveLength(1)
		expect(await roleOf(860)).toMatchObject({ Role: 10, LastChangedByAccountId: 2 })

		// The two tiers a grant may never reach — co-ownership has to be accepted, and
		// Creator is more than co-ownership. Neither writes anything.
		for (const role of ['30', '255']) {
			expect(await envOf(await putForm('/rooms/2/roles/860', { role }, '1'))).toMatchObject({
				success: false,
				error: 'Co-ownership must be invited, not granted!',
			})
		}

		// A grant leaves a pending co-owner invite standing — the two are answered separately.
		expect((await putForm('/rooms/2/roles/861/invite', { role: '30' }, '1')).status).toBe(200)
		expect((await putForm('/rooms/2/roles/861', { role: '20' }, '1')).status).toBe(200)
		expect(await roleOf(861)).toMatchObject({ Role: 20, InvitedRole: 30 })
	})

	it('protects owners and co-owners against role changes and malformed answers', async () => {
		expect((await putForm('/rooms/2/roles/862/invite', { role: '30' }, '1')).status).toBe(200)
		expect(await envOf(await putForm('/rooms/2/roles/862', { role: '30' }, '862'))).toMatchObject({ success: true })
		const beforeOwner = await storedRoleOf(2, 1)
		const beforePeer = await storedRoleOf(2, 862)
		const hub = env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		await hub.fetch('http://do/all', { method: 'DELETE' })
		for (const target of [1, 862]) {
			expect(await envOf(await putForm(`/rooms/2/roles/${target}`, { role: '25' }, '2'))).toMatchObject({
				success: false,
			})
		}
		expect(await storedRoleOf(2, 1)).toEqual(beforeOwner)
		expect(await storedRoleOf(2, 862)).toEqual(beforePeer)
		expect(await (await hub.fetch('http://do/all')).json()).toEqual([])

		// The room owner can demote a co-owner, but a malformed role is never a revoke.
		expect(await envOf(await putForm('/rooms/2/roles/862', { role: '0junk' }, '1'))).toMatchObject({ success: false })
		expect(await storedRoleOf(2, 862)).toEqual(beforePeer)
		expect(await envOf(await putForm('/rooms/2/roles/862', { role: '25' }, '1'))).toMatchObject({ success: true })
		expect(await storedRoleOf(2, 862)).toMatchObject({ Role: 25 })

		// A partially numeric answer must not accept or decline an existing invite.
		expect((await putForm('/rooms/2/roles/863/invite', { role: '25' }, '2')).status).toBe(200)
		for (const role of ['25junk', '0junk']) {
			expect(await envOf(await putForm('/rooms/2/roles/863', { role }, '863'))).toMatchObject({ success: false })
		}
		expect(await storedRoleOf(2, 863)).toMatchObject({ Role: 0, InvitedRole: 25 })
	})

	it('PUT /rooms/:id/roles/:accountId with role=0 from an owner REVOKES the role', async () => {
		type Role = { AccountId: number; Role: number; InvitedRole: number }
		const rolesOf = async (): Promise<Role[]> =>
			(await (await SELF.fetch(`${ORIGIN}/rooms/2/roles`)).json()) as Role[]
		const roleOf = async (accountId: number) =>
			(await rolesOf()).find((r) => r.AccountId === accountId)

		// RecCenter (room 2) is owned by account 1, with account 2 as co-owner.
		expect((await putForm('/rooms/2/roles/880', { role: '10' }, '1')).status).toBe(200)
		expect(await roleOf(880)).toMatchObject({ Role: 10 })

		// The owner removes the role. The RECORD goes — there is no "holds no role" tier — and
		// the envelope carries the whole updated room, which is what the client re-renders from.
		const revoked = await putForm('/rooms/2/roles/880', { role: '0' }, '1')
		expect(revoked.status).toBe(200)
		const body = (await envOf(revoked)) as {
			success: boolean
			error: string
			value: { Roles: Role[] }
		}
		expect(body).toMatchObject({ success: true, error: '' })
		expect(body.value.Roles.some((r) => r.AccountId === 880)).toBe(false)
		expect(await roleOf(880)).toBeUndefined()

		// A body naming NO role is the same removal.
		expect((await putForm('/rooms/2/roles/881', { role: '20' }, '1')).status).toBe(200)
		expect(await envOf(await putForm('/rooms/2/roles/881', {}, '1'))).toMatchObject({
			success: true,
		})
		expect(await roleOf(881)).toBeUndefined()

		// ...but a role that is PRESENT and unparseable is still malformed, and must not be read
		// as a removal — a typo'd tier silently stripping someone would be the worst outcome.
		expect((await putForm('/rooms/2/roles/881', { role: '20' }, '1')).status).toBe(200)
		expect(await envOf(await putForm('/rooms/2/roles/881', { role: 'nope' }, '1'))).toMatchObject({
			success: false,
			error: 'You must provide a valid role!',
		})
		expect(await roleOf(881)).toMatchObject({ Role: 20 })

		// A co-owner may revoke a helper tier.
		expect(await envOf(await putForm('/rooms/2/roles/881', { role: '0' }, '2'))).toMatchObject({
			success: true,
		})
		expect(await roleOf(881)).toBeUndefined()

		// Removing a role the player does not hold is not a failure: they asked for no role, and
		// there is none. Nothing changes.
		const before = await rolesOf()
		expect(await envOf(await putForm('/rooms/2/roles/889', { role: '0' }, '1'))).toMatchObject({
			success: true,
		})
		expect(await rolesOf()).toEqual(before)

		// The gate still applies: no token 401s, and no standing in the room 403s.
		expect((await putForm('/rooms/2/roles/882', { role: '0' })).status).toBe(401)
		expect((await putForm('/rooms/2/roles/882', { role: '0' }, '999')).status).toBe(403)
	})

	it('a role revoke cannot touch the owner, and co-owners cannot revoke each other', async () => {
		type Role = { AccountId: number; Role: number; InvitedRole: number }
		const roleOf = async (accountId: number) =>
			((await (await SELF.fetch(`${ORIGIN}/rooms/2/roles`)).json()) as Role[]).find(
				(r) => r.AccountId === accountId
			)
		const refused = { success: false, error: 'You cannot remove that role!' }

		// Ownership is not a role anyone beside it can take away — it moves only by transfer.
		// Account 1 is RecCenter's creator; its co-owner cannot remove it.
		expect(await envOf(await putForm('/rooms/2/roles/1', { role: '0' }, '2'))).toMatchObject(
			refused
		)

		// Make 883 a second co-owner the only legal way: invited, then accepted.
		expect((await putForm('/rooms/2/roles/883/invite', { role: '30' }, '1')).status).toBe(200)
		expect((await putForm('/rooms/2/roles/883', { role: '30' }, '883')).status).toBe(200)
		expect(await roleOf(883)).toMatchObject({ Role: 30 })

		// Co-owners are peers, so one cannot strip the other — whichever asked first would win.
		expect(await envOf(await putForm('/rooms/2/roles/883', { role: '0' }, '2'))).toMatchObject(
			refused
		)
		expect(await envOf(await putForm('/rooms/2/roles/2', { role: '0' }, '883'))).toMatchObject(
			refused
		)
		expect(await roleOf(883)).toMatchObject({ Role: 30 })

		// The room's owner is not their peer, and may.
		expect(await envOf(await putForm('/rooms/2/roles/883', { role: '0' }, '1'))).toMatchObject({
			success: true,
		})
		expect(await roleOf(883)).toBeUndefined()
	})

	it('a role revoke takes a standing invite with it, and never removes your own entry', async () => {
		type Role = { AccountId: number; Role: number; InvitedRole: number }
		const roleOf = async (accountId: number) =>
			((await (await SELF.fetch(`${ORIGIN}/rooms/2/roles`)).json()) as Role[]).find(
				(r) => r.AccountId === accountId
			)

		// The whole entry goes, so a pending co-owner invite on it is withdrawn too.
		expect((await putForm('/rooms/2/roles/884/invite', { role: '30' }, '1')).status).toBe(200)
		expect((await putForm('/rooms/2/roles/884', { role: '10' }, '1')).status).toBe(200)
		expect(await roleOf(884)).toMatchObject({ Role: 10, InvitedRole: 30 })
		expect((await putForm('/rooms/2/roles/884', { role: '0' }, '1')).status).toBe(200)
		expect(await roleOf(884)).toBeUndefined()

		// On your OWN entry the path means answering an invite, which has to name its answer. An
		// empty body is a removal, and removing yourself is not what that branch does.
		expect((await putForm('/rooms/2/roles/885/invite', { role: '30' }, '1')).status).toBe(200)
		expect(await envOf(await putForm('/rooms/2/roles/885', {}, '885'))).toMatchObject({
			success: false,
			error: 'You must provide a valid role!',
		})
		expect(await storedRoleOf(2, 885)).toMatchObject({ Role: 0, InvitedRole: 30 })
		// The role list still shows the invite as pending.
		expect(await roleOf(885)).toMatchObject({ Role: 0, InvitedRole: 30 })
	})

	it('a revoke pushes a RoomUpdate to the room and to the player who lost the role', async () => {
		type Sent = { playerId: number; notificationType: string | number; data: { RoomId: number } }
		const hub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')

		expect((await putForm('/rooms/4/roles/887', { role: '20' }, '1')).status).toBe(200)
		// A bystander in the room, and the player losing the role standing somewhere else.
		await putInRoom(886, 4)
		await putInRoom(887, 2)
		await hub().fetch('http://do/all', { method: 'DELETE' })

		expect((await putForm('/rooms/4/roles/887', { role: '0' }, '1')).status).toBe(200)

		const pushed = (await (await hub().fetch('http://do/all')).json()) as Sent[]
		expect(pushed.map((n) => n.playerId).sort((a, b) => a - b)).toEqual([886, 887])
		expect(pushed.every((n) => n.data.RoomId === 4)).toBe(true)

		for (const id of [886, 887]) await clearPresence(id)
	})

	it('a grant pushes a RoomUpdate to the room and to the affected player', async () => {
		type Sent = { playerId: number; notificationType: string | number; data: { RoomId: number } }
		const hub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		const sent = async (): Promise<Sent[]> =>
			(await (await hub().fetch('http://do/all')).json()) as Sent[]

		// One bystander in room 4, and the player being granted the role standing somewhere
		// else entirely — a role they can use when they arrive, so they hear about it too.
		await putInRoom(870, 4)
		await putInRoom(871, 2)
		await hub().fetch('http://do/all', { method: 'DELETE' })

		expect((await putForm('/rooms/4/roles/871', { role: '20' }, '1')).status).toBe(200)

		const pushed = await sent()
		expect(pushed.map((n) => n.playerId).sort((a, b) => a - b)).toEqual([870, 871])
		expect(
			pushed.every((n) => n.notificationType === NotificationType.SubscriptionUpdateRoom)
		).toBe(true)
		expect(pushed.every((n) => n.data.RoomId === 4)).toBe(true)

		for (const id of [870, 871]) await clearPresence(id)
	})

	it('PUT /rooms/:id/roles/:accountId accepts a standing invite, and only that one', async () => {
		type Role = {
			AccountId: number
			Role: number
			InvitedRole: number
			LastChangedByAccountId: number | null
		}
		const roleOf = async (accountId: number): Promise<Role | undefined> =>
			((await (await SELF.fetch(`${ORIGIN}/rooms/2/roles`)).json()) as Role[]).find(
				(r) => r.AccountId === accountId
			)

		// RecCenter (room 2) is owned by account 1. The owner invites 850 to co-ownership,
		// leaving a pending offer and no role yet. The role list shows the pending invite, but
		// the room DTO does not list them: they are not a member until they accept.
		expect((await putForm('/rooms/2/roles/850/invite', { role: '30' }, '1')).status).toBe(200)
		expect(await storedRoleOf(2, 850)).toMatchObject({ Role: 0, InvitedRole: 30 })
		expect(await roleOf(850)).toMatchObject({ Role: 0, InvitedRole: 30 })
		const room2 = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as { Roles: Role[] }
		expect(room2.Roles.some((r) => r.AccountId === 850)).toBe(false)

		// No token → 401 (auth gate).
		expect((await putForm('/rooms/2/roles/850', { role: '30' })).status).toBe(401)
		// Nobody can accept on 850's behalf. A stranger has no standing here at all (403);
		// the owner and the co-owner fall through to the GRANT path, where co-ownership is
		// exactly the tier they may not hand over.
		expect((await putForm('/rooms/2/roles/850', { role: '30' }, '999')).status).toBe(403)
		for (const caller of ['1', '2']) {
			expect(
				await envOf(await putForm('/rooms/2/roles/850', { role: '30' }, caller))
			).toMatchObject({ success: false, error: 'Co-ownership must be invited, not granted!' })
		}
		expect(await storedRoleOf(2, 850)).toMatchObject({ Role: 0, InvitedRole: 30 })
		// Unknown room → failure envelope.
		expect(
			await envOf(await putForm('/rooms/99999/roles/850', { role: '30' }, '850'))
		).toMatchObject({ success: false, error: 'This room does not exist!' })
		// Non-numeric role → failure envelope.
		expect(await envOf(await putForm('/rooms/2/roles/850', { role: 'nope' }, '850'))).toMatchObject(
			{
				success: false,
			}
		)

		// Asking for a HIGHER role than the one offered is the attack this guards against:
		// refused, and the entry is untouched — still no role, invite still standing.
		expect(await envOf(await putForm('/rooms/2/roles/850', { role: '255' }, '850'))).toMatchObject({
			success: false,
		})
		expect(await storedRoleOf(2, 850)).toMatchObject({ Role: 0, InvitedRole: 30 })

		// A player with no entry in the room at all is the same rejection — probing tells
		// them nothing.
		expect(await envOf(await putForm('/rooms/2/roles/833', { role: '30' }, '833'))).toMatchObject({
			success: false,
		})
		expect(await roleOf(833)).toBeUndefined()

		// Accepting the role actually offered promotes the entry and consumes the invite.
		const ok = await putForm('/rooms/2/roles/850', { role: '30' }, '850')
		expect(ok.status).toBe(200)
		const okBody = await envOf(ok)
		expect(okBody).toMatchObject({ success: true, error: '' })
		expect(okBody.value?.Roles as Role[]).toContainEqual(
			expect.objectContaining({ AccountId: 850, Role: 30, InvitedRole: 0 })
		)
		expect(await roleOf(850)).toMatchObject({
			Role: 30,
			InvitedRole: 0,
			// Left as the OWNER who offered the role, not restamped with the accepter.
			LastChangedByAccountId: 1,
		})

		// The invite is spent: the same call again is refused, so it can't be replayed.
		expect(await envOf(await putForm('/rooms/2/roles/850', { role: '30' }, '850'))).toMatchObject({
			success: false,
		})
		expect(await roleOf(850)).toMatchObject({ Role: 30, InvitedRole: 0 })
	})

	it('PUT /rooms/:id/roles/:accountId with role=0 declines, dropping the entry', async () => {
		type Role = { AccountId: number; Role: number; InvitedRole: number }
		const roleOf = async (accountId: number): Promise<Role | undefined> =>
			((await (await SELF.fetch(`${ORIGIN}/rooms/2/roles`)).json()) as Role[]).find(
				(r) => r.AccountId === accountId
			)

		// Declining with nothing standing is the same rejection as any other unanswerable
		// invite — it can't be used to drop a role nobody offered to change.
		expect(await envOf(await putForm('/rooms/2/roles/851', { role: '0' }, '851'))).toMatchObject({
			success: false,
		})

		// Invited, then declined: the whole entry goes, leaving `Roles` as it was before the
		// offer rather than an entry with nothing pending on it.
		expect((await putForm('/rooms/2/roles/851/invite', { role: '30' }, '1')).status).toBe(200)
		expect(await storedRoleOf(2, 851)).toMatchObject({ Role: 0, InvitedRole: 30 })
		expect(await roleOf(851)).toMatchObject({ Role: 0, InvitedRole: 30 })

		const declined = await putForm('/rooms/2/roles/851', { role: '0' }, '851')
		expect(declined.status).toBe(200)
		expect(await envOf(declined)).toMatchObject({ success: true, error: '' })
		expect(await storedRoleOf(2, 851)).toBeUndefined()
		expect(await roleOf(851)).toBeUndefined()

		// And the decline can't be replayed either — there is no entry left to answer.
		expect(await envOf(await putForm('/rooms/2/roles/851', { role: '0' }, '851'))).toMatchObject({
			success: false,
		})

		// Declining takes a role the player ALREADY held with it: the invite is answered as a
		// whole, so a re-invited member who declines is left with nothing.
		expect((await putForm('/rooms/2/roles/852/invite', { role: '10' }, '1')).status).toBe(200)
		expect((await putForm('/rooms/2/roles/852', { role: '10' }, '852')).status).toBe(200)
		expect(await roleOf(852)).toMatchObject({ Role: 10, InvitedRole: 0 })
		expect((await putForm('/rooms/2/roles/852/invite', { role: '30' }, '1')).status).toBe(200)
		expect((await putForm('/rooms/2/roles/852', { role: '0' }, '852')).status).toBe(200)
		expect(await storedRoleOf(2, 852)).toBeUndefined()
		expect(await roleOf(852)).toBeUndefined()
	})

	it('accepting an invite pushes a RoomUpdate to everyone in the room', async () => {
		type Sent = {
			playerId: number
			notificationType: string | number
			data: { RoomId: number; Roles: Array<{ AccountId: number; Role: number }> }
		}
		const hub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		const sent = async (): Promise<Sent[]> =>
			(await (await hub().fetch('http://do/all')).json()) as Sent[]

		// Room 3's owner invites 840, who is standing in the room with two others. A fourth
		// player is in a DIFFERENT room, and a fifth's presence has lapsed — neither is there.
		expect((await putForm('/rooms/3/roles/840/invite', { role: '20' }, '1')).status).toBe(200)
		await putInRoom(840, 3)
		await putInRoom(841, 3)
		await putInRoom(842, 2)
		await putInRoom(843, 3, { expired: true })

		await hub().fetch('http://do/all', { method: 'DELETE' })
		expect((await putForm('/rooms/3/roles/840', { role: '20' }, '840')).status).toBe(200)

		// A role change alters what the room lets people do, so everyone standing in it
		// re-renders — including the accepter, who is one of them.
		const pushed = await sent()
		expect(pushed.map((n) => n.playerId).sort((a, b) => a - b)).toEqual([840, 841])
		expect(
			pushed.every((n) => n.notificationType === NotificationType.SubscriptionUpdateRoom)
		).toBe(true)
		// Each carries the room as it now stands, with the accepted role on it.
		expect(pushed[0].data).toMatchObject({ RoomId: 3 })
		expect(pushed[0].data.Roles).toContainEqual(
			expect.objectContaining({ AccountId: 840, Role: 20, InvitedRole: 0 })
		)

		for (const id of [840, 841, 842, 843]) await clearPresence(id)
	})

	it('GET /rooms/:id/roles serves the room’s roles as a bare array', async () => {
		// RecCenter (room 2) is seeded with its creator (255) and a co-owner (30). Public,
		// like the room itself — no token.
		const res = await SELF.fetch(`${ORIGIN}/rooms/2/roles`)
		expect(res.status).toBe(200)
		// Containment, not equality: the role-write test above grants account 5 a role on
		// this same room, and the two tests share a database.
		expect(await res.json()).toEqual(
			expect.arrayContaining([
				{ AccountId: 1, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 },
				{ AccountId: 2, Role: 30, LastChangedByAccountId: null, InvitedRole: 0 },
			])
		)

		// An unknown room reads the same as a room nobody holds a role in.
		expect((await SELF.fetch(`${ORIGIN}/rooms/99999/roles`)).status).toBe(200)
		expect(await (await SELF.fetch(`${ORIGIN}/rooms/99999/roles`)).json()).toEqual([])

		// A role written without `LastChangedByAccountId`/`InvitedRole` (the older rooms) is
		// still served as a whole record — the client's parser wants every key.
		await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					RoomId: 30601,
					Name: 'PartialRoles',
					CreatorAccountId: 830,
					SubRooms: [],
					Roles: [{ AccountId: 830, Role: 255 }],
				})
			)
			.run()
		expect(await (await SELF.fetch(`${ORIGIN}/rooms/30601/roles`)).json()).toEqual([
			{ AccountId: 830, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 },
		])

		// A room with no `Roles` key at all is an empty list, not a failure.
		await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
			.bind(JSON.stringify({ RoomId: 30602, Name: 'NoRoles', CreatorAccountId: 830, SubRooms: [] }))
			.run()
		expect(await (await SELF.fetch(`${ORIGIN}/rooms/30602/roles`)).json()).toEqual([])
	})

	it('PUT /rooms/:id/creator hands the room over, and only the owner may', async () => {
		type Role = { AccountId: number; Role: number; LastChangedByAccountId: number | null }
		const roomOf = async (roomId: number) =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/${roomId}`, { headers: await bearer('1', ['developer']) })
			).json()) as {
				CreatorAccountId: number
				Roles: Role[]
			}

		// A room of account 1's to give away, and two accounts to try it with.
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 30701,
			Name: 'HandMeDown',
			CreatorAccountId: 1,
			Accessibility: 1,
			SubRooms: [],
			Roles: [{ AccountId: 1, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 }],
		})
		for (const accountId of [880, 881]) {
			await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
				.bind(JSON.stringify({ accountId, username: `Taker${accountId}` }))
				.run()
		}

		// No token → 401; a valid token that doesn't own the room → 403.
		expect((await putForm('/rooms/30701/creator', { accountId: '880' })).status).toBe(401)
		expect((await putForm('/rooms/30701/creator', { accountId: '880' }, '999')).status).toBe(403)
		// Unknown room → failure envelope.
		expect(
			await envOf(await putForm('/rooms/99999/creator', { accountId: '880' }, '1'))
		).toMatchObject({ success: false, error: 'This room does not exist!' })
		// No account, yourself, and a player who doesn't exist are each refused — a room
		// handed to a nonexistent account would be orphaned for good.
		expect(await envOf(await putForm('/rooms/30701/creator', {}, '1'))).toMatchObject({
			success: false,
		})
		expect(
			await envOf(await putForm('/rooms/30701/creator', { accountId: '1' }, '1'))
		).toMatchObject({ success: false, error: 'You already own this room!' })
		expect(
			await envOf(await putForm('/rooms/30701/creator', { accountId: '99998' }, '1'))
		).toMatchObject({ success: false, error: 'That player does not exist!' })
		expect((await roomOf(30701)).CreatorAccountId).toBe(1)

		// A pending lower-tier invite can outlive the ownership transfer.
		expect((await putForm('/rooms/30701/roles/880/invite', { role: '25' }, '1')).status).toBe(200)
		// The owner hands it to 880: they become Creator, the outgoing owner is left CoOwner,
		// and `CreatorAccountId` moves with them.
		const ok = await putForm('/rooms/30701/creator', { accountId: '880' }, '1')
		expect(ok.status).toBe(200)
		expect(await envOf(ok)).toMatchObject({ success: true, error: '' })

		const after = await roomOf(30701)
		expect(after.CreatorAccountId).toBe(880)
		expect(after.Roles).toContainEqual(
			expect.objectContaining({ AccountId: 880, Role: 255, LastChangedByAccountId: 1 })
		)
		expect(after.Roles).toContainEqual(
			expect.objectContaining({ AccountId: 1, Role: 30, LastChangedByAccountId: 1 })
		)
		const beforeAnswer = await storedRoleOf(30701, 880)
		for (const role of ['25', '0']) {
			expect(await envOf(await putForm('/rooms/30701/roles/880', { role }, '880'))).toMatchObject({ success: false })
		}
		expect(await storedRoleOf(30701, 880)).toEqual(beforeAnswer)

		// The old owner is a co-owner now, not the owner: they can no longer give the room
		// away — otherwise the transfer would have left it with two owners.
		expect((await putForm('/rooms/30701/creator', { accountId: '881' }, '1')).status).toBe(403)
		// The new owner can, and the room only ever has one Creator entry.
		expect((await putForm('/rooms/30701/creator', { accountId: '881' }, '880')).status).toBe(200)
		const handedOn = await roomOf(30701)
		expect(handedOn.CreatorAccountId).toBe(881)
		expect(handedOn.Roles.filter((r) => r.Role === 255)).toEqual([
			expect.objectContaining({ AccountId: 881 }),
		])
		expect(handedOn.Roles).toContainEqual(expect.objectContaining({ AccountId: 880, Role: 30 }))
	})

	it('PUT /rooms/:id/creator refuses a dorm, and pushes the room on a transfer', async () => {
		type Sent = { playerId: number; notificationType: string | number; data: { RoomId: number } }
		const hub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		const sent = async (): Promise<Sent[]> =>
			(await (await hub().fetch('http://do/all')).json()) as Sent[]

		// A dorm is found by its owner, so handing one over would give away somebody's
		// personal room and mint them a fresh empty one on next access.
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 30702,
			Name: 'SomeonesDorm',
			CreatorAccountId: 890,
			IsDorm: true,
			Accessibility: 2,
			SubRooms: [],
			Roles: [{ AccountId: 890, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 }],
		})
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 891, username: 'NotYourDorm' }))
			.run()

		expect(
			await envOf(await putForm('/rooms/30702/creator', { accountId: '891' }, '890'))
		).toMatchObject({ success: false, error: 'A dorm cannot be given away!' })
		const dorm = (await (
			await SELF.fetch(`${ORIGIN}/rooms/30702`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			CreatorAccountId: number
		}
		expect(dorm.CreatorAccountId).toBe(890)

		// A real transfer reaches everyone in the room plus both parties, wherever they are.
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 30703,
			Name: 'WatchedHandover',
			CreatorAccountId: 892,
			Accessibility: 1,
			SubRooms: [],
			Roles: [{ AccountId: 892, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 }],
		})
		await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
			.bind(JSON.stringify({ accountId: 893, username: 'NewOwner' }))
			.run()
		await putInRoom(894, 30703)
		await hub().fetch('http://do/all', { method: 'DELETE' })

		expect((await putForm('/rooms/30703/creator', { accountId: '893' }, '892')).status).toBe(200)

		const pushed = await sent()
		expect(pushed.map((n) => n.playerId).sort((a, b) => a - b)).toEqual([892, 893, 894])
		expect(
			pushed.every((n) => n.notificationType === NotificationType.SubscriptionUpdateRoom)
		).toBe(true)
		expect(pushed.every((n) => n.data.RoomId === 30703)).toBe(true)

		await clearPresence(894)
	})
})

it('GET /rooms/:id/similar ignores system tags on both sides', async () => {
		for (const RoomId of [97_101, 97_102, 97_103, 97_104, 97_105]) {
			await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
				.bind(JSON.stringify({ RoomId, Name: `Sim${RoomId}`, CreatorAccountId: 9710, Accessibility: 1 }))
				.run()
		}
		await env.DB.prepare(
			`INSERT INTO room_tag (room_id, tag, type) VALUES
			 (97101, 'limitsv2', 1),
			 (97102, 'limitsv2', 1), (97102, 'zzsimilar', 0),
			 (97103, 'limitsv2', 1), (97103, 'zzsimilar', 0),
			 (97104, 'beta', 0),
			 (97105, 'beta', 1)`
		).run()
		const similar = async (id: number) => {
			const res = await SELF.fetch(`${ORIGIN}/rooms/${id}/similar`)
			const body = (await res.json()) as { Results: Array<{ RoomId: number }>; TotalResults: number }
			return { ids: body.Results.map((r) => r.RoomId), total: body.TotalResults }
		}

		// Only system tags: nothing is similar, though three rooms share `limitsv2`.
		expect(await similar(97_101)).toEqual({ ids: [], total: 0 })
		// The user tag still matches, and the shared system tag adds no one else.
		expect(await similar(97_102)).toEqual({ ids: [97_103], total: 1 })
		// A user tag NAMED like a system tag doesn't match the rooms carrying the system one.
		expect((await similar(97_104)).ids).not.toContain(97_105)
	})

it('PUT /rooms/:id/image lets staff set a room they hold no role on (audited)', async () => {
		const imageName = 'staffset0000000000000000000000000.jpg'
		const put = async (roles: string[]) =>
			bodyOf(
				await SELF.fetch(`${ORIGIN}/rooms/2/image`, {
					method: 'PUT',
					headers: {
						...(await bearer('997', ['gameClient', ...roles])),
						'Content-Type': 'application/x-www-form-urlencoded',
					},
					body: new URLSearchParams({ imageName }).toString(),
				})
			)
		// A plain player is still refused; a moderator isn't.
		expect(await put([])).toMatchObject({ Success: false, ErrorId: 'Rooms.NotOwner' })
		expect(await put(['moderator'])).toMatchObject({ Success: true })

		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as { ImageName: string }
		expect(room.ImageName).toBe(imageName)

		const { results: audit } = await env.DB.prepare(
			'SELECT player_id, data FROM audit_log WHERE action = ?1'
		)
			.bind('room_image')
			.all<{ player_id: number; data: string }>()
		expect(audit).toHaveLength(1)
		expect(audit[0].player_id).toBe(997)
		expect(JSON.parse(audit[0].data)).toMatchObject({ roomId: 2, to: imageName })
	})
