// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { MessageType } from '@repo/domain'

import { NotificationType } from '../../../../notify/src/notification-types'
import {
	bearer,
	clearPresence,
	envOf,
	ORIGIN,
	postForm,
	putForm,
	putInRoom,
	setupSchema,
	storedRoleOf,
} from './support/harness'

beforeAll(setupSchema)

describe('rooms endpoints', () => {
	it('PUT /rooms/:id/roles/:accountId/invite records the offer and pushes the invite', async () => {
		type Sent = {
			playerId: number
			notificationType: string | number
			data: Record<string, unknown>
		}
		const hub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		const sent = async (): Promise<Sent[]> =>
			(await (await hub().fetch('http://do/all')).json()) as Sent[]
		const rolesOf = async (roomId: number) =>
			(await (await SELF.fetch(`${ORIGIN}/rooms/${roomId}/roles`)).json()) as Array<{
				AccountId: number
				Role: number
				InvitedRole: number
				LastChangedByAccountId: number | null
			}>

		// No token → 401 (auth gate).
		expect((await putForm('/rooms/2/roles/187/invite', { role: '30' })).status).toBe(401)
		// A valid token with no standing on the room → 403...
		expect((await putForm('/rooms/2/roles/187/invite', { role: '30' }, '999')).status).toBe(403)
		// A co-owner may invite lower roles, but may not hand out co-ownership.
		expect((await putForm('/rooms/2/roles/187/invite', { role: '30' }, '2')).status).toBe(403)
		expect((await putForm('/rooms/2/roles/187/invite', { role: '255' }, '2')).status).toBe(403)
		// An unknown room answers the same 403 rather than leaking that it doesn't exist.
		expect((await putForm('/rooms/99999/roles/187/invite', { role: '30' }, '1')).status).toBe(403)
		// A non-numeric role is a bad request — there is no envelope here to carry a message.
		expect((await putForm('/rooms/2/roles/187/invite', { role: 'nope' }, '1')).status).toBe(400)
		// None of the refusals wrote a role entry.
		expect((await rolesOf(2)).find((r) => r.AccountId === 187)).toBeUndefined()

		// The owner invites 187 to co-ownership.
		await hub().fetch('http://do/all', { method: 'DELETE' })
		const res = await putForm('/rooms/2/roles/187/invite', { role: '30' }, '1')
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })

		// A new entry, holding no role yet — only the pending offer, stamped with the inviter.
		// The role list shows it as a pending invite (the client lists pending invites from
		// it); the room DTO's `Roles` does not, until they accept.
		expect(await storedRoleOf(2, 187)).toEqual({
			Role: 0,
			InvitedRole: 30,
			LastChangedByAccountId: 1,
		})
		expect(await rolesOf(2)).toContainEqual({
			AccountId: 187,
			Role: 0,
			InvitedRole: 30,
			LastChangedByAccountId: 1,
		})
		const room2 = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			Roles: Array<{ AccountId: number }>
		}
		expect(room2.Roles.some((r) => r.AccountId === 187)).toBe(false)

		// One MessageReceived to the INVITED player carrying a type 62 RoomCoOwnerInvited —
		// the entry alone is silent, this is what raises the invite on their client.
		const pushed = await sent()
		expect(pushed).toHaveLength(1)
		expect(pushed[0].playerId).toBe(187)
		expect(pushed[0].notificationType).toBe(NotificationType.MessageReceived)
		expect(pushed[0].data).toMatchObject({
			FromPlayerId: 1,
			Type: MessageType.RoomCoOwnerInvited,
			// The offered role, as a string — what the client reads the tier off, and sends
			// back as `role` to accept.
			Data: '30',
			RoomId: 2,
			PlayerEventId: null,
		})
		// The invite is STORED before it is pushed, and the frame carries the row's id and
		// timestamp — so the invited player reads the same invite from their inbox
		// (`GET /api/messages/v2/get`) even if the push never reached them.
		const row = await env.DB.prepare(
			'SELECT notification_id, from_player_id, type, data, room_id, sent_time FROM notification WHERE to_player_id = 187'
		).first<{
			notification_id: number
			from_player_id: number
			type: number
			data: string | null
			room_id: number
			sent_time: string
		}>()
		expect(row).toMatchObject({
			from_player_id: 1,
			type: MessageType.RoomCoOwnerInvited,
			data: '30',
			room_id: 2,
		})
		expect(pushed[0].data.Id).toBe(row!.notification_id)
		expect(pushed[0].data.SentTime).toBe(row!.sent_time)
		expect(Date.parse(row!.sent_time)).not.toBeNaN()

		// Re-inviting someone who already has an entry sets the pending role in place rather
		// than adding a second entry — and leaves the role they already hold alone. 187
		// accepts the invite above first, so they hold a real role to be re-invited over.
		expect((await putForm('/rooms/2/roles/187', { role: '30' }, '187')).status).toBe(200)
		await putForm('/rooms/2/roles/187/invite', { role: '20' }, '1')
		const after = await rolesOf(2)
		expect(after.filter((r) => r.AccountId === 187)).toHaveLength(1)
		expect(after).toContainEqual({
			AccountId: 187,
			Role: 30,
			InvitedRole: 20,
			LastChangedByAccountId: 1,
		})
	})

	it('rejects malformed or empty role invitations without saving or notifying, while allowing future tiers', async () => {
		const hub = env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		await hub.fetch('http://do/all', { method: 'DELETE' })
		for (const role of ['', '0', '-1', '25junk', '25.5', '1e2', '9007199254740992']) {
			expect((await putForm('/rooms/2/roles/191/invite', { role }, '2')).status).toBe(400)
		}
		expect(await storedRoleOf(2, 191)).toBeUndefined()
		const notifications = await env.DB.prepare(
			'SELECT COUNT(*) AS n FROM notification WHERE to_player_id = 191'
		).first<{ n: number }>()
		expect(notifications?.n).toBe(0)
		expect(await (await hub.fetch('http://do/all')).json()).toEqual([])

		expect((await putForm('/rooms/2/roles/192/invite', { role: '26' }, '2')).status).toBe(200)
		expect(await storedRoleOf(2, 192)).toMatchObject({ Role: 0, InvitedRole: 26 })
	})

	it('does not let a co-owner invite the owner or a co-owner around role protections', async () => {
		expect((await putForm('/rooms/2/roles/193/invite', { role: '30' }, '1')).status).toBe(200)
		expect(await envOf(await putForm('/rooms/2/roles/193', { role: '30' }, '193'))).toMatchObject({ success: true })
		const beforeOwner = await storedRoleOf(2, 1)
		const beforePeer = await storedRoleOf(2, 193)
		const hub = env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		await hub.fetch('http://do/all', { method: 'DELETE' })
		expect((await putForm('/rooms/2/roles/1/invite', { role: '25' }, '2')).status).toBe(403)
		expect((await putForm('/rooms/2/roles/193/invite', { role: '25' }, '2')).status).toBe(403)
		expect(await storedRoleOf(2, 1)).toEqual(beforeOwner)
		expect(await storedRoleOf(2, 193)).toEqual(beforePeer)
		const notifications = await env.DB.prepare(
			"SELECT COUNT(*) AS n FROM notification WHERE to_player_id IN (1, 193) AND from_player_id = 2 AND data = '25'"
		).first<{ n: number }>()
		expect(notifications?.n).toBe(0)
		expect(await (await hub.fetch('http://do/all')).json()).toEqual([])
	})

	it('lets a co-owner invite a contributor who can accept the delivered offer', async () => {
		const res = await putForm('/rooms/2/roles/188/invite', { role: '25' }, '2')
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ success: true })
		expect(await storedRoleOf(2, 188)).toEqual({ Role: 0, InvitedRole: 25, LastChangedByAccountId: 2 })
		const message = await env.DB.prepare(
			'SELECT from_player_id, type, data, room_id FROM notification WHERE to_player_id = 188'
		).first()
		expect(message).toMatchObject({ from_player_id: 2, type: MessageType.RoomCoOwnerInvited, data: '25', room_id: 2 })
		expect((await putForm('/rooms/2/roles/188', { role: '25' }, '188')).status).toBe(200)
		expect(await storedRoleOf(2, 188)).toMatchObject({ Role: 25, InvitedRole: 0 })
	})

	it('POST /rooms/:id/bans is gated to the room’s owners or staff, and persists', async () => {
		// RecCenter (room 2) is owned by account 1, with account 2 as co-owner.
		const bansOf = async (roomId: number) =>
			(
				await env.DB.prepare(
					'SELECT banned_player_id, ban_mask, banned_by_account_id FROM room_ban WHERE room_id = ?1'
				)
					.bind(roomId)
					.all<{ banned_player_id: number; ban_mask: number; banned_by_account_id: number }>()
			).results

		// No token → 401 (auth gate).
		expect((await postForm('/rooms/2/bans', { banMask: '0', id: '205' })).status).toBe(401)
		// A valid token, no role on the room and no staff role → 403.
		expect((await postForm('/rooms/2/bans', { banMask: '0', id: '205' }, '999')).status).toBe(403)
		// Unknown room → failure envelope.
		expect(
			await envOf(await postForm('/rooms/99999/bans', { banMask: '0', id: '205' }, '1'))
		).toMatchObject({ success: false, error: 'This room does not exist!' })

		// The owner bans player 205 — the real client body.
		const ok = await postForm('/rooms/2/bans', { banMask: '0', id: '205' }, '1')
		expect(ok.status).toBe(200)
		expect(await envOf(ok)).toMatchObject({
			success: true,
			error: '',
			value: { RoomId: 2, BannedPlayerId: 205, BanMask: 0, BannedByAccountId: 1 },
		})
		expect(await bansOf(2)).toEqual([
			{ banned_player_id: 205, ban_mask: 0, banned_by_account_id: 1 },
		])

		// Re-banning rewrites the one row rather than appending a second.
		expect((await postForm('/rooms/2/bans', { banMask: '7', id: '205' }, '2')).status).toBe(200)
		expect(await bansOf(2)).toEqual([
			{ banned_player_id: 205, ban_mask: 7, banned_by_account_id: 2 },
		])

		// A staff token bans in a room they have no role on.
		const byStaff = await postForm('/rooms/2/bans', { id: '206' }, '999', [
			'gameClient',
			'moderator',
		])
		expect(byStaff.status).toBe(200)
		// banMask defaults to 0 when the field is absent.
		expect(await envOf(byStaff)).toMatchObject({ value: { BannedPlayerId: 206, BanMask: 0 } })

		// Refusals: no id, yourself, and an owner of the room (a co-owner must not be
		// able to ban the creator out of their own room).
		expect(await envOf(await postForm('/rooms/2/bans', { id: 'nope' }, '1'))).toMatchObject({
			success: false,
			value: null,
		})
		expect(await envOf(await postForm('/rooms/2/bans', { id: '1' }, '1'))).toMatchObject({
			success: false,
			error: 'You cannot ban yourself!',
		})
		expect(await envOf(await postForm('/rooms/2/bans', { id: '1' }, '2'))).toMatchObject({
			success: false,
			error: 'You cannot ban an owner of this room!',
		})
		// Nothing was written by any of the refusals.
		expect(await bansOf(2)).toHaveLength(2)
	})

	it('GET /Room_server/rooms/:id/bans/:playerId/isBanned answers the real ban state', async () => {
		const isBanned = async (roomId: number, playerId: number, sub = '300') =>
			SELF.fetch(`${ORIGIN}/Room_server/rooms/${roomId}/bans/${playerId}/isBanned`, {
				headers: await bearer(sub),
			})

		// Auth-gated, but any authenticated caller may ask — a ban is not a secret from the
		// player it stops.
		expect((await SELF.fetch(`${ORIGIN}/Room_server/rooms/2/bans/205/isBanned`)).status).toBe(401)

		// Nobody is banned from room 3.
		const clean = await isBanned(3, 4242)
		expect(clean.status).toBe(200)
		// `success` says the CHECK ran; `value` is the answer. Note `error_id` is present and
		// `error` is null — not the room mutations' `{ success, error, value }` with `""`.
		expect(await clean.json()).toEqual({
			success: true,
			error: null,
			error_id: null,
			value: false,
		})

		// Ban someone from room 3, and the same call now says so.
		await env.DB.prepare(
			'INSERT INTO room_ban (room_id, banned_player_id, ban_mask, banned_by_account_id, created_at)' +
				" VALUES (?1, ?2, 0, 1, '2026-01-01T00:00:00Z')"
		)
			.bind(3, 4242)
			.run()
		expect(await (await isBanned(3, 4242)).json()).toMatchObject({ success: true, value: true })

		// The ban is per (room, player): another room and another player are unaffected.
		expect(await (await isBanned(2, 4242)).json()).toMatchObject({ value: false })
		expect(await (await isBanned(3, 4243)).json()).toMatchObject({ value: false })

		await env.DB.prepare('DELETE FROM room_ban WHERE room_id = ?1 AND banned_player_id = ?2')
			.bind(3, 4242)
			.run()
	})

	it('GET /rooms/:id/bans/:playerId/isBanned answers the same check, PascalCase', async () => {
		const isBanned = async (roomId: number, playerId: number) =>
			SELF.fetch(`${ORIGIN}/rooms/${roomId}/bans/${playerId}/isBanned`, {
				headers: await bearer('300'),
			})

		// Same gate as the `/Room_server/` spelling: a token is needed, any token will do.
		expect((await SELF.fetch(`${ORIGIN}/rooms/112/bans/1/isBanned`)).status).toBe(401)

		const clean = await isBanned(112, 1)
		expect(clean.status).toBe(200)
		// PascalCase — `Value`/`Success`/`Error`, and `error_id` lowercase all the same. The
		// client's decoder drops members it doesn't recognise, so the other route's lowercase
		// keys here would decode as `false` rather than fail. Room 112 does not exist and the
		// answer is still a clean `false`: the question is about the ban row, not the room.
		expect(await clean.json()).toEqual({
			Value: false,
			Success: true,
			Error: null,
			error_id: null,
		})

		// The same `room_ban` rows the other route and `match` read.
		await env.DB.prepare(
			'INSERT INTO room_ban (room_id, banned_player_id, ban_mask, banned_by_account_id, created_at)' +
				" VALUES (?1, ?2, 0, 1, '2026-01-01T00:00:00Z')"
		)
			.bind(112, 1)
			.run()
		expect(await (await isBanned(112, 1)).json()).toEqual({
			Value: true,
			Success: true,
			Error: null,
			error_id: null,
		})

		// Per (room, player), like every other read of these rows.
		expect(await (await isBanned(113, 1)).json()).toMatchObject({ Value: false })
		expect(await (await isBanned(112, 2)).json()).toMatchObject({ Value: false })

		// …and the prefixed route sees the same ban, in its own lowercase envelope.
		const prefixed = await SELF.fetch(`${ORIGIN}/Room_server/rooms/112/bans/1/isBanned`, {
			headers: await bearer('300'),
		})
		expect(await prefixed.json()).toEqual({
			success: true,
			error: null,
			error_id: null,
			value: true,
		})

		await env.DB.prepare('DELETE FROM room_ban WHERE room_id = ?1 AND banned_player_id = ?2')
			.bind(112, 1)
			.run()
	})

	it('GET/PUT /rooms/:id/playerdata/me stores and serves the caller’s per-room data', async () => {
		const get = async (path: string, sub?: string) =>
			SELF.fetch(`${ORIGIN}${path}`, { headers: sub ? await bearer(sub) : {} })
		const rowsOf = async (roomId: number) =>
			(
				await env.DB.prepare(
					'SELECT player_id, data FROM playerdata WHERE room_id = ?1 ORDER BY player_id'
				)
					.bind(roomId)
					.all()
			).results

		// The real client body, verbatim: a base64 blob the server stores without decoding.
		const blob = 'CAVKGhoYChIKEPpVnzZ50iJLpI8BPCdUjjoaAhAAUggKAAoACgAKAA=='

		// No token → 401 on both: the data is the caller's own.
		expect((await get('/rooms/2/playerdata/me')).status).toBe(401)
		expect((await putForm('/rooms/2/playerdata/me', { data: blob })).status).toBe(401)
		// Unknown room → 404 on the write; the read serves an empty blob (a 404 would stall
		// the room load).
		expect((await putForm('/rooms/99999/playerdata/me', { data: blob }, '205')).status).toBe(404)
		expect(await (await get('/rooms/99999/playerdata/me', '205')).json()).toEqual({ Data: '' })

		// Nothing saved yet → empty `Data`.
		expect(await (await get('/rooms/2/playerdata/me', '205')).json()).toEqual({ Data: '' })

		// Any player may save to any room — 205 owns nothing here. The reply carries what
		// was stored, and the GET reads it back verbatim.
		const put = await putForm('/rooms/2/playerdata/me', { data: blob }, '205')
		expect(put.status).toBe(200)
		expect(await put.json()).toEqual({ Data: blob })
		expect(await (await get('/rooms/2/playerdata/me', '205')).json()).toEqual({ Data: blob })
		expect(await rowsOf(2)).toEqual([{ player_id: 205, data: blob }])

		// A re-save overwrites the one row rather than appending.
		expect(await (await putForm('/rooms/2/playerdata/me', { data: 'CAA=' }, '205')).json()).toEqual(
			{ Data: 'CAA=' }
		)
		expect(await rowsOf(2)).toEqual([{ player_id: 205, data: 'CAA=' }])

		// Keyed per (room, player): another player and another room are their own rows,
		// and neither reads the other's.
		expect((await putForm('/rooms/2/playerdata/me', { data: blob }, '1')).status).toBe(200)
		expect((await putForm('/rooms/3/playerdata/me', { data: blob }, '205')).status).toBe(200)
		expect(await rowsOf(2)).toEqual([
			{ player_id: 1, data: blob },
			{ player_id: 205, data: 'CAA=' },
		])
		expect(await (await get('/rooms/3/playerdata/me', '205')).json()).toEqual({ Data: blob })
		expect(await (await get('/rooms/3/playerdata/me', '1')).json()).toEqual({ Data: '' })

		await env.DB.prepare('DELETE FROM playerdata WHERE room_id IN (2, 3)').run()
	})

	it('POST/DELETE /rooms/:id/leaderboards/:lid configures and removes a room’s leaderboard slots', async () => {
		// RecCenter (room 2) is owned by account 1, with account 2 as co-owner.
		const del = async (path: string, sub?: string) =>
			SELF.fetch(`${ORIGIN}${path}`, {
				method: 'DELETE',
				headers: sub ? await bearer(sub) : {},
			})
		const slotsOf = async (roomId: number) =>
			(
				await env.DB.prepare(
					'SELECT leaderboard_id, leaderboard_title, stat_format, sort_ascending FROM room_leaderboard WHERE room_id = ?1 ORDER BY leaderboard_id'
				)
					.bind(roomId)
					.all()
			).results

		// The real client body, verbatim.
		const body = { leaderboardTitle: 'full name', statFormat: '1', sortAscending: 'False' }

		// No token → 401 (auth gate).
		expect((await postForm('/rooms/2/leaderboards/1', body)).status).toBe(401)
		expect((await del('/rooms/2/leaderboards/1')).status).toBe(401)
		// A valid token but no role on the room → 403.
		expect((await postForm('/rooms/2/leaderboards/1', body, '999')).status).toBe(403)
		expect((await del('/rooms/2/leaderboards/1', '999')).status).toBe(403)
		// The envelope both routes answer — PascalCase `Success`/`Error`, lowercase
		// `error_id`, no entity. NOT the room mutations' lowercase `{ success, error, value }`.
		const OK = { Success: true, Error: null, error_id: null }

		// Unknown room → failure envelope.
		expect(await (await postForm('/rooms/99999/leaderboards/1', body, '1')).json()).toEqual({
			Success: false,
			Error: 'This room does not exist!',
			error_id: null,
		})

		// The owner configures slot 1 — a bare success, with the row persisted.
		const ok = await postForm('/rooms/2/leaderboards/1', body, '1')
		expect(ok.status).toBe(200)
		expect(await ok.json()).toEqual(OK)
		expect(await slotsOf(2)).toEqual([
			{ leaderboard_id: 1, leaderboard_title: 'full name', stat_format: 1, sort_ascending: 0 },
		])

		// Re-posting the slot reconfigures the one row rather than appending — and the
		// co-owner may do it. `sortAscending=True` parses case-insensitively.
		const rewrite = await postForm(
			'/rooms/2/leaderboards/1',
			{ leaderboardTitle: 'lap time', statFormat: '2', sortAscending: 'True' },
			'2'
		)
		expect(rewrite.status).toBe(200)
		expect(await rewrite.json()).toEqual(OK)
		expect(await slotsOf(2)).toEqual([
			{ leaderboard_id: 1, leaderboard_title: 'lap time', stat_format: 2, sort_ascending: 1 },
		])

		// Slots are per room: slot 2 here and slot 1 of another room are their own rows.
		expect((await postForm('/rooms/2/leaderboards/2', body, '1')).status).toBe(200)
		expect((await postForm('/rooms/3/leaderboards/1', body, '1')).status).toBe(200)
		expect(await slotsOf(2)).toHaveLength(2)
		expect(await slotsOf(3)).toHaveLength(1)

		// DELETE removes exactly the named slot.
		const removed = await del('/rooms/2/leaderboards/1', '1')
		expect(removed.status).toBe(200)
		expect(await removed.json()).toEqual(OK)
		expect(await slotsOf(2)).toEqual([
			{ leaderboard_id: 2, leaderboard_title: 'full name', stat_format: 1, sort_ascending: 0 },
		])
		expect(await slotsOf(3)).toHaveLength(1)

		// Deleting a slot that isn't configured is a rejection, not an HTTP error — the
		// client tears boards down by deleting every slot blindly.
		expect(await (await del('/rooms/2/leaderboards/1', '1')).json()).toEqual({
			Success: false,
			Error: 'This room has no such leaderboard!',
			error_id: null,
		})

		// Clean up the surviving rows so this test leaves no trace.
		await env.DB.prepare('DELETE FROM room_leaderboard WHERE room_id IN (2, 3)').run()
	})

	it('POST/DELETE /rooms/:id/leaderboards/:lid refuse with an HTTP status for 2026', async () => {
		// 20260323 never reads these bodies, so a 200 `Success: false` would read as success.
		const as2026 = async (sub: string) => ({
			...(await bearer(sub, undefined, '20260323.14')),
		})
		const body = { leaderboardTitle: 'full name', statFormat: '1', sortAscending: 'False' }
		const form = new URLSearchParams(body).toString()
		const send = async (method: string, path: string, headers: Record<string, string>) =>
			SELF.fetch(`${ORIGIN}${path}`, {
				method,
				headers: { ...headers, 'Content-Type': 'application/x-www-form-urlencoded' },
				...(method === 'POST' && { body: form }),
			})

		// Unknown room: 404 for 2026, both verbs, never 200 + Success:false.
		const create = await send('POST', '/rooms/99999/leaderboards/1', await as2026('1'))
		expect(create.status).toBe(404)
		expect((await send('DELETE', '/rooms/99999/leaderboards/1', await as2026('1'))).status).toBe(
			404
		)

		// 2025 keeps the 200 failure envelope it parses.
		const legacy = await send(
			'POST',
			'/rooms/99999/leaderboards/1',
			await bearer('1', undefined, '20250718.01')
		)
		expect(legacy.status).toBe(200)
		expect(await legacy.json()).toEqual({
			Success: false,
			Error: 'This room does not exist!',
			error_id: null,
		})

		// A real create still succeeds for 2026, and the denial paths stay 401/403.
		expect((await send('POST', '/rooms/2/leaderboards/1', await as2026('1'))).status).toBe(200)
		expect((await send('POST', '/rooms/2/leaderboards/1', await as2026('999'))).status).toBe(403)
		// An unconfigured slot is already gone, which is what the delete asked for.
		expect((await send('DELETE', '/rooms/2/leaderboards/7', await as2026('1'))).status).toBe(200)

		await env.DB.prepare('DELETE FROM room_leaderboard WHERE room_id = 2').run()
	})

	it('POST /rooms/:id/experience sets a room’s progression, which the GETs read back', async () => {
		// RecCenter (room 2) is owned by account 1, with account 2 as co-owner.
		const getXp = async (roomId: number, sub?: string) =>
			SELF.fetch(`${ORIGIN}/rooms/${roomId}/experience/player`, {
				headers: sub ? await bearer(sub) : {},
			})
		// The real client body, verbatim.
		const body = { enabled: 'True', dailyLimit: '1000' }
		// The same bare envelope as the leaderboard write.
		const OK = { Success: true, Error: null, error_id: null }

		// No token → 401; a valid token but no role on the room → 403.
		expect((await postForm('/rooms/2/experience', body)).status).toBe(401)
		expect((await postForm('/rooms/2/experience', body, '999')).status).toBe(403)
		// Unknown room → failure envelope, not a 404.
		expect(await (await postForm('/rooms/99999/experience', body, '1')).json()).toEqual({
			Success: false,
			Error: 'This room does not exist!',
			error_id: null,
		})

		// The owner turns it on, and the room-level GET reads it back as a bare pair.
		const ok = await postForm('/rooms/2/experience', body, '1')
		expect(ok.status).toBe(200)
		expect(await ok.json()).toEqual(OK)
		expect(await (await SELF.fetch(`${ORIGIN}/rooms/2/experience`)).json()).toEqual({
			Enabled: true,
			DailyLimit: 1000,
		})
		// It lands on the room blob under the names the room DTO carries.
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as Record<string, unknown>
		expect(room).toMatchObject({ progressionEnabled: true, progressionDailyLimit: 1000 })

		// The per-player read is auth-gated, 404 for no such room, and echoes the switch. A
		// player with no XP recorded here is 0 — and nothing is written by reading. The
		// `ConcurrencyCode` is a GUID minted per response, not stored.
		expect((await getXp(2)).status).toBe(401)
		expect((await getXp(99999, '999')).status).toBe(404)
		const fresh = (await (await getXp(2, '999')).json()) as {
			RoomExperienceEnabled: boolean
			Experience: number
			ConcurrencyCode: string
		}
		expect(fresh).toMatchObject({ RoomExperienceEnabled: true, Experience: 0 })
		expect(fresh.ConcurrencyCode).toMatch(/^[0-9a-f-]{36}$/)
		expect(
			await env.DB.prepare('SELECT 1 FROM room_xp WHERE room_id = 2 AND player_id = 999').first()
		).toBeNull()

		// The increment write creates the row on first use and answers the read's DTO with the
		// new total, wrapped in the leaderboard write's envelope — the read serves it bare. The
		// real client body, verbatim; the code is accepted and ignored.
		const add = { increment: '2500', concurrencyCode: '79e10fb4-1956-4251-b482-9f21d76c3776' }
		const addXp = async (roomId: number, fields: Record<string, string>, sub: string) =>
			(await (await postForm(`/rooms/${roomId}/experience/player`, fields, sub)).json()) as {
				Value: { RoomExperienceEnabled: boolean; Experience: number; ConcurrencyCode: string }
				Success: boolean
				Error: string | null
				error_id: string | null
			}
		expect((await postForm('/rooms/2/experience/player', add)).status).toBe(401)
		expect((await postForm('/rooms/99999/experience/player', add, '999')).status).toBe(404)
		const added = await addXp(2, add, '999')
		expect(added).toMatchObject({
			Value: { RoomExperienceEnabled: true, Experience: 2500 },
			Success: true,
			Error: null,
			error_id: null,
		})
		expect(added.Value.ConcurrencyCode).toMatch(/^[0-9a-f-]{36}$/)
		// It accumulates, per (room, player); the read serves the running total.
		expect((await addXp(2, { increment: '250' }, '999')).Value.Experience).toBe(2750)
		expect((await addXp(3, { increment: '1' }, '999')).Value.Experience).toBe(1)
		expect(await (await getXp(2, '999')).json()).toMatchObject({
			RoomExperienceEnabled: true,
			Experience: 2750,
		})
		// A missing increment adds nothing.
		expect((await addXp(2, {}, '999')).Value.Experience).toBe(2750)

		// A stored row serves its XP.
		await env.DB.prepare('UPDATE room_xp SET xp = 1250 WHERE room_id = 2 AND player_id = 999').run()
		expect(await (await getXp(2, '999')).json()).toMatchObject({
			RoomExperienceEnabled: true,
			Experience: 1250,
		})

		// The co-owner may turn it off; `enabled` parses case-insensitively, and a missing
		// or non-numeric `dailyLimit` is 0. Off is echoed to the per-player read.
		expect(await (await postForm('/rooms/2/experience', { enabled: 'false' }, '2')).json()).toEqual(
			OK
		)
		expect(await (await SELF.fetch(`${ORIGIN}/rooms/2/experience`)).json()).toEqual({
			Enabled: false,
			DailyLimit: 0,
		})
		expect(await (await getXp(2, '999')).json()).toMatchObject({
			RoomExperienceEnabled: false,
			Experience: 1250,
		})

		await env.DB.prepare('DELETE FROM room_xp WHERE player_id = 999').run()
	})

	it('POST /rooms/:id/bans takes a reason and a duration', async () => {
		type Ban = { Reason: string | null; ExpiresAt: string | null; CreatedAt: string }
		type Sent = { playerIds: number[]; data: { duration: number; isBan: boolean; message: string } }
		const hub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		await hub().fetch('http://do/all', { method: 'DELETE' })
		// Standing in the room, so there is a session to kick them out of.
		await putInRoom(310, 2)

		// The client's body, verbatim.
		const res = await postForm(
			'/rooms/2/bans',
			{ banMask: '0', id: '310', reason: 'test', durationMinutes: '30' },
			'1'
		)
		const body = (await envOf(res)) as unknown as { success: boolean; value: Ban }
		expect(body).toMatchObject({ success: true, value: { BannedPlayerId: 310, Reason: 'test' } })
		// Lapses thirty minutes after it was issued, to the second.
		expect(Date.parse(body.value.ExpiresAt!) - Date.parse(body.value.CreatedAt)).toBe(30 * 60_000)

		// The kick carries the reason in its message — but NOT the ban's length, and is not a
		// ban frame: a duration with `isBan` is what the client shows as a timed GAME ban.
		const [kick] = (await (await hub().fetch('http://do/all')).json()) as Sent[]
		expect(kick.playerIds).toEqual([310])
		expect(kick.data).toMatchObject({ duration: 0, isBan: false })
		expect(kick.data.message).toMatch(/Reason: test$/)

		// Neither field is required: no duration is a permanent ban, and it still pushes 0.
		const permanent = (await envOf(
			await postForm('/rooms/2/bans', { banMask: '0', id: '311' }, '1')
		)) as unknown as { value: Ban }
		expect(permanent.value).toMatchObject({ Reason: null, ExpiresAt: null })
		for (const d of ['', '0']) {
			const v = (await envOf(
				await postForm('/rooms/2/bans', { id: '312', durationMinutes: d }, '1')
			)) as unknown as { value: Ban }
			expect(v.value.ExpiresAt, d).toBeNull()
		}

		// A re-ban REPLACES the duration and reason — it neither extends nor keeps the old ones.
		const rebanned = (await envOf(
			await postForm('/rooms/2/bans', { id: '310' }, '1')
		)) as unknown as { value: Ban }
		expect(rebanned.value).toMatchObject({ Reason: null, ExpiresAt: null })
	})

	it('POST /rooms/:id/bans moves the banned player out of that room, into their dorm', async () => {
		const presenceOf = (accountId: number) =>
			env.DB.prepare(
				`SELECT room_id, json_extract(data, '$.roomInstance.roomInstanceId') AS instance
				 FROM presence WHERE account_id = ?1`
			)
				.bind(accountId)
				.first<{ room_id: number; instance: number }>()
		const instanceId = 1000002 // what `putInRoom` puts room 2's players in
		const isFull = async () =>
			(
				await env.DB.prepare('SELECT is_full FROM room_instance WHERE id = ?1')
					.bind(instanceId)
					.first<{ is_full: number }>()
			)?.is_full

		// A one-seat instance of room 2 that 320 is filling.
		await env.DB.prepare('INSERT INTO room_instance (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					roomInstanceId: instanceId,
					roomId: 2,
					subRoomId: 2,
					maxCapacity: 1,
					isFull: true,
				})
			)
			.run()
		await putInRoom(320, 2)
		// 321 is standing in a DIFFERENT room.
		await putInRoom(321, 4)

		expect((await postForm('/rooms/2/bans', { banMask: '0', id: '320' }, '1')).status).toBe(200)
		// Out of the room they were banned from, and the seat they held is free again. Their
		// presence is REWRITTEN to their own dorm rather than deleted: with none to read, the
		// client arrives at the dorm not knowing where it is and loads it a second time.
		const moved = await presenceOf(320)
		expect(moved).not.toBeNull()
		expect(moved!.room_id).not.toBe(2)
		// The OFFLINE dorm sentinel, not a live dorm session minted per ban.
		expect(moved!.instance).toBe(-2)
		expect(await isFull()).toBe(0)

		// A ban from room 2 does not knock someone offline from room 4.
		expect((await postForm('/rooms/2/bans', { banMask: '0', id: '321' }, '1')).status).toBe(200)
		expect((await presenceOf(321))?.room_id).toBe(4)

		await clearPresence(321)
		await env.DB.prepare('DELETE FROM room_instance WHERE id = ?1').bind(instanceId).run()
	})

	it('POST /rooms/:id/bans refuses a duration it cannot read, rather than banning forever', async () => {
		for (const durationMinutes of ['thirty', '-5', '1.5']) {
			expect(
				await envOf(await postForm('/rooms/2/bans', { id: '313', durationMinutes }, '1')),
				durationMinutes
			).toMatchObject({ success: false, error: 'You must provide a valid ban duration!' })
		}
		const row = await env.DB.prepare(
			'SELECT 1 FROM room_ban WHERE room_id = 2 AND banned_player_id = 313'
		).first()
		expect(row).toBeNull()
	})

	it('a lapsed room ban stops counting everywhere without being lifted', async () => {
		// Written straight to the table: an hour-long ban issued two hours ago.
		const issued = new Date(Date.now() - 2 * 3_600_000)
		await env.DB.prepare(
			`INSERT INTO room_ban
				 (room_id, banned_player_id, ban_mask, banned_by_account_id, created_at, reason, expires_at)
			 VALUES (2, 314, 0, 1, ?1, 'old', ?2)`
		)
			.bind(issued.toISOString(), new Date(issued.getTime() + 3_600_000).toISOString())
			.run()

		// `isBanned` — the same check `match` refuses matchmakes on.
		const isBanned = await SELF.fetch(`${ORIGIN}/rooms/2/bans/314/isBanned`, {
			headers: await bearer('314'),
		})
		expect(await isBanned.json()).toMatchObject({ Value: false })

		// Not in the ban list.
		const list = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2/bans`, { headers: await bearer('1') })
		).json()) as Array<{ accountId: number }>
		expect(list.some((b) => b.accountId === 314)).toBe(false)

		// Unbanning it is "not banned", like any other player who isn't.
		const unban = await SELF.fetch(`${ORIGIN}/rooms/2/bans/314`, {
			method: 'DELETE',
			headers: await bearer('1'),
		})
		expect(await unban.json()).toMatchObject({ success: false })

		// A ban still in force DOES count — the filter is on the expiry, not on having one.
		expect(
			(await postForm('/rooms/2/bans', { id: '315', durationMinutes: '30' }, '1')).status
		).toBe(200)
		const stillBanned = await SELF.fetch(`${ORIGIN}/rooms/2/bans/315/isBanned`, {
			headers: await bearer('315'),
		})
		expect(await stillBanned.json()).toMatchObject({ Value: true })
	})

	it('POST /rooms/:id/bans kicks a banned player out of the room — without banning them from the game', async () => {
		type Sent = {
			playerId?: number
			playerIds?: number[]
			ephemeral?: boolean
			notificationType: string | number
			data: unknown
		}
		const hub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
		const sentSince = async (): Promise<Sent[]> =>
			(await (await hub().fetch('http://do/all')).json()) as Sent[]

		// The room's current name, read rather than hardcoded — earlier tests rename it.
		const { Name } = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as { Name: string }

		await putInRoom(207, 2)
		await hub().fetch('http://do/all', { method: 'DELETE' })
		expect((await postForm('/rooms/2/bans', { banMask: '0', id: '207' }, '1')).status).toBe(200)

		// One EPHEMERAL ModerationKick to the banned player, out of the instance they were in.
		// Asserted against the enum rather than a literal: the ids are notify's to change.
		expect(await sentSince()).toEqual([
			{
				playerIds: [207],
				ephemeral: true,
				notificationType: NotificationType.ModerationKick,
				// The client's moderation payload, camelCase, in wire order.
				data: {
					reportCategory: -1, // Moderator — a person acted, not the system
					duration: 0,
					gameSessionId: 1000002, // the instance `putInRoom` stood them in
					// Account 1 owns RecCenter, so it hosts it.
					isHostKick: true,
					message: `You have been banned from ${Name}.`,
					playerIdReporter: 1,
					// FALSE. `isBan: true` is what the client shows as a ban from the whole game
					// — the account ban's frame. A room ban is enforced by the row, when `match`
					// refuses them the room; this frame only ejects them from the session.
					isBan: false,
					isVoiceModAutoban: false,
				},
			},
		])

		// A staff moderator doesn't host the room, so it isn't a host kick — and
		// `playerIdReporter` is still whoever caused it.
		await putInRoom(208, 2)
		await hub().fetch('http://do/all', { method: 'DELETE' })
		expect(
			(await postForm('/rooms/2/bans', { id: '208' }, '999', ['gameClient', 'moderator'])).status
		).toBe(200)
		expect((await sentSince())[0]).toMatchObject({
			playerIds: [208],
			data: { isHostKick: false, playerIdReporter: 999, isBan: false },
		})

		// A player who is NOT in the room has nothing to be kicked out of, and hears NOTHING —
		// not now, and not queued for their next connect, which is how a room ban once greeted
		// players with a ban screen on login.
		await putInRoom(216, 4)
		await hub().fetch('http://do/all', { method: 'DELETE' })
		expect((await postForm('/rooms/2/bans', { id: '216' }, '1')).status).toBe(200)
		expect((await postForm('/rooms/2/bans', { id: '217' }, '1')).status).toBe(200)
		expect(await sentSince()).toEqual([])

		for (const id of [216]) await clearPresence(id)
	})

	it('GET /rooms/:id/bans lists the room’s bans, under the same gate', async () => {
		type Entry = { accountId: number; bannedByAccountId: number; banStartTime: string }
		const list = async (path: string, sub?: string, roles?: string[]) =>
			SELF.fetch(`${ORIGIN}${path}`, { headers: sub ? await bearer(sub, roles) : {} })

		// Room 3 is owned by account 1 (it has no bans yet) — ban two players into it.
		expect((await postForm('/rooms/3/bans', { id: '401' }, '1')).status).toBe(200)
		expect((await postForm('/rooms/3/bans', { id: '402' }, '1')).status).toBe(200)

		// No token → 401; a valid token with no room role and no staff role → 403.
		expect((await list('/rooms/3/bans')).status).toBe(401)
		expect((await list('/rooms/3/bans', '999')).status).toBe(403)

		const res = await list('/rooms/3/bans', '1')
		expect(res.status).toBe(200)
		// A bare array in the client's camelCase shape — no room id, no ban mask.
		const bans = (await res.json()) as Entry[]
		expect(bans.map((b) => b.accountId).sort((a, b) => a - b)).toEqual([401, 402])
		expect(bans[0]).toEqual({
			accountId: expect.any(Number),
			bannedByAccountId: 1,
			banStartTime: expect.stringMatching(/^\d{4}-\d{2}-\d{2}T/),
		})

		// A staffer can read a list for a room they have no role on.
		expect((await list('/rooms/3/bans', '999', ['gameClient', 'moderator'])).status).toBe(200)

		// An unknown room reads the same as a room with nobody banned — no probing which
		// room ids exist.
		expect(await (await list('/rooms/99999/bans', '1')).json()).toEqual([])
	})

	it('GET /rooms/:id/bans/history serves the client’s exact shape', async () => {
		const history = async (playerId: number) =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/2/bans/history?id=${playerId}`, {
					headers: await bearer('1'),
				})
			).json()) as {
				Value: {
					ActiveBan: Record<string, unknown> | null
					PreviousBans: Array<Record<string, unknown>>
				}
				Success: boolean
				Error: string | null
				error_id: string | null
			}

		expect(
			(await postForm('/rooms/2/bans', { banMask: '0', id: '340', reason: 'test' }, '1')).status
		).toBe(200)
		const body = await history(340)

		// The envelope, PascalCase with a lowercase `error_id`, and a Value of exactly two keys.
		expect(Object.keys(body)).toEqual(['Value', 'Success', 'Error', 'error_id'])
		expect(body).toMatchObject({ Success: true, Error: null, error_id: null })
		expect(Object.keys(body.Value)).toEqual(['ActiveBan', 'PreviousBans'])

		// Seven keys in the CLIENT'S order — derived members first, so AccountId is fifth.
		const active = body.Value.ActiveBan!
		expect(Object.keys(active)).toEqual([
			'Status',
			'UnbannedByAccountId',
			'BanEndTime',
			'Reason',
			'AccountId',
			'BannedByAccountId',
			'BanStartTime',
		])
		expect(active).toMatchObject({
			Status: 0, // Active
			UnbannedByAccountId: null,
			BanEndTime: null, // permanent
			Reason: 'test',
			AccountId: 340,
			BannedByAccountId: 1,
		})
		// UTC to the second, as the client's example carries it.
		expect(active.BanStartTime).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/)
		expect(body.Value.PreviousBans).toEqual([])

		// A ban with no reason is `""`, never null; a timed one carries its scheduled end.
		expect(
			(await postForm('/rooms/2/bans', { id: '341', durationMinutes: '30' }, '1')).status
		).toBe(200)
		const timed = (await history(341)).Value.ActiveBan!
		expect(timed.Reason).toBe('')
		expect(Date.parse(timed.BanEndTime as string) - Date.parse(timed.BanStartTime as string)).toBe(
			30 * 60_000
		)

		// Someone never banned has no history at all.
		expect((await history(349)).Value).toEqual({ ActiveBan: null, PreviousBans: [] })
	})

	it('GET /rooms/:id/bans/history keeps lifted and elapsed bans, newest first', async () => {
		type Rec = {
			Status: number
			UnbannedByAccountId: number | null
			BanEndTime: string | null
			Reason: string
		}
		const history = async (playerId: number) =>
			(
				(await (
					await SELF.fetch(`${ORIGIN}/rooms/2/bans/history?id=${playerId}`, {
						headers: await bearer('1'),
					})
				).json()) as { Value: { ActiveBan: Rec | null; PreviousBans: Rec[] } }
			).Value
		const unban = async (playerId: number, sub: string) =>
			SELF.fetch(`${ORIGIN}/rooms/2/bans/${playerId}`, {
				method: 'DELETE',
				headers: await bearer(sub),
			})

		// LIFTED: banned by the owner, unbanned early by the co-owner.
		expect((await postForm('/rooms/2/bans', { id: '342', reason: 'first' }, '1')).status).toBe(200)
		expect((await unban(342, '2')).status).toBe(200)
		let h = await history(342)
		expect(h.ActiveBan).toBeNull()
		expect(h.PreviousBans).toHaveLength(1)
		expect(h.PreviousBans[0]).toMatchObject({ Status: 2, UnbannedByAccountId: 2, Reason: 'first' })
		expect(h.PreviousBans[0].BanEndTime).not.toBeNull()

		// Banned and lifted again: two previous bans, the newest first.
		expect((await postForm('/rooms/2/bans', { id: '342', reason: 'second' }, '1')).status).toBe(200)
		expect((await unban(342, '1')).status).toBe(200)
		h = await history(342)
		expect(h.PreviousBans.map((b) => b.Reason)).toEqual(['second', 'first'])

		// ELAPSED: a one-hour ban issued two hours ago, never touched since. It is not active,
		// and it is already reported as a previous ban before anything files it.
		const issued = new Date(Date.now() - 2 * 3_600_000)
		const expired = new Date(issued.getTime() + 3_600_000).toISOString()
		await env.DB.prepare(
			`INSERT INTO room_ban
				 (room_id, banned_player_id, ban_mask, banned_by_account_id, created_at, reason, expires_at)
			 VALUES (2, 343, 0, 1, ?1, 'lapsed', ?2)`
		)
			.bind(issued.toISOString(), expired)
			.run()
		h = await history(343)
		expect(h.ActiveBan).toBeNull()
		expect(h.PreviousBans).toEqual([
			expect.objectContaining({ Status: 1, UnbannedByAccountId: null, Reason: 'lapsed' }),
		])

		// A new ban replaces the stale row — and FILES the lapsed one, exactly once, rather than
		// losing it or counting it twice.
		expect((await postForm('/rooms/2/bans', { id: '343', reason: 'again' }, '1')).status).toBe(200)
		h = await history(343)
		expect(h.ActiveBan).toMatchObject({ Status: 0, Reason: 'again' })
		expect(h.PreviousBans).toEqual([
			expect.objectContaining({ Status: 1, UnbannedByAccountId: null, Reason: 'lapsed' }),
		])
		// Elapsed at its expiry, not at the moment it was replaced.
		expect(Date.parse(h.PreviousBans[0].BanEndTime!)).toBe(
			Math.floor(Date.parse(expired) / 1000) * 1000
		)

		// Re-issuing a ban still in force AMENDS it: one active ban, nothing filed.
		expect((await postForm('/rooms/2/bans', { id: '344', reason: 'v1' }, '1')).status).toBe(200)
		expect((await postForm('/rooms/2/bans', { id: '344', reason: 'v2' }, '2')).status).toBe(200)
		h = await history(344)
		expect(h.ActiveBan).toMatchObject({ Reason: 'v2' })
		expect(h.PreviousBans).toEqual([])

		// The bulk unban files a lift the same way the single one does.
		await SELF.fetch(`${ORIGIN}/rooms/2/bans/bulk`, {
			method: 'DELETE',
			headers: { 'content-type': 'application/x-www-form-urlencoded', ...(await bearer('1')) },
			body: 'banMask=0&id=344',
		})
		h = await history(344)
		expect(h.ActiveBan).toBeNull()
		expect(h.PreviousBans).toEqual([
			expect.objectContaining({ Status: 2, UnbannedByAccountId: 1, Reason: 'v2' }),
		])
	})

	it('GET /rooms/:id/bans/history is gated like the ban list', async () => {
		const get = async (path: string, sub?: string, roles?: string[]) =>
			SELF.fetch(`${ORIGIN}${path}`, { headers: sub ? await bearer(sub, roles) : {} })
		expect((await postForm('/rooms/2/bans', { id: '345' }, '1')).status).toBe(200)

		expect((await get('/rooms/2/bans/history?id=345')).status).toBe(401)
		expect((await get('/rooms/2/bans/history?id=345', '999')).status).toBe(403)
		// The co-owner, and a staff token with no role on the room.
		for (const [sub, roles] of [
			['2', undefined],
			['999', ['gameClient', 'moderator']],
		] as const) {
			const res = await get('/rooms/2/bans/history?id=345', sub, roles as string[] | undefined)
			expect(res.status, sub).toBe(200)
			expect(
				((await res.json()) as { Value: { ActiveBan: unknown } }).Value.ActiveBan
			).not.toBeNull()
		}

		// An unknown room is an empty history, not an error.
		expect(await (await get('/rooms/99999/bans/history?id=345', '999')).json()).toEqual({
			Value: { ActiveBan: null, PreviousBans: [] },
			Success: true,
			Error: null,
			error_id: null,
		})
		// A missing or non-numeric id.
		for (const q of ['', '?id=nope']) {
			expect(await (await get(`/rooms/2/bans/history${q}`, '1')).json(), q).toEqual({
				Value: null,
				Success: false,
				Error: 'You must provide a valid player!',
				error_id: null,
			})
		}
	})

	it('DELETE /rooms/:id/bans/bulk removes the named bans, under the same gate', async () => {
		type Removed = {
			success: boolean
			error: string
			value: Array<{ BannedPlayerId: number }> | null
		}
		const unban = async (body: string, sub?: string, roles?: string[]) =>
			SELF.fetch(`${ORIGIN}/rooms/2/bans/bulk`, {
				method: 'DELETE',
				headers: {
					'content-type': 'application/x-www-form-urlencoded',
					...(sub ? await bearer(sub, roles) : {}),
				},
				body,
			})
		const banned = async (playerId: number) =>
			(await env.DB.prepare('SELECT 1 FROM room_ban WHERE room_id = 2 AND banned_player_id = ?1')
				.bind(playerId)
				.first()) !== null
		for (const id of ['330', '331', '332', '333']) {
			expect((await postForm('/rooms/2/bans', { id }, '1')).status).toBe(200)
		}

		// No token → 401; a valid token with no standing in the room → 403. Nothing removed.
		expect((await unban('banMask=0&id=330')).status).toBe(401)
		expect((await unban('banMask=0&id=330', '999')).status).toBe(403)
		expect(await banned(330)).toBe(true)

		// The client's body, verbatim, from the owner.
		const one = await unban('banMask=0&id=330', '1')
		expect(one.status).toBe(200)
		expect((await one.json()) as Removed).toMatchObject({
			success: true,
			error: '',
			value: [{ BannedPlayerId: 330 }],
		})
		expect(await banned(330)).toBe(false)

		// Repeated `id` lifts every one of them — not just the last — from a co-owner, and a player
		// who is not banned (330, already lifted) is skipped rather than failing the others.
		const many = (await (await unban('banMask=0&id=331&id=330&id=332', '2')).json()) as Removed
		expect(many).toMatchObject({ success: true })
		expect(many.value!.map((b) => b.BannedPlayerId)).toEqual([331, 332])
		expect(await banned(331)).toBe(false)
		expect(await banned(332)).toBe(false)

		// A staff token works in a room it has no role on, and a comma-separated id is read too.
		expect(
			(await (await unban('id=333,334', '999', ['gameClient', 'moderator'])).json()) as Removed
		).toMatchObject({ success: true, value: [{ BannedPlayerId: 333 }] })

		// Nothing banned among the names is still a success, with nothing removed.
		expect((await (await unban('id=330', '1')).json()) as Removed).toMatchObject({
			success: true,
			value: [],
		})
		// A body naming no valid player at all is the one rejection.
		for (const body of ['banMask=0', 'id=nope']) {
			expect((await (await unban(body, '1')).json()) as Removed, body).toMatchObject({
				success: false,
				error: 'You must provide a valid player to unban!',
				value: null,
			})
		}
	})

	it('DELETE /rooms/:id/bans/:playerId lifts a ban, under the same gate', async () => {
		const del = async (path: string, sub?: string, roles?: string[]) =>
			SELF.fetch(`${ORIGIN}${path}`, {
				method: 'DELETE',
				headers: sub ? await bearer(sub, roles) : {},
			})
		const isBanned = async (roomId: number, playerId: number) =>
			(await env.DB.prepare(
				'SELECT 1 AS hit FROM room_ban WHERE room_id = ?1 AND banned_player_id = ?2'
			)
				.bind(roomId, playerId)
				.first()) !== null

		// Two bans to lift: one removed by the owner, one by a staffer.
		expect((await postForm('/rooms/2/bans', { id: '305' }, '1')).status).toBe(200)
		expect((await postForm('/rooms/2/bans', { id: '306' }, '1')).status).toBe(200)

		// No token → 401; a valid token with no room role and no staff role → 403.
		expect((await del('/rooms/2/bans/305')).status).toBe(401)
		expect((await del('/rooms/2/bans/305', '999')).status).toBe(403)
		expect(await isBanned(2, 305)).toBe(true)

		// Unknown room → failure envelope.
		expect(await envOf(await del('/rooms/99999/bans/305', '1'))).toMatchObject({
			success: false,
			error: 'This room does not exist!',
		})

		// The owner lifts it; the removed ban comes back as `value`.
		const ok = await del('/rooms/2/bans/305', '1')
		expect(ok.status).toBe(200)
		expect(await envOf(ok)).toMatchObject({
			success: true,
			error: '',
			value: { RoomId: 2, BannedPlayerId: 305 },
		})
		expect(await isBanned(2, 305)).toBe(false)

		// Unbanning someone who isn't banned is a rejection, not a silent success.
		expect(await envOf(await del('/rooms/2/bans/305', '1'))).toMatchObject({
			success: false,
			error: 'This player is not banned from this room!',
			value: null,
		})

		// A staff token may lift a ban in a room they have no role on.
		expect((await del('/rooms/2/bans/306', '999', ['gameClient', 'developer'])).status).toBe(200)
		expect(await isBanned(2, 306)).toBe(false)
	})

	it('PUT /rooms/:id/warning is auth-gated, owner/co-owner-only, and persists', async () => {
		// No token → 401 (auth gate).
		expect((await putForm('/rooms/2/warning', { warningMask: '2' })).status).toBe(401)
		// A valid token but no role on the room → 403.
		expect((await putForm('/rooms/2/warning', { warningMask: '2' }, '999')).status).toBe(403)
		// Unknown room → failure envelope.
		expect(
			await envOf(await putForm('/rooms/99999/warning', { warningMask: '2' }, '1'))
		).toMatchObject({ success: false, error: 'This room does not exist!' })
		// Non-numeric mask → failure envelope.
		expect(await envOf(await putForm('/rooms/2/warning', { warningMask: 'x' }, '1'))).toMatchObject(
			{ success: false }
		)

		// Owner sets it, and it persists as an integer (not 2.0). The success envelope
		// carries the updated room as `value`.
		const ok = await putForm('/rooms/2/warning', { warningMask: '2' }, '1')
		expect(ok.status).toBe(200)
		const okBody = await envOf(ok)
		expect(okBody).toMatchObject({ success: true, error: '' })
		expect(okBody.value?.WarningMask).toBe(2)
		const raw = await env.DB.prepare('SELECT data FROM room WHERE room_id = ?1')
			.bind(2)
			.first<{ data: string }>()
		expect(raw!.data).toContain('"WarningMask":2')
		expect(raw!.data).not.toContain('"WarningMask":2.0')
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as { WarningMask: number }
		expect(room.WarningMask).toBe(2)

		// The mask can carry an optional free-text CustomWarning alongside it.
		const custom = await envOf(
			await putForm('/rooms/2/warning', { warningMask: '63', customWarning: 'slfkjsdf' }, '1')
		)
		expect(custom).toMatchObject({ success: true })
		expect(custom.value).toMatchObject({ WarningMask: 63, CustomWarning: 'slfkjsdf' })
		const withCustom = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			WarningMask: number
			CustomWarning: string
		}
		expect(withCustom).toMatchObject({ WarningMask: 63, CustomWarning: 'slfkjsdf' })

		// Omitting customWarning leaves the existing text untouched (partial update).
		await putForm('/rooms/2/warning', { warningMask: '7' }, '1')
		const kept = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as { CustomWarning: string }
		expect(kept.CustomWarning).toBe('slfkjsdf')

		// The co-owner (account 2, Role 30) may also set it.
		expect((await putForm('/rooms/2/warning', { warningMask: '4' }, '2')).status).toBe(200)
	})

	it('PUT /rooms/:id/cloning is auth-gated, owner/co-owner-only, and persists a JSON boolean', async () => {
		// No token → 401.
		expect((await putForm('/rooms/2/cloning', { cloningAllowed: 'False' })).status).toBe(401)
		// A valid token but no role on the room → 403.
		expect((await putForm('/rooms/2/cloning', { cloningAllowed: 'False' }, '999')).status).toBe(403)
		// Unknown room → failure envelope.
		expect(
			await envOf(await putForm('/rooms/99999/cloning', { cloningAllowed: 'False' }, '1'))
		).toMatchObject({ success: false, error: 'This room does not exist!' })

		// Owner disables cloning; it persists as a real JSON boolean (not 0/1). The
		// success envelope carries the updated room as `value`.
		const disabled = await envOf(
			await putForm('/rooms/2/cloning', { cloningAllowed: 'False' }, '1')
		)
		expect(disabled).toMatchObject({ success: true, error: '' })
		expect(disabled.value?.CloningAllowed).toBe(false)
		const raw = await env.DB.prepare('SELECT data FROM room WHERE room_id = ?1')
			.bind(2)
			.first<{ data: string }>()
		expect(raw!.data).toContain('"CloningAllowed":false')
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			CloningAllowed: boolean
		}
		expect(room.CloningAllowed).toBe(false)

		// The co-owner (account 2) may re-enable it.
		await putForm('/rooms/2/cloning', { cloningAllowed: 'True' }, '2')
		const reenabled = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			CloningAllowed: boolean
		}
		expect(reenabled.CloningAllowed).toBe(true)
	})

	it('PUT /rooms/:id/restrictions sets the Supports* flags present in the body', async () => {
		// No token → 401; a valid token with no role → 403.
		expect((await putForm('/rooms/2/restrictions', { supportsScreens: 'True' })).status).toBe(401)
		expect(
			(await putForm('/rooms/2/restrictions', { supportsScreens: 'True' }, '999')).status
		).toBe(403)

		// The exact client body: a mix of True/False across a subset of the flags.
		const res = await SELF.fetch(`${ORIGIN}/rooms/2/restrictions`, {
			method: 'PUT',
			headers: { ...(await bearer('1')), 'Content-Type': 'application/x-www-form-urlencoded' },
			body: 'supportsScreens=True&supportsWalkVR=True&supportsTeleportVR=False&supportsJuniors=True',
		})
		expect(res.status).toBe(200)
		// The success envelope carries the updated room as `value`.
		const env2 = await envOf(res)
		expect(env2).toMatchObject({ success: true, error: '' })
		expect(env2.value).toMatchObject({
			SupportsScreens: true,
			SupportsWalkVR: true,
			SupportsTeleportVR: false,
			SupportsJuniors: true,
		})

		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			SupportsScreens: boolean
			SupportsWalkVR: boolean
			SupportsTeleportVR: boolean
			SupportsJuniors: boolean
			SupportsMobile: boolean
		}
		expect(room.SupportsScreens).toBe(true)
		expect(room.SupportsWalkVR).toBe(true)
		expect(room.SupportsTeleportVR).toBe(false)
		expect(room.SupportsJuniors).toBe(true)
		// A flag not in the body is left unchanged (still a boolean, not dropped).
		expect(typeof room.SupportsMobile).toBe('boolean')
	})

	it('PUT /rooms/:id/loadscreen replaces the load screen (auth-gated, owner/co-owner-only)', async () => {
		const screensOf = async (): Promise<Array<Record<string, unknown>>> => {
			const room = (await (
				await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
			).json()) as {
				LoadScreens?: Array<Record<string, unknown>>
			}
			return room.LoadScreens ?? []
		}

		// No token → 401; a valid token with no role → 403.
		expect((await putForm('/rooms/2/loadscreen', { imageName: 'a.jpg' })).status).toBe(401)
		expect((await putForm('/rooms/2/loadscreen', { imageName: 'a.jpg' }, '999')).status).toBe(403)
		// Unknown room → failure envelope.
		expect(
			await envOf(await putForm('/rooms/99999/loadscreen', { imageName: 'a.jpg' }, '1'))
		).toMatchObject({ success: false, error: 'This room does not exist!' })
		// Missing image → failure envelope.
		expect(await envOf(await putForm('/rooms/2/loadscreen', { title: 'x' }, '1'))).toMatchObject({
			success: false,
		})

		// Owner sets one (imageName + title + subtitle) — the success envelope carries the
		// updated room, and the posted screen is the ONLY entry.
		const added = await envOf(
			await putForm(
				'/rooms/2/loadscreen',
				{ imageName: 'sharecamera/2026-07-15/abc.jpg', title: 'asdf', subtitle: 'sdf' },
				'1'
			)
		)
		expect(added).toMatchObject({ success: true })
		expect(added.value?.LoadScreens).toEqual([
			{ ImageName: 'sharecamera/2026-07-15/abc.jpg', Title: 'asdf', Subtitle: 'sdf' },
		])
		expect(await screensOf()).toHaveLength(1)

		// A second call REPLACES rather than appending (the client renders one screen, so
		// an appended one would sit unreachable behind the old); title/subtitle default to
		// empty when omitted.
		const co = await envOf(await putForm('/rooms/2/loadscreen', { imageName: 'second.jpg' }, '2'))
		expect(co).toMatchObject({ success: true })
		expect(await screensOf()).toEqual([{ ImageName: 'second.jpg', Title: '', Subtitle: '' }])
	})

	it('PUT /rooms/:id/accessibility sets the room-level Accessibility (auth-gated, owner/co-owner-only)', async () => {
		// No token → 401; a valid token with no role → 403.
		expect((await putForm('/rooms/2/accessibility', { accessibility: '1' })).status).toBe(401)
		expect((await putForm('/rooms/2/accessibility', { accessibility: '1' }, '999')).status).toBe(
			403
		)
		// Unknown room → failure envelope.
		expect(
			await envOf(await putForm('/rooms/99999/accessibility', { accessibility: '1' }, '1'))
		).toMatchObject({ success: false, error: 'This room does not exist!' })
		// Non-numeric → failure envelope.
		expect(
			await envOf(await putForm('/rooms/2/accessibility', { accessibility: 'x' }, '1'))
		).toMatchObject({ success: false })

		// Owner sets it (0 = Private); the success envelope carries the updated room.
		const priv = await envOf(await putForm('/rooms/2/accessibility', { accessibility: '0' }, '1'))
		expect(priv).toMatchObject({ success: true, error: '' })
		expect(priv.value?.Accessibility).toBe(0)
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as { Accessibility: number }
		expect(room.Accessibility).toBe(0)

		// The co-owner (account 2) may set it back to public (1).
		const pub = await envOf(await putForm('/rooms/2/accessibility', { accessibility: '1' }, '2'))
		expect(pub.value?.Accessibility).toBe(1)
	})

	it('PUT /rooms/:id/accessibility lets staff unpublish a room they hold no role on (audited)', async () => {
		const staffPut = async (roles: string[], accessibility: string) =>
			envOf(
				await SELF.fetch(`${ORIGIN}/rooms/2/accessibility`, {
					method: 'PUT',
					headers: {
						...(await bearer('997', ['gameClient', ...roles])),
						'Content-Type': 'application/x-www-form-urlencoded',
					},
					body: new URLSearchParams({ accessibility }).toString(),
				})
			)
		const before = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			Accessibility: number
		}

		expect((await staffPut(['moderator'], '0')).value?.Accessibility).toBe(0)
		expect((await staffPut(['developer'], String(before.Accessibility))).value?.Accessibility).toBe(
			before.Accessibility
		)

		const { results: audit } = await env.DB.prepare(
			'SELECT player_id, data FROM audit_log WHERE action = ?1 ORDER BY audit_log_id'
		)
			.bind('room_accessibility')
			.all<{ player_id: number; data: string }>()
		expect(audit).toHaveLength(2)
		expect(audit[0].player_id).toBe(997)
		expect(JSON.parse(audit[0].data)).toMatchObject({
			roomId: 2,
			from: before.Accessibility,
			to: 0,
		})
	})
})
