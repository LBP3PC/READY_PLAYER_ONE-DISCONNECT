import { adminSecretsStore, env, SELF } from 'cloudflare:test'

import {
	AUDIT_LOG_SCHEMA_DDL,
	CURATED_LIST_SCHEMA_DDL,
	NOTIFICATION_SCHEMA_DDL,
	PRESENCE_SCHEMA_DDL,
	RELATIONSHIP_SCHEMA_DDL,
	ROOM_INSTANCE_SCHEMA_DDL,
	ROOM_INVITE_SCHEMA_DDL,
	ROOM_SCHEMA_DDL,
	ROOM_XP_SCHEMA_DDL,
	seedRoomWithSubRooms,
	SUBROOM_SCHEMA_DDL,
	UNITY_ASSET_SCHEMA_DDL,
} from '@repo/domain'

import { SCHEMA_DDL as CUSTOM_AVATAR_ITEM_SCHEMA_DDL } from '../../../../../api/src/custom-avatar-items-db'
import { SCHEMA_DDL as INVENTION_SCHEMA_DDL } from '../../../../../api/src/inventions-db'
import { SCHEMA_DDL as ROOM_VOTE_SCHEMA_DDL } from '../../../../../api/src/votes-db'
import importRooms from '../../../../static/ImportRooms.json'

import '../../../rooms.app'

import type { Room } from '@repo/domain'
import type { Env } from '../../../context'

declare module 'cloudflare:test' {
	interface ProvidedEnv extends Env {}
}

export const ORIGIN = 'https://example.com'

// Mint a token the way the `auth` worker does, signing with the shared test key seeded into the JWT_SECRET store.
const TEST_SECRET = 'test-signing-key'
function b64url(input: ArrayBuffer | string): string {
	const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : new Uint8Array(input)
	let binary = ''
	for (const byte of bytes) binary += String.fromCharCode(byte)
	return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}
// `roles` mints the `role` claim the auth worker stamps from an account's flags; left
// off, the token carries none — what a plain player's looks like to the role gates.
export async function bearer(
	sub: string,
	roles?: string[],
	// The client build the token was minted for (`rn.ver`), which is what
	// `/featuredrooms/current` gates on. Omitted by default, like a token from a grant that
	// posted no `ver`.
	version?: string,
	// The `rn.plus` claim auth stamps for a Rec Room Plus subscriber.
	plus?: boolean
): Promise<Record<string, string>> {
	const now = Math.floor(Date.now() / 1000)
	const signingInput = `${b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))}.${b64url(
		JSON.stringify({
			sub,
			exp: now + 3600,
			...(roles && { role: roles }),
			...(version && { 'rn.ver': version }),
			...(plus && { 'rn.plus': true }),
		})
	)}`
	const key = await crypto.subtle.importKey(
		'raw',
		new TextEncoder().encode(TEST_SECRET),
		{ name: 'HMAC', hash: 'SHA-256' },
		false,
		['sign']
	)
	const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(signingInput))
	return { Authorization: `Bearer ${signingInput}.${b64url(sig)}` }
}

/**
 * Put a player in a room, the way the `match` heartbeat would — the save routes read this
 * to decide whether a non-creator may see the room's history. `expired` writes a row that
 * has already lapsed, which reads back as no presence at all.
 */
export async function putInRoom(
	accountId: number,
	roomId: number,
	{ expired = false }: { expired?: boolean } = {}
): Promise<void> {
	const now = Math.floor(Date.now() / 1000)
	await env.DB.prepare('INSERT OR REPLACE INTO presence (data) VALUES (?1)')
		.bind(
			JSON.stringify({
				accountId,
				roomInstance: { roomInstanceId: 1000000 + roomId, roomId, subRoomId: roomId },
				expiresAt: expired ? now - 1 : now + 900,
			})
		)
		.run()
}

/** Take a player back out of whatever room they were in. */
export async function clearPresence(accountId: number): Promise<void> {
	await env.DB.prepare('DELETE FROM presence WHERE account_id = ?1').bind(accountId).run()
}

export const postForm = async (
	path: string,
	fields: Record<string, string>,
	sub?: string,
	roles?: string[]
) =>
	SELF.fetch(`${ORIGIN}${path}`, {
		method: 'POST',
		headers: {
			...(sub ? await bearer(sub, roles) : {}),
			'Content-Type': 'application/x-www-form-urlencoded',
		},
		body: new URLSearchParams(fields).toString(),
	})

export const putForm = async (path: string, fields: Record<string, string>, sub?: string) =>
	SELF.fetch(`${ORIGIN}${path}`, {
		method: 'PUT',
		headers: {
			...(sub ? await bearer(sub) : {}),
			'Content-Type': 'application/x-www-form-urlencoded',
		},
		body: new URLSearchParams(fields).toString(),
	})

// Room-mutation envelope helper (PascalCase `{ Success, Value, ErrorId, Error }` —
// used by name/image/description).
export type RoomResult = {
	Success: boolean
	Value: unknown
	ErrorId: string | null
	Error: string | null
}
export const bodyOf = async (res: Response) => (await res.json()) as RoomResult

// Lowercase `{ success, error, value }` envelope — used by tags/clone and the
// roles/warning/cloning/restrictions room-settings mutations (value = updated room).
export type RoomEnv = { success: boolean; error: string; value: Record<string, unknown> | null }
export const envOf = async (res: Response) => (await res.json()) as RoomEnv

// A role entry as STORED, read off the `room_role` index — pending invites included.
// The served room carries only held roles; `GET /rooms/:id/roles` lists invites too.
export type StoredRole = {
	Role: number
	InvitedRole: number
	LastChangedByAccountId: number | null
}
export const storedRoleOf = async (roomId: number, accountId: number) =>
	(await env.DB.prepare(
		`SELECT role AS Role, invited_role AS InvitedRole,
		        last_changed_by_account_id AS LastChangedByAccountId
		 FROM room_role WHERE room_id = ?1 AND account_id = ?2`
	)
		.bind(roomId, accountId)
		.first<StoredRole>()) ?? undefined

// A subroom as the client sees it. There is no GET for a single subroom — the client
// reads them off the room — so tests do the same.
export const subRoomOf = async (
	roomId: number,
	subRoomId: number
): Promise<Record<string, unknown> | undefined> => {
	const res = await SELF.fetch(`${ORIGIN}/rooms/${roomId}`, {
		headers: await bearer('1', ['developer']),
	})
	if (res.status !== 200) return undefined
	const room = (await res.json()) as { SubRooms?: Array<Record<string, unknown>> }
	return (room.SubRooms ?? []).find((s) => s.SubRoomId === subRoomId)
}

/** The hub stub records every notifyPlayer call — see vitest.config.ts. */
export type SentUpdate = { playerId: number; notificationType: string | number; data: Room }
const notifyHub = () => env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
export const resetNotifications = () => notifyHub().fetch('http://do/all', { method: 'DELETE' })
export const sentNotifications = async (): Promise<SentUpdate[]> =>
	(await (await notifyHub().fetch('http://do/all')).json()) as SentUpdate[]

// Apply the schema + seed the imported rooms into the test D1 (mirrors the migrations).
export async function setupSchema(): Promise<void> {
	// Seed the shared JWT signing key into the local Secrets Store so .get() resolves.
	await adminSecretsStore(env.JWT_SECRET).create('test-signing-key')
	for (const stmt of ROOM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of SUBROOM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of ROOM_INSTANCE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Presence table (read by the photon access-token handler).
	// The showcase route reads the player's __Showcase_Rooms list, so the lists tables have
	// to exist here too.
	for (const stmt of CURATED_LIST_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of PRESENCE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Friend graph — a friend in an unpublished room lets the caller read that room.
	for (const stmt of RELATIONSHIP_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Message store (owned by the api worker) — a room-role invite is written there before
	// it is pushed, so the invited player can read it back from their inbox.
	for (const stmt of NOTIFICATION_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// The audit log the staff takedown writes to. Owned by `api`'s migrations; built here
	// directly, the way `notify`'s tests do.
	for (const stmt of AUDIT_LOG_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Vote-to-kick ballots (owned by `api`) and game invites (owned by `match`) — the cron
	// here sweeps the stale ones.
	for (const stmt of ROOM_VOTE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Inventions (owned by the api worker) — a room save writes each one's room count.
	for (const stmt of INVENTION_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of CUSTOM_AVATAR_ITEM_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	for (const stmt of ROOM_INVITE_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Baked unity asset bundles — what `POST /unity_assets/baked/bulk` serves.
	for (const stmt of UNITY_ASSET_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Per-room XP — what `GET /rooms/:id/experience/player` reads.
	for (const stmt of ROOM_XP_SCHEMA_DDL) await env.DB.prepare(stmt).run()
	// Seed each room and split its subrooms into the subroom table (mirrors 0007's backfill).
	for (const r of importRooms) await seedRoomWithSubRooms(env.DB, r as Record<string, unknown>)

	// Accounts table (owned by the auth worker) — provisioning a dorm reads the username
	// to name the room. Seed the player `dormroom/me` provisions a fresh dorm for.
	await env.DB.prepare(
		`CREATE TABLE IF NOT EXISTS account (
			data TEXT NOT NULL,
			account_id INTEGER GENERATED ALWAYS AS (json_extract(data, '$.accountId')) VIRTUAL
		)`
	).run()
	await env.DB.prepare('INSERT OR IGNORE INTO account (data) VALUES (?1)')
		.bind(JSON.stringify({ accountId: 999, username: 'Dormer' }))
		.run()
}
