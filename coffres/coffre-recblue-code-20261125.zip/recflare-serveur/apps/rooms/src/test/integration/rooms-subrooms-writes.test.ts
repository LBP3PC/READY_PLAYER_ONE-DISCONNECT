// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { putUnityAsset, seedRoomWithSubRooms } from '@repo/domain'

import { bearer, ORIGIN, setupSchema, subRoomOf } from './support/harness'

beforeAll(setupSchema)

describe('rooms endpoints', () => {
	it('POST /rooms/:id/subrooms/:sid/clone is auth-gated, owner/co-owner only, and copies the subroom', async () => {
		const clone = async (roomId: number, subRoomId: number, sub?: string) =>
			SELF.fetch(`${ORIGIN}/rooms/${roomId}/subrooms/${subRoomId}/clone`, {
				method: 'POST',
				headers: sub ? await bearer(sub) : {},
			})
		type SubRoom = { SubRoomId: number; CreatorAccountId: number }
		const envelope = async (res: Response) =>
			(await res.json()) as {
				success: boolean
				error: string
				value: { RoomId: number; SubRooms: SubRoom[] } | null
			}

		// No token → 401.
		expect((await clone(2, 2)).status).toBe(401)
		// Not the owner → success:false envelope.
		expect((await envelope(await clone(2, 2, '999'))).success).toBe(false)
		// Unknown subroom → success:false envelope.
		expect((await envelope(await clone(2, 9999, '1'))).success).toBe(false)

		const before = new Set(
			(
				(await (
					await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
				).json()) as { SubRooms: SubRoom[] }
			).SubRooms.map((s) => s.SubRoomId)
		)

		// Owner clones → success. `value` is the updated ROOM, not the new subroom, so the
		// clone shows up as one extra entry in its re-attached SubRooms list.
		const res = await clone(2, 2, '1')
		expect(res.status).toBe(200)
		const body = await envelope(res)
		expect(body.success).toBe(true)
		expect(body.value?.RoomId).toBe(2)
		const added = body.value!.SubRooms.filter((s) => !before.has(s.SubRoomId))
		expect(added).toHaveLength(1)
		expect(added[0]!.CreatorAccountId).toBe(1)
		// A fresh id, and fetchable as a subroom of the room.
		expect(added[0]!.SubRoomId).not.toBe(2)
		expect(await subRoomOf(2, added[0]!.SubRoomId)).toMatchObject({
			SubRoomId: added[0]!.SubRoomId,
		})

		// Co-owners may clone too; the new subroom belongs to the caller.
		const coOwnerBody = await envelope(await clone(2, 2, '2'))
		expect(coOwnerBody.success).toBe(true)
		const known = new Set([...before, added[0]!.SubRoomId])
		const coOwnerAdded = coOwnerBody.value!.SubRooms.filter((s) => !known.has(s.SubRoomId))
		expect(coOwnerAdded).toHaveLength(1)
		expect(coOwnerAdded[0]!.CreatorAccountId).toBe(2)
	})

	it('PUT /rooms/:id/max_player_calculation_mode stores the mode; MaxPlayers is derived on read', async () => {
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 720,
			Name: 'CapMode',
			CreatorAccountId: 5,
			MaxPlayerCalculationMode: 0,
			MaxPlayers: 12,
			Roles: [{ AccountId: 1, Role: 30, LastChangedByAccountId: null, InvitedRole: 0 }],
			SubRooms: [
				{ SubRoomId: 920, UnitySceneId: 'x', MaxPlayers: 12 },
				{ SubRoomId: 921, UnitySceneId: 'x', MaxPlayers: 4 },
			],
		})
		const put = async (roomId: number, mode: string, sub?: string) =>
			SELF.fetch(`${ORIGIN}/rooms/${roomId}/max_player_calculation_mode`, {
				method: 'PUT',
				headers: {
					...(sub ? await bearer(sub) : {}),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: new URLSearchParams({ maxPlayerCalculationMode: mode }).toString(),
			})
		type Envelope = {
			Value: { RoomId: number; MaxPlayerCalculationMode: number; MaxPlayers: number } | null
			Success: boolean
			Error: string | null
			error_id: null
		}
		const envelope = async (res: Response) => (await res.json()) as Envelope

		// No token → 401; every other refusal is a 200 with Success:false and Value:null.
		expect((await put(720, 'OnlyEntrySubrooms')).status).toBe(401)
		for (const res of [
			await put(720, 'OnlyEntrySubrooms', '999'), // not on the room
			await put(720, 'Sideways', '1'), // not a mode
			await put(720, '7', '1'), // not an ordinal in the enum
			await put(424242, 'OnlyEntrySubrooms', '1'), // no such room
		]) {
			expect(res.status).toBe(200)
			expect(await envelope(res)).toMatchObject({ Value: null, Success: false, error_id: null })
		}

		// A co-owner sets it by NAME (what the client sends). Stored as the ordinal; the stored
		// MaxPlayers is untouched, and the SERVED one is derived — neither subroom is public, so
		// "only entry" counts them all, and the smallest is 4.
		const res = await put(720, 'OnlyEntrySubrooms', '1')
		expect(res.status).toBe(200)
		const body = await envelope(res)
		expect(body).toMatchObject({ Success: true, Error: null, error_id: null })
		expect(body.Value).toMatchObject({ RoomId: 720, MaxPlayerCalculationMode: 1, MaxPlayers: 4 })
		expect(
			await env.DB.prepare(
				"SELECT json_extract(data, '$.MaxPlayers') AS max FROM room WHERE room_id = 720"
			).first()
		).toEqual({ max: 12 })
		const stored = (await (
			await SELF.fetch(`${ORIGIN}/rooms/720`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			MaxPlayerCalculationMode: number
			MaxPlayers: number
		}
		expect(stored).toMatchObject({ MaxPlayerCalculationMode: 1, MaxPlayers: 4 })

		// Case-insensitive names and the bare ordinal are accepted too.
		expect(
			(await envelope(await put(720, 'allsubrooms', '5'))).Value?.MaxPlayerCalculationMode
		).toBe(0)
		expect((await envelope(await put(720, '1', '5'))).Value?.MaxPlayerCalculationMode).toBe(1)
	})

	it('POST /rooms/:id/subrooms/:sid/move re-parents a subroom when the caller manages both rooms', async () => {
		// Source 710 is owned by 1 with two subrooms; target 711 is owned by 5 with 1 as a
		// CO-OWNER (the move gate is manage, not own); 712 is somebody else's entirely.
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 710,
			Name: 'MoveSource',
			CreatorAccountId: 1,
			SubRooms: [
				{ SubRoomId: 910, UnitySceneId: 'x', MaxPlayers: 4 },
				{ SubRoomId: 911, UnitySceneId: 'x', MaxPlayers: 4 },
			],
		})
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 711,
			Name: 'MoveTarget',
			CreatorAccountId: 5,
			Roles: [{ AccountId: 1, Role: 30, LastChangedByAccountId: null, InvitedRole: 0 }],
			SubRooms: [{ SubRoomId: 912, UnitySceneId: 'x', MaxPlayers: 4 }],
		})
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 712,
			Name: 'NotMine',
			CreatorAccountId: 999,
			SubRooms: [{ SubRoomId: 913, UnitySceneId: 'x', MaxPlayers: 4 }],
		})
		const move = async (roomId: number, subRoomId: number, newRoomId: string, sub?: string) =>
			SELF.fetch(`${ORIGIN}/rooms/${roomId}/subrooms/${subRoomId}/move`, {
				method: 'POST',
				headers: {
					...(sub ? await bearer(sub) : {}),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: new URLSearchParams({ newRoomId }).toString(),
			})
		type Envelope = {
			Value: { RoomId: number; SubRooms: Array<{ SubRoomId: number; RoomId: number }> } | null
			Success: boolean
			Error: string | null
			error_id: null
		}
		const envelope = async (res: Response) => (await res.json()) as Envelope

		// No token → 401. Every other refusal is a 200 with Success:false and Value:null.
		expect((await move(710, 910, '711')).status).toBe(401)
		const refused = async (res: Response) => {
			expect(res.status).toBe(200)
			const body = await envelope(res)
			expect(body).toMatchObject({ Value: null, Success: false, error_id: null })
			expect(typeof body.Error).toBe('string')
		}
		await refused(await move(710, 910, '711', '999')) // can't manage the source
		await refused(await move(710, 910, '712', '1')) // can't manage the target
		await refused(await move(710, 910, '424242', '1')) // no such target
		await refused(await move(710, 910, '710', '1')) // already there
		await refused(await move(710, 910, '', '1')) // no newRoomId
		await refused(await move(710, 99999, '711', '1')) // no such subroom
		await refused(await move(712, 913, '711', '999')) // 999 owns 712 but not 711
		// Nothing moved on any of those.
		expect(await subRoomOf(710, 910)).toBeDefined()
		expect(await subRoomOf(711, 910)).toBeUndefined()

		// Owner of the source and co-owner of the target → moved. Value is the SOURCE room,
		// which no longer lists the subroom, in the PascalCase envelope.
		const res = await move(710, 910, '711', '1')
		expect(res.status).toBe(200)
		const body = await envelope(res)
		expect(body).toMatchObject({ Success: true, Error: null, error_id: null })
		expect(body.Value?.RoomId).toBe(710)
		expect(body.Value?.SubRooms.map((s) => s.SubRoomId)).toEqual([911])
		// It now reads as the target's, with its RoomId re-injected from the column.
		expect(await subRoomOf(710, 910)).toBeUndefined()
		expect(await subRoomOf(711, 910)).toMatchObject({ SubRoomId: 910, RoomId: 711 })

		// The source's last subroom can't leave — the room would have no scene to load.
		await refused(await move(710, 911, '711', '1'))
		expect(await subRoomOf(710, 911)).toBeDefined()
	})

	it('subroom clone mints a globally-unique SubRoomId (no cross-room clash)', async () => {
		// The old per-room `max(SubRoomId)+1` allocator would mint id 3 for room 2's clone —
		// colliding with another room that already owns subroom 3. The subroom table's
		// autoincrement mints an id above every existing subroom instead.
		const maxBefore = (await env.DB.prepare('SELECT MAX(sub_room_id) AS m FROM subroom').first<{
			m: number
		}>())!.m

		const res = await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/clone`, {
			method: 'POST',
			headers: await bearer('1'),
		})
		// `value` is the updated room; the clone is its highest-numbered subroom.
		const body = (await res.json()) as {
			value: { RoomId: number; SubRooms: Array<{ SubRoomId: number }> }
		}
		const cloned = Math.max(...body.value.SubRooms.map((s) => s.SubRoomId))
		// Above every prior subroom id — a fresh global id, not a per-room collision.
		expect(cloned).toBeGreaterThan(maxBefore)
		expect(body.value.RoomId).toBe(2)

		// The id is unique across the whole table (exactly one row owns it).
		const dupes = (await env.DB.prepare('SELECT COUNT(*) AS n FROM subroom WHERE sub_room_id = ?1')
			.bind(cloned)
			.first<{ n: number }>())!.n
		expect(dupes).toBe(1)
	})

	it('POST /rooms/:id/subrooms creates a new subroom (auth-gated, owner-only, fresh id)', async () => {
		const create = async (roomId: number, name: string, sub?: string) =>
			SELF.fetch(`${ORIGIN}/rooms/${roomId}/subrooms`, {
				method: 'POST',
				headers: {
					...(sub ? await bearer(sub) : {}),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: new URLSearchParams({ name }).toString(),
			})
		type SubRoom = { SubRoomId: number; RoomId: number; Name: string; CreatorAccountId: number }
		const envelope = async (res: Response) =>
			(await res.json()) as {
				success: boolean
				// The whole room comes back on success (the client re-renders its subroom list).
				value: { RoomId: number; SubRooms: SubRoom[] } | null
			}

		// No token → 401.
		expect((await create(2, 'ffff')).status).toBe(401)
		// Valid token but not the owner → success:false envelope.
		expect((await envelope(await create(2, 'ffff', '999'))).success).toBe(false)
		// Blank name → success:false envelope.
		expect((await envelope(await create(2, '  ', '1'))).success).toBe(false)
		// Unknown room → success:false envelope.
		expect((await envelope(await create(99999, 'ffff', '1'))).success).toBe(false)

		const maxBefore = (await env.DB.prepare('SELECT MAX(sub_room_id) AS m FROM subroom').first<{
			m: number
		}>())!.m

		// Owner creates → success, and the returned room now embeds the new subroom: a fresh
		// global SubRoomId owned by the caller, named, and fetchable.
		const body = await envelope(await create(2, 'ffff', '1'))
		expect(body.success).toBe(true)
		expect(body.value?.RoomId).toBe(2)
		const created = body.value?.SubRooms.find((s) => s.Name === 'ffff')
		expect(created).toMatchObject({ RoomId: 2, Name: 'ffff', CreatorAccountId: 1 })
		expect(created!.SubRoomId).toBeGreaterThan(maxBefore)

		const fetched = (await subRoomOf(2, created!.SubRoomId)) as unknown as {
			SubRoomId: number
			Name: string
			UnitySceneId: string
		}
		expect(fetched).toMatchObject({ SubRoomId: created?.SubRoomId, Name: 'ffff' })

		// It inherits room 2's own existing (first) subroom scene.
		const roomScene = (
			JSON.parse(
				(await env.DB.prepare(
					'SELECT data FROM subroom WHERE room_id = 2 ORDER BY sub_room_id LIMIT 1'
				).first<{ data: string }>())!.data
			) as { UnitySceneId: string }
		).UnitySceneId
		expect(fetched.UnitySceneId).toBe(roomScene)
	})

	it('DELETE /rooms/:id/subrooms/:sid removes a subroom (auth-gated, owner-only, not the last)', async () => {
		const del = async (roomId: number, subRoomId: number, sub?: string) =>
			SELF.fetch(`${ORIGIN}/rooms/${roomId}/subrooms/${subRoomId}`, {
				method: 'DELETE',
				headers: sub ? await bearer(sub) : {},
			})
		type SubRoom = { SubRoomId: number; Name: string }
		const envelope = async (res: Response) =>
			(await res.json()) as { success: boolean; value: { SubRooms: SubRoom[] } | null }

		// Add a subroom to room 2 (which already has others), and capture its id by name.
		const created = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2/subrooms`, {
				method: 'POST',
				headers: { ...(await bearer('1')), 'Content-Type': 'application/x-www-form-urlencoded' },
				body: new URLSearchParams({ name: 'ToDelete' }).toString(),
			})
		).json()) as { value: { SubRooms: SubRoom[] } }
		const newId = created.value.SubRooms.find((s) => s.Name === 'ToDelete')!.SubRoomId

		// No token → 401. Not the owner → success:false. Unknown subroom → success:false.
		expect((await del(2, newId)).status).toBe(401)
		expect((await envelope(await del(2, newId, '999'))).success).toBe(false)
		expect((await envelope(await del(2, 99999, '1'))).success).toBe(false)

		// Owner deletes → success, and the subroom is gone from the returned room + not fetchable.
		const body = await envelope(await del(2, newId, '1'))
		expect(body.success).toBe(true)
		expect(body.value?.SubRooms.some((s) => s.SubRoomId === newId)).toBe(false)
		expect(await subRoomOf(2, newId)).toBeUndefined()

		// A room's only subroom can't be deleted (would leave it with no scene). Seed a
		// dedicated single-subroom room owned by account 1 to exercise the guard.
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 700,
			Name: 'SoloSubRoom',
			CreatorAccountId: 1,
			SubRooms: [{ SubRoomId: 900, UnitySceneId: 'x', MaxPlayers: 4 }],
		})
		expect((await envelope(await del(700, 900, '1'))).success).toBe(false)
		// The lone subroom survives the refused delete.
		expect(await subRoomOf(700, 900)).toBeDefined()
	})

	describe('POST /unity_assets/baked/bulk', () => {
		const URL = `${ORIGIN}/unity_assets/baked/bulk`
		const post = (body: string) =>
			SELF.fetch(URL, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body,
			})
		const A = '4f0c1e4a-2b77-4b16-9a3e-5dbcfd7f2865'
		const B = '9a3e5dbc-fd7f-2865-8f0c-1e4a2b774b16'
		const C = '22555d14-2918-43f3-94d4-da0c893d96c4'

		beforeAll(async () => {
			await putUnityAsset(env.DB, {
				UnityAssetId: A,
				Target: 0,
				Version: 227,
				Filename: '2026-10-05/a0d83019-675d-41c0-8924-c238c5a12ee8',
				Hash: 'R0SVMvrAW4n1TIF2lxaOAQZ5XXVJh7prEP6GpiLCrQo=',
			})
			await putUnityAsset(env.DB, {
				UnityAssetId: A,
				Target: 2,
				Version: 227,
				Filename: '2026-10-05/quest-a',
				Hash: 'quest-a-hash',
			})
			// B was built twice for Windows.
			await putUnityAsset(env.DB, {
				UnityAssetId: B,
				Target: 0,
				Version: 3,
				Filename: '2026-10-05/b-v3',
				Hash: 'b-v3-hash',
			})
			await putUnityAsset(env.DB, {
				UnityAssetId: B,
				Target: 0,
				Version: 5,
				Filename: '2026-10-05/b-v5',
				Hash: 'b-v5-hash',
			})
		})

		it('answers a bare array of five-key entries for the ids asked, in order', async () => {
			const res = await post(`target=0&version=227&id=${B}&id=${A}`)
			expect(res.status).toBe(200)
			const body = (await res.json()) as Array<Record<string, unknown>>
			expect(body.map((e) => e.UnityAssetId)).toEqual([B, A])
			expect(Object.keys(body[1]!)).toEqual([
				'UnityAssetId',
				'Target',
				'Version',
				'Filename',
				'Hash',
			])
			expect(body[1]).toEqual({
				UnityAssetId: A,
				Target: 0,
				Version: 227,
				Filename: '2026-10-05/a0d83019-675d-41c0-8924-c238c5a12ee8',
				Hash: 'R0SVMvrAW4n1TIF2lxaOAQZ5XXVJh7prEP6GpiLCrQo=',
			})
		})

		it('serves the build for the target asked, and leaves out assets with none', async () => {
			// C has no build at all, so no blank row: the client downloads nothing for it either
			// way, and a row with no Filename is the quieter failure.
			const quest = (await (
				await post(`target=2&version=227&id=${A}&id=${C}&id=${B}`)
			).json()) as Array<Record<string, unknown>>
			expect(quest).toEqual([
				{
					UnityAssetId: A,
					Target: 2,
					Version: 227,
					Filename: '2026-10-05/quest-a',
					Hash: 'quest-a-hash',
				},
			])
		})

		it('prefers the build at the requested version and falls back to the newest', async () => {
			const exact = (await (await post(`target=0&version=3&id=${B}`)).json()) as Array<{
				Version: number
			}>
			expect(exact.map((e) => e.Version)).toEqual([3])
			// A version nothing was built at still answers the asset — its newest build.
			const newest = (await (await post(`target=0&version=4&id=${B}`)).json()) as Array<{
				Version: number
			}>
			expect(newest.map((e) => e.Version)).toEqual([5])
			// No version at all: the newest.
			const none = (await (await post(`target=0&id=${B}`)).json()) as Array<{ Version: number }>
			expect(none.map((e) => e.Version)).toEqual([5])
		})

		it('matches ids case-insensitively and accepts a comma-separated list', async () => {
			const body = (await (
				await post(`target=0&version=227&id=${A.toUpperCase()},${B}`)
			).json()) as Array<{
				UnityAssetId: string
			}>
			expect(body.map((e) => e.UnityAssetId)).toEqual([A, B])
		})

		it('answers [] for no ids, an unknown id, or a non-integer target', async () => {
			expect(await (await post('target=0&version=227')).json()).toEqual([])
			expect(await (await post(`target=0&version=227&id=${C}`)).json()).toEqual([])
			expect(await (await post(`target=win&version=227&id=${A}`)).json()).toEqual([])
			expect(await (await post('')).json()).toEqual([])
		})
	})

	it('GET /openapi.json documents every route', async () => {
		const res = await SELF.fetch(`${ORIGIN}/openapi.json`)
		expect(res.status).toBe(200)
		const spec = (await res.json()) as {
			openapi: string
			paths: Record<string, Record<string, { summary?: string }>>
		}
		expect(spec.openapi).toMatch(/^3\.1/)

		// The spec route hides itself.
		expect(spec.paths['/openapi.json']).toBeUndefined()

		// Every route the worker serves is described. This is the drift guard: adding a
		// route without a describeRoute() block fails here rather than silently shipping
		// an incomplete spec. Hono's `:param` syntax becomes OpenAPI's `{param}`.
		const documented = new Set(
			Object.entries(spec.paths).flatMap(([path, ops]) =>
				Object.keys(ops).map((method) => `${method.toUpperCase()} ${path}`)
			)
		)
		expect([...documented].sort()).toEqual([
			'DELETE /rooms/{roomId}',
			'DELETE /rooms/{roomId}/bans/bulk',
			'DELETE /rooms/{roomId}/bans/{playerId}',
			'DELETE /rooms/{roomId}/interactionby/me/cheer',
			'DELETE /rooms/{roomId}/interactionby/me/favorite',
			'DELETE /rooms/{roomId}/leaderboards/{leaderboardId}',
			'DELETE /rooms/{roomId}/subrooms/{subRoomId}',
			'GET /',
			'GET /Room_server/rooms/{roomId}/bans/{playerId}/isBanned',
			'GET /dormroom/me',
			'GET /featuredrooms/current',
			'GET /photon_access_token',
			'GET /publishState/configs',
			'GET /rooms',
			'GET /rooms/autocomplete_search',
			'GET /rooms/base',
			'GET /rooms/bulk',
			'GET /rooms/carousel/foryou',
			'GET /rooms/carousel/rising',
			'GET /rooms/carousel/{name}',
			'GET /rooms/contributedby/me',
			'GET /rooms/createdby/me',
			'GET /rooms/curated_playlists',
			'GET /rooms/favoritedby/me',
			'GET /rooms/hot',
			'GET /rooms/ownedby/me',
			'GET /rooms/ownedby/{accountId}',
			'GET /rooms/recommendations',
			'GET /rooms/search',
			'GET /rooms/search/name',
			'GET /rooms/visitedby/me',
			'GET /rooms/visitedby/me/count',
			'GET /rooms/visitedby/{playerId}',
			'GET /rooms/{roomId}',
			'GET /rooms/{roomId}/bans',
			'GET /rooms/{roomId}/bans/history',
			'GET /rooms/{roomId}/bans/{playerId}/isBanned',
			'GET /rooms/{roomId}/boosts/count',
			'GET /rooms/{roomId}/boosts/{playerId}/count',
			'GET /rooms/{roomId}/experience',
			'GET /rooms/{roomId}/experience/player',
			'GET /rooms/{roomId}/interactionby/me',
			'GET /rooms/{roomId}/playerdata/me',
			'GET /rooms/{roomId}/roles',
			'GET /rooms/{roomId}/similar',
			'GET /rooms/{roomId}/subrooms/{subRoomId}/saves',
			'GET /rooms/{roomId}/subrooms/{subRoomId}/saves/no_unity_assets',
			'GET /rooms/{roomId}/subrooms/{subRoomId}/saves/{saveId}',
			'GET /rooms/{roomId}/subrooms/{subRoomId}/unityasset',
			'GET /roomserver/rooms/createdby/me',
			'GET /showcase/{playerId}',
			'POST /rooms/bulk',
			'POST /rooms/create',
			'POST /rooms/{roomId}/bans',
			'POST /rooms/{roomId}/boosts/counts',
			'POST /rooms/{roomId}/clone',
			'POST /rooms/{roomId}/experience',
			'POST /rooms/{roomId}/experience/player',
			'POST /rooms/{roomId}/leaderboards/{leaderboardId}',
			'POST /rooms/{roomId}/subrooms',
			'POST /rooms/{roomId}/subrooms/{subRoomId}/clone',
			'POST /rooms/{roomId}/subrooms/{subRoomId}/data',
			'POST /rooms/{roomId}/subrooms/{subRoomId}/datasaves/{saveId}/requestAutomatedModeration',
			'POST /rooms/{roomId}/subrooms/{subRoomId}/move',
			'POST /rooms/{roomId}/subrooms/{subRoomId}/publish_save',
			'POST /unity_assets/baked/bulk',
			'PUT /dormroom/me',
			'PUT /rooms/{roomId}/accessibility',
			'PUT /rooms/{roomId}/cloning',
			'PUT /rooms/{roomId}/creator',
			'PUT /rooms/{roomId}/description',
			'PUT /rooms/{roomId}/exclude',
			'PUT /rooms/{roomId}/image',
			'PUT /rooms/{roomId}/interactionby/me/cheer',
			'PUT /rooms/{roomId}/interactionby/me/favorite',
			'PUT /rooms/{roomId}/loadscreen',
			'PUT /rooms/{roomId}/max_player_calculation_mode',
			'PUT /rooms/{roomId}/name',
			'PUT /rooms/{roomId}/playerdata/me',
			'PUT /rooms/{roomId}/restrictions',
			'PUT /rooms/{roomId}/roles/{accountId}',
			'PUT /rooms/{roomId}/roles/{accountId}/invite',
			'PUT /rooms/{roomId}/subrooms/{subRoomId}/accessibility',
			'PUT /rooms/{roomId}/subrooms/{subRoomId}/modify',
			'PUT /rooms/{roomId}/subrooms/{subRoomId}/permissions',
			'PUT /rooms/{roomId}/tags',
			'PUT /rooms/{roomId}/v2/restrictions',
			'PUT /rooms/{roomId}/warning',
		])

		// Every operation carries a summary — a path present but undescribed is not
		// documentation.
		for (const ops of Object.values(spec.paths)) {
			for (const op of Object.values(ops)) expect(op.summary).toBeTruthy()
		}
	})
})
