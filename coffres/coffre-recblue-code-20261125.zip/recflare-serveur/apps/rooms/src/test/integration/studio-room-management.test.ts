// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { seedRoomWithSubRooms } from '@repo/domain'

import { bearer, ORIGIN, setupSchema } from './support/harness'

import type { Room } from '@repo/domain'

beforeAll(setupSchema)

describe('Studio room management contracts', () => {
	it('lists private co-owned rooms, but excludes hosts and pending invites', async () => {
		for (const [id, role, invited] of [
			[91001, 30, 0],
			[91002, 10, 0],
			[91003, 0, 30],
		]) {
			await seedRoomWithSubRooms(env.DB, {
				RoomId: id,
				Name: `StudioRole${id}`,
				CreatorAccountId: 999,
				Accessibility: 0,
				Roles: [{ AccountId: 880, Role: role, InvitedRole: invited }],
				SubRooms: [],
			})
		}
		const rooms = (await (
			await SELF.fetch(`${ORIGIN}/rooms/ownedby/me`, { headers: await bearer('880') })
		).json()) as Array<{ RoomId: number }>
		expect(rooms.map((r) => r.RoomId)).toEqual([91001])
		expect(
			await (
				await SELF.fetch(`${ORIGIN}/rooms/createdby/me`, { headers: await bearer('880') })
			).json()
		).toEqual([])
	})
	it('returns null for Studio name validation and preserves the legacy empty object', async () => {
		expect(
			await (await SELF.fetch(`${ORIGIN}/rooms?name=StudioUnusedName&include=525581`)).json()
		).toBeNull()
		expect(await (await SELF.fetch(`${ORIGIN}/rooms?name=StudioUnusedName`)).json()).toEqual({})
	})
	it('creates a private empty R2 room and rejects a case-insensitive duplicate', async () => {
		const create = async (name: string, auth = true) =>
			SELF.fetch(`${ORIGIN}/rooms/create`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					...(auth ? await bearer('880') : {}),
				},
				body: new URLSearchParams({ name, ugcVersion: '2' }).toString(),
			})
		expect((await create('StudioFreshRoom', false)).status).toBe(401)
		const response = await create('StudioFreshRoom')
		expect(response.status).toBe(200)
		const room = (await response.json()) as Room
		expect(room).toMatchObject({
			Name: 'StudioFreshRoom',
			UgcVersion: 2,
			Accessibility: 0,
			CreatorAccountId: 880,
			Tags: [],
			LoadScreens: [],
			RestrictedCircuitsAllowListNames: [],
			PublishedAt: null,
		})
		expect(room.SubRooms).toEqual([
			expect.objectContaining({
				Name: 'Home',
				CreatorAccountId: 880,
				CurrentSave: expect.objectContaining({ DataBlob: null, OMVersion: 198 }),
				UnitySceneId: '5d4e40d8-f289-4295-a6e1-4f907835007d',
			}),
		])
		const added = await SELF.fetch(`${ORIGIN}/rooms/${Number(room.RoomId)}/subrooms`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...(await bearer('880')) },
			body: 'name=Second',
		})
		expect(added.status).toBe(200)
		const lookup = await SELF.fetch(`${ORIGIN}/rooms/${Number(room.RoomId)}?include=525581`, {
			headers: await bearer('1', ['developer']),
		})
		const refreshed = await lookup.json<
			Room & { SubRooms: Array<{ SubRoomId: number; CurrentSave: unknown }> }
		>()
		expect(refreshed.SubRooms).toHaveLength(2)
		for (const sub of refreshed.SubRooms) {
			expect(sub.CurrentSave).toMatchObject({ DataBlob: null, OMVersion: 198 })
		}
		const initial = refreshed.SubRooms[0]!.CurrentSave as { SubRoomDataSaveId: number }
		const subRoomId = Number(refreshed.SubRooms[0]!.SubRoomId)
		const initialSave = await SELF.fetch(
			`${ORIGIN}/rooms/${Number(room.RoomId)}/subrooms/${subRoomId}/saves/${initial.SubRoomDataSaveId}`,
			{ headers: await bearer('880') }
		)
		expect(initialSave.status).toBe(200)
		expect(await initialSave.json()).toMatchObject({ DataBlob: null, OMVersion: 198 })
		for (const fields of [{ OMVersion: 197, UgcSubVersion: 3 }, {}]) {
			const saved = await SELF.fetch(
				`${ORIGIN}/rooms/${Number(room.RoomId)}/subrooms/${subRoomId}/data`,
				{
					method: 'POST',
					headers: { 'Content-Type': 'application/json', ...(await bearer('880')) },
					body: JSON.stringify({ ...fields, AutoPublish: true }),
				}
			)
			expect(saved.status).toBe(200)
			const updated = await (
				await SELF.fetch(`${ORIGIN}/rooms/${Number(room.RoomId)}?include=525581`, {
					headers: await bearer('1', ['developer']),
				})
			).json<Room & { SubRooms: Array<{ CurrentSave: unknown }> }>()
			expect(updated.SubRooms[0]!.CurrentSave).toMatchObject({ OMVersion: 197, UgcSubVersion: 3 })
		}
		expect((await create('studiofreshroom')).status).toBe(409)
		expect((await create('bad name')).status).toBe(400)
		expect(
			(
				await SELF.fetch(`${ORIGIN}/rooms/${Number(room.RoomId)}`, {
					method: 'DELETE',
					headers: await bearer('880'),
				})
			).status
		).toBe(200)
	})
	it('keeps fresh R1 rooms owned and their new subrooms visible to the Studio picker', async () => {
		const response = await SELF.fetch(`${ORIGIN}/rooms/create`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...(await bearer('880')) },
			body: new URLSearchParams({ name: 'StudioFreshR1', ugcVersion: '1' }).toString(),
		})
		expect(response.status).toBe(200)
		const created = await response.json<Room>()
		const roomId = Number(created.RoomId)
		expect(created.Roles).toEqual([expect.objectContaining({ AccountId: 880, Role: 255 })])
		const added = await SELF.fetch(`${ORIGIN}/rooms/${roomId}/subrooms`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...(await bearer('880')) },
			body: 'name=Second',
		})
		expect(added.status).toBe(200)
		// Unpublished: a name lookup finds it for its owner, not for anyone else.
		const anonymous = await SELF.fetch(`${ORIGIN}/rooms?name=StudioFreshR1&include=525581`)
		expect(await anonymous.json()).toBeNull()
		expect((await SELF.fetch(`${ORIGIN}/rooms/${roomId}`)).status).toBe(404)
		const stranger = { headers: await bearer('999') }
		expect((await SELF.fetch(`${ORIGIN}/rooms/${roomId}`, stranger)).status).toBe(404)
		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/${roomId}`, { headers: await bearer('880') })).status
		).toBe(200)
		const lookup = await SELF.fetch(`${ORIGIN}/rooms?name=StudioFreshR1&include=525581`, {
			headers: await bearer('880'),
		})
		const room = await lookup.json<Room & { SubRooms: Array<{ SubRoomId: number }> }>()
		expect(room.SubRooms).toEqual([
			expect.objectContaining({
				Name: 'Home',
				CurrentSave: null,
				UnitySceneId: 'a75f7547-79eb-47c6-8986-6767abcb4f92',
			}),
			expect.objectContaining({
				Name: 'Second',
				CurrentSave: null,
				UnitySceneId: 'a75f7547-79eb-47c6-8986-6767abcb4f92',
			}),
		])
		for (const path of ['/rooms/ownedby/me', '/rooms/createdby/me']) {
			const rooms = await (
				await SELF.fetch(ORIGIN + path, { headers: await bearer('880') })
			).json<Room[]>()
			expect(rooms.some((entry) => entry.RoomId === created.RoomId)).toBe(true)
		}
		const history = await SELF.fetch(
			`${ORIGIN}/rooms/${roomId}/subrooms/${room.SubRooms[0]!.SubRoomId}/saves/no_unity_assets`,
			{ headers: await bearer('880') }
		)
		expect(history.status).toBe(200)
		expect(await history.json()).toMatchObject({ Results: [] })
		expect(
			(
				await SELF.fetch(`${ORIGIN}/rooms/${roomId}`, {
					method: 'DELETE',
					headers: await bearer('880'),
				})
			).status
		).toBe(200)
	})

	it('saves the Studio age rating through v2 restrictions with ownership checks', async () => {
		const before = await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json<Room>()
		const update = async (body: string, account?: string) =>
			SELF.fetch(`${ORIGIN}/rooms/2/v2/restrictions`, {
				method: 'PUT',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					...(account ? await bearer(account) : {}),
				},
				body,
			})
		expect((await update('ageRating=1')).status).toBe(401)
		expect((await update('ageRating=1', '999')).status).toBe(403)
		const result = await update('ageRating=1&supportsScreens=True&supportsWalkVR=False', '1')
		expect(result.status).toBe(200)
		expect(await result.json()).toMatchObject({
			Success: true,
			Error: null,
			Value: {
				AgeRating: 1,
				SupportsScreens: true,
				SupportsWalkVR: false,
				LoadScreens: before.LoadScreens,
			},
		})
		const invalid = await update('ageRating=99', '1')
		expect(await invalid.json()).toEqual({
			Success: false,
			Error: 'Invalid age rating.',
			Value: null,
		})
		expect(
			(
				await (
					await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
				).json<Room>()
			).AgeRating
		).toBe(1)
		await update('ageRating=2&supportsWalkVR=True', '1')
	})

	it('does not advertise an archived baked asset as editable source', async () => {
		const id = '11111111-2222-4333-8444-555555555555'
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 91004,
			Name: 'StudioArchivedGame',
			CreatorAccountId: 880,
			Roles: [],
			SubRooms: [
				{
					SubRoomId: 91004,
					Name: 'Home',
					CurrentSave: {
						UnityAssetId: id,
						DataBlob: 'original-game.room',
						SavedOnPlatform: 0,
						SavedOnDeviceClass: 2,
						SavedByAccountId: 880,
						CreatedAt: '2026-01-01T00:00:00Z',
					},
				},
			],
		})
		const headers = await bearer('880')
		const url = `${ORIGIN}/rooms/91004/subrooms/91004/saves/no_unity_assets`
		const studio = (await (
			await SELF.fetch(url, { headers: { ...headers, 'User-Agent': 'RRStudio' } })
		).json()) as { Results: Array<Record<string, unknown>> }
		expect(studio.Results[0]).toMatchObject({ UnityAssetId: null, DataBlob: 'original-game.room' })
		const legacy = (await (await SELF.fetch(url, { headers })).json()) as typeof studio
		expect(legacy.Results[0]!.UnityAssetId).toBe(id)
		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/91004/subrooms/91004/unityasset?unityAssetId=${id}`))
				.status
		).toBe(404)
		const original = (await (
			await SELF.fetch(`${ORIGIN}/rooms/91004`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			SubRooms: Array<{ CurrentSave: Record<string, unknown> }>
		}
		expect(original.SubRooms[0]!.CurrentSave.UnityAssetId).toBe(id)
	})
	it('persists source manifests and returns them independently of baked builds', async () => {
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 91005,
			Name: 'StudioSourceRoom',
			CreatorAccountId: 880,
			Roles: [],
			SubRooms: [{ SubRoomId: 91005, Name: 'Home', CurrentSave: null }],
		})
		const id = '22222222-3333-4444-8555-666666666666'
		const saved = await SELF.fetch(`${ORIGIN}/rooms/91005/subrooms/91005/data`, {
			method: 'POST',
			headers: { ...(await bearer('880')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				UnityAssetId: id,
				UnityAsset: { Filename: 'manifest.json', Hash: 'source-hash' },
				SubRoomData: { Filename: 'maker.room' },
				AutoPublish: true,
			}),
		})
		expect(saved.status).toBe(200)
		const source = await (
			await SELF.fetch(`${ORIGIN}/rooms/91005/subrooms/91005/unityasset?unityAssetId=${id}`)
		).json()
		expect(source).toMatchObject({
			unityAssetId: id,
			filename: 'manifest.json',
			hash: 'source-hash',
			bakedUnityAssets: [],
		})
		const history = (await (
			await SELF.fetch(`${ORIGIN}/rooms/91005/subrooms/91005/saves/no_unity_assets`, {
				headers: { ...(await bearer('880')), 'User-Agent': 'RRStudio' },
			})
		).json()) as { Results: Array<Record<string, unknown>> }
		expect(history.Results[0]).toMatchObject({
			UnityAssetId: id,
			SavedOnPlatform: null,
			SavedOnDeviceClass: null,
		})
	})
})
