// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { createRoomInstance, getRoomInstance } from '@repo/domain'

import { NotificationType } from '../../../../notify/src/notification-types'
import { bearer, bodyOf, clearPresence, envOf, ORIGIN, putForm, setupSchema, subRoomOf } from './support/harness'

beforeAll(setupSchema)

describe('rooms endpoints', () => {
	it('room_instance: create + read round-trips and hides JsonIgnore fields', async () => {
		const created = await createRoomInstance(env.DB, {
			ownerAccountId: 5,
			roomId: 2,
			subRoomId: 3,
			photonRoomId: crypto.randomUUID(),
			name: '^RecCenter',
			maxCapacity: 20,
			isPrivate: true,
			encryptVoiceChat: true,
		})
		// The DB assigns a sequential id, mapped to `roomInstanceId` in the DTO.
		expect(created.roomInstanceId).toBeGreaterThan(0)
		expect(created.roomId).toBe(2)
		expect(created.isPrivate).toBe(true)
		expect(created.EncryptVoiceChat).toBe(true) // PascalCase JSON key, per the reference

		// Reads back identically; JsonIgnore columns are not in the DTO.
		const fetched = await getRoomInstance(env.DB, created.roomInstanceId)
		expect(fetched).toEqual(created)
		expect('ownerAccountId' in (fetched as object)).toBe(false)
		expect('dataBlob' in (fetched as object)).toBe(false)
		expect('allowNewUsers' in (fetched as object)).toBe(false)
	})

	it('GET /photon_access_token 401s without a token', async () => {
		expect((await SELF.fetch(`${ORIGIN}/photon_access_token`)).status).toBe(401)
	})

	it('GET /photon_access_token gives a VISITOR no build permissions, with their presence instance', async () => {
		// Seed the caller's presence so RoomInstanceId reflects their current instance.
		await env.DB.prepare('INSERT OR REPLACE INTO presence (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					accountId: 777,
					roomInstance: { roomInstanceId: 1000042, roomId: 2, subRoomId: 2 },
					expiresAt: Math.floor(Date.now() / 1000) + 900,
				})
			)
			.run()
		const res = await SELF.fetch(`${ORIGIN}/photon_access_token`, { headers: await bearer('777') })
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			Permissions: Array<{ Permission: string; Role: number; Override: boolean; Value: string }>
			PhotonAccessToken: string
			RoomInstanceId: number | null
		}
		expect(body.RoomInstanceId).toBe(1000042)
		expect(body.PhotonAccessToken).toBe('')
		// 777 holds no role in room 2: one Role 0 row per permission, every one of them False.
		// Serving True here handed every visitor the delete-all button.
		expect(body.Permissions.map((p) => p.Permission)).toEqual([
			'CAN_USE_MAKER_PEN',
			'CAN_USE_ROOM_RESET_BUTTON',
			'CAN_USE_DELETE_ALL_BUTTON',
			'CAN_SAVE_INVENTIONS',
			'CAN_SPAWN_INVENTIONS',
			'CAN_USE_PLAY_GIZMOS_TOGGLE',
		])
		for (const p of body.Permissions) {
			// Les inventions sont ouvertes à tous (sinon le client grise « Make Invention ») ;
			// les boutons destructeurs, eux, restent fermés à un visiteur.
			const invention =
				p.Permission === 'CAN_SAVE_INVENTIONS' || p.Permission === 'CAN_SPAWN_INVENTIONS'
			expect(p).toMatchObject({
				Role: 0,
				Override: true,
				Type: 0,
				Value: invention ? 'True' : 'False',
			})
		}
	})

	it('GET /photon_access_token returns null RoomInstanceId when the caller has no presence', async () => {
		const res = await SELF.fetch(`${ORIGIN}/photon_access_token`, { headers: await bearer('888') })
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			RoomInstanceId: number | null
			Permissions: Array<{ Permission: string; Value: string }>
		}
		expect(body.RoomInstanceId).toBeNull()
		// In no room, they are nobody's manager: the destructive permissions stay closed. The
		// invention ones are open regardless — that is what un-greys « Make Invention ».
		expect(body.Permissions.filter((p) => p.Value === 'True').map((p) => p.Permission)).toEqual([
			'CAN_SAVE_INVENTIONS',
			'CAN_SPAWN_INVENTIONS',
		])
	})

	it('GET /photon_access_token gives the room’s MANAGERS every build permission', async () => {
		// Room 2 is account 1's, with account 2 a co-owner (Role 30).
		const tableFor = async (accountId: number) => {
			await env.DB.prepare('INSERT OR REPLACE INTO presence (data) VALUES (?1)')
				.bind(
					JSON.stringify({
						accountId,
						roomInstance: { roomInstanceId: 1000043, roomId: 2, subRoomId: 2 },
						expiresAt: Math.floor(Date.now() / 1000) + 900,
					})
				)
				.run()
			const res = await SELF.fetch(`${ORIGIN}/photon_access_token`, {
				headers: await bearer(String(accountId)),
			})
			return (
				(await res.json()) as {
					Permissions: Array<{
						Permission: string
						Role: number
						Override: boolean
						Value: string
					}>
				}
			).Permissions
		}
		// A manager gets the WHOLE table — a row per permission for every role tier, grouped
		// by role — because the permissions screen reads each cell from the row at exactly
		// that role. Nothing is stored on subroom 2 here, so every row is a default
		// (`Override: false`): co-owner and creator rows True, the rest False.
		const roles = [0, 10, 20, 25, 30, 255]
		for (const table of [await tableFor(1), await tableFor(2)]) {
			expect(table.length).toBe(36)
			expect(table.map((p) => p.Role)).toEqual(roles.flatMap((r) => Array<number>(6).fill(r)))
			for (const p of table) {
				// Les inventions sont ouvertes par défaut à tous les rôles (sinon le client grise
				// « Make Invention ») ; le reste suit la règle des managers.
				const invention =
					p.Permission === 'CAN_SAVE_INVENTIONS' || p.Permission === 'CAN_SPAWN_INVENTIONS'
				expect(p).toMatchObject({
					Override: false,
					Value: p.Role >= 30 || invention ? 'True' : 'False',
				})
			}
		}
		await env.DB.prepare('DELETE FROM presence WHERE account_id IN (1, 2)').run()
	})

	it('GET /photon_access_token grants the global maker pen to dev accounts (1/2/3), and inventions to everyone', async () => {
		for (const sub of ['1', '2', '3']) {
			// Out of any room: a visitor with the dev maker pen.
			const res = await SELF.fetch(`${ORIGIN}/photon_access_token`, { headers: await bearer(sub) })
			expect(res.status).toBe(200)
			const body = (await res.json()) as {
				Permissions: Array<{ Permission: string; Role: number; Override: boolean; Value: string }>
			}
			expect(body.Permissions[0]).toEqual({
				Override: true,
				Permission: 'CAN_USE_MAKER_PEN',
				Role: 0,
				Type: 0,
				Value: 'True',
			})
			// Seules les inventions suivent la Maker Pen : rien d'autre n'est accordé à un visiteur.
			expect(
				body.Permissions.slice(1)
					.filter((p) => p.Value === 'True')
					.map((p) => p.Permission)
			).toEqual(['CAN_SAVE_INVENTIONS', 'CAN_SPAWN_INVENTIONS'])
		}
	})

	it('interaction: defaults to false, cheer/favorite toggle and persist', async () => {
		type Interaction = { Cheered: boolean; Favorited: boolean; LastVisitedAt: string }
		const headers = await bearer('555')
		const get = async () =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me`, { headers })
			).json()) as Interaction
		const put = async (action: 'cheer' | 'favorite') =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/${action}`, {
					method: 'PUT',
					headers,
				})
			).json()) as Interaction

		// No row yet → both false.
		expect(await get()).toMatchObject({ Cheered: false, Favorited: false })

		// Cheer on, then favorite on.
		expect(await put('cheer')).toMatchObject({ Cheered: true, Favorited: false })
		expect(await put('favorite')).toMatchObject({ Cheered: true, Favorited: true })
		// Persisted across a fresh GET.
		expect(await get()).toMatchObject({ Cheered: true, Favorited: true })

		// Toggling again flips back.
		expect(await put('cheer')).toMatchObject({ Cheered: false, Favorited: true })

		// Scoped per player — a different account starts fresh.
		const other = await bearer('556')
		const otherGet = (await (
			await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me`, { headers: other })
		).json()) as Interaction
		expect(otherGet).toMatchObject({ Cheered: false, Favorited: false })
	})

	it('room Stats count cheers/favorites on the room row, kept by the toggles', async () => {
		type Stats = {
			CheerCount: number
			FavoriteCount: number
			VisitorCount: number
			VisitCount: number
		}
		// Room 15 (CrimsonCauldron) is untouched by the other interaction tests.
		const searched = async (): Promise<Stats> => {
			const body = (await (
				await SELF.fetch(`${ORIGIN}/rooms/search?query=crimsoncauldron`)
			).json()) as { Results: Array<{ Stats: Stats }> }
			return body.Results[0]!.Stats
		}
		const direct = async (): Promise<Stats> =>
			(
				(await (
					await SELF.fetch(`${ORIGIN}/rooms/15`, { headers: await bearer('1', ['developer']) })
				).json()) as { Stats: Stats }
			).Stats
		const interact = async (player: string, action: string, method: string) =>
			SELF.fetch(`${ORIGIN}/rooms/15/interactionby/me/${action}`, {
				method,
				headers: await bearer(player),
			})

		// Nobody has interacted with it yet.
		expect(await searched()).toEqual({
			CheerCount: 0,
			FavoriteCount: 0,
			VisitorCount: 0,
			VisitCount: 0,
		})

		// Two players cheer it; one of them also favorites it.
		await interact('561', 'cheer', 'PUT')
		await interact('562', 'cheer', 'PUT')
		await interact('561', 'favorite', 'PUT')

		// Both the search results and the room itself report the aggregate.
		expect(await searched()).toMatchObject({ CheerCount: 2, FavoriteCount: 1 })
		expect(await direct()).toMatchObject({ CheerCount: 2, FavoriteCount: 1 })

		// Clearing a cheer decrements it. Visits are counted by the `match` worker on
		// matchmake and nobody has entered this room, so those stay 0.
		await interact('562', 'cheer', 'DELETE')
		expect(await direct()).toEqual({
			CheerCount: 1,
			FavoriteCount: 1,
			VisitorCount: 0,
			VisitCount: 0,
		})

		// The counts are columns on the room, not an aggregate taken on read — the toggles
		// keep them. A repeated clear changes nothing (the flag was already off), and neither
		// does clearing a flag a player never set, so neither counts down again.
		await interact('562', 'cheer', 'DELETE')
		await interact('563', 'favorite', 'DELETE')
		expect(await direct()).toMatchObject({ CheerCount: 1, FavoriteCount: 1 })
		expect(
			await env.DB.prepare('SELECT cheers, favorites FROM room WHERE room_id = 15').first()
		).toEqual({ cheers: 1, favorites: 1 })
		// Toggling off and on again lands back where it started.
		await interact('561', 'cheer', 'PUT')
		expect(await direct()).toMatchObject({ CheerCount: 0 })
		await interact('561', 'cheer', 'PUT')
		expect(await direct()).toMatchObject({ CheerCount: 1 })

		// VisitCount is the `room.visits` column (what match bumps on each matchmake),
		// served on every read of the room — here and in the search results — and it
		// survives the cheer/favorite aggregation rather than being zeroed by it.
		await env.DB.prepare('UPDATE room SET visits = 7 WHERE room_id = 15').run()
		expect(await direct()).toEqual({
			CheerCount: 1,
			FavoriteCount: 1,
			VisitorCount: 0,
			VisitCount: 7,
		})
		expect(await searched()).toMatchObject({ VisitCount: 7 })

		// A write to the room doesn't bake the count into the blob (nor reset it).
		// Account 1 created room 15, so the description write is allowed.
		const wrote = await SELF.fetch(`${ORIGIN}/rooms/15/description`, {
			method: 'PUT',
			headers: {
				...(await bearer('1')),
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: new URLSearchParams({ description: 'counted' }).toString(),
		})
		expect(wrote.status).toBe(200)
		const blob = await env.DB.prepare('SELECT data FROM room WHERE room_id = 15').first<{
			data: string
		}>()
		expect((JSON.parse(blob!.data) as { Stats: Stats }).Stats.VisitCount).toBe(0)
		expect(await direct()).toMatchObject({ VisitCount: 7 })
	})

	it('DELETE /rooms/:id/interactionby/me/cheer clears the cheer (auth-gated, idempotent)', async () => {
		type Interaction = { Cheered: boolean; Favorited: boolean }
		const headers = await bearer('557')
		const del = () =>
			SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/cheer`, { method: 'DELETE', headers })

		// No token → 401.
		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/cheer`, { method: 'DELETE' })).status
		).toBe(401)

		// Cheer + favorite on, then DELETE clears only the cheer (favorite untouched).
		await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/cheer`, { method: 'PUT', headers })
		await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/favorite`, { method: 'PUT', headers })
		expect(await (await del()).json()).toMatchObject({ Cheered: false, Favorited: true })

		// Idempotent — a second DELETE stays cleared.
		expect(await (await del()).json()).toMatchObject({ Cheered: false, Favorited: true })

		// Idempotent on a never-interacted room, and it doesn't create a visited row.
		const fresh = await bearer('558')
		const res = await SELF.fetch(`${ORIGIN}/rooms/2/interactionby/me/cheer`, {
			method: 'DELETE',
			headers: fresh,
		})
		expect(await res.json()).toMatchObject({ Cheered: false, Favorited: false })
		const visited = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/me`, { headers: fresh })
		).json()) as unknown[]
		expect(visited).toEqual([])
	})

	it('DELETE /rooms/:id/interactionby/me/favorite clears the favorite (auth-gated, idempotent)', async () => {
		const headers = await bearer('559')
		const del = () =>
			SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/favorite`, { method: 'DELETE', headers })

		// No token → 401.
		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/favorite`, { method: 'DELETE' }))
				.status
		).toBe(401)

		// Favorite + cheer on, then DELETE clears only the favorite (cheer untouched).
		await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/favorite`, { method: 'PUT', headers })
		await SELF.fetch(`${ORIGIN}/rooms/12/interactionby/me/cheer`, { method: 'PUT', headers })
		expect(await (await del()).json()).toMatchObject({ Cheered: true, Favorited: false })
		// It drops out of the caller's favorited list.
		const favs = (await (
			await SELF.fetch(`${ORIGIN}/rooms/favoritedby/me`, { headers })
		).json()) as unknown[]
		expect(favs).toEqual([])

		// Idempotent — a second DELETE stays cleared.
		expect(await (await del()).json()).toMatchObject({ Cheered: true, Favorited: false })

		// Idempotent on a never-interacted room, without creating a visited row.
		const fresh = await bearer('560')
		const res = await SELF.fetch(`${ORIGIN}/rooms/2/interactionby/me/favorite`, {
			method: 'DELETE',
			headers: fresh,
		})
		expect(await res.json()).toMatchObject({ Cheered: false, Favorited: false })
		const visited = (await (
			await SELF.fetch(`${ORIGIN}/rooms/visitedby/me`, { headers: fresh })
		).json()) as unknown[]
		expect(visited).toEqual([])
	})

	it('PUT /rooms/:id/subrooms/:sid/modify is auth-gated, owner-only, and persists subroom settings', async () => {
		const fields = { name: 'MyCoolSubroom', accessibility: '1', maxPlayers: '20' }
		// No token → 401 (auth gate).
		expect((await putForm('/rooms/2/subrooms/2/modify', fields)).status).toBe(401)
		// Not the owner (room 2 is owned by account 1) → NotOwner.
		expect(await bodyOf(await putForm('/rooms/2/subrooms/2/modify', fields, '999'))).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.NotOwner',
		})
		// Unknown room → DoesntExist.
		expect(
			await bodyOf(await putForm('/rooms/99999/subrooms/2/modify', fields, '1'))
		).toMatchObject({ Success: false, ErrorId: 'Rooms.DoesntExist' })
		// Unknown subroom → DoesntExist.
		expect(await bodyOf(await putForm('/rooms/2/subrooms/9999/modify', fields, '1'))).toMatchObject(
			{ Success: false, ErrorId: 'Rooms.DoesntExist' }
		)
		// Empty name → InvalidName.
		expect(
			await bodyOf(await putForm('/rooms/2/subrooms/2/modify', { ...fields, name: '  ' }, '1'))
		).toMatchObject({ Success: false, ErrorId: 'Rooms.InvalidName' })

		// Owner updates the subroom → Success, and it persists on the subroom descriptor.
		const ok = await putForm('/rooms/2/subrooms/2/modify', fields, '1')
		expect(ok.status).toBe(200)
		expect(await bodyOf(ok)).toMatchObject({ Success: true })
		const sub = (await subRoomOf(2, 2)) as unknown as {
			Name: string
			Accessibility: number
			MaxPlayers: number
		}
		expect(sub).toMatchObject({ Name: 'MyCoolSubroom', Accessibility: 1, MaxPlayers: 20 })
	})

	it('PUT /rooms/:id/subrooms/:sid/accessibility takes the enum name the client sends', async () => {
		const path = '/rooms/2/subrooms/2/accessibility'
		const accessibilityOf = async () =>
			((await subRoomOf(2, 2)) as unknown as { Accessibility: number }).Accessibility

		// No token → 401.
		expect((await putForm(path, { accessibility: 'Private' })).status).toBe(401)
		// Not the owner (room 2 is owned by account 1) → failure envelope.
		expect(await envOf(await putForm(path, { accessibility: 'Private' }, '999'))).toMatchObject({
			success: false,
			error: 'You are not the owner of this room!',
		})
		// Unknown room / unknown subroom → failure envelope.
		expect(
			await envOf(
				await putForm('/rooms/99999/subrooms/2/accessibility', { accessibility: '0' }, '1')
			)
		).toMatchObject({ success: false })
		expect(
			await envOf(
				await putForm('/rooms/2/subrooms/9999/accessibility', { accessibility: '0' }, '1')
			)
		).toMatchObject({ success: false })
		// A value that names nothing in the enum → rejected, not silently stored.
		expect(await envOf(await putForm(path, { accessibility: 'Nonsense' }, '1'))).toMatchObject({
			success: false,
			error: 'You must provide a valid accessibility!',
		})

		// The name form is what the live client sends.
		const priv = await envOf(await putForm(path, { accessibility: 'Private' }, '1'))
		expect(priv.success).toBe(true)
		// The envelope carries the updated ROOM, so the client can re-render the subroom list.
		expect(priv.value).toMatchObject({ RoomId: 2 })
		expect(await accessibilityOf()).toBe(0)

		// Case-insensitive, and the later enum members resolve too.
		expect((await envOf(await putForm(path, { accessibility: 'dev_unlisted' }, '1'))).success).toBe(
			true
		)
		expect(await accessibilityOf()).toBe(4)

		// The ordinal still works.
		expect((await envOf(await putForm(path, { accessibility: '1' }, '1'))).success).toBe(true)
		expect(await accessibilityOf()).toBe(1)
	})

	// The permission table a room's creator saves on a subroom, and how it reaches the
	// client: `PUT …/permissions` stores entries keyed by (Permission, Role), and
	// `GET /photon_access_token` builds the table for whoever is standing in that subroom,
	// from the entries that reach THEIR role over the role's defaults. Room 2 / subroom 2 is
	// owned by account 1, with account 2 a co-owner; 743–747 are visitors whose presence
	// points at it.
	describe('subroom permissions', () => {
		type Permission = { Permission: string; Role: number; Override: boolean; Type: number; Value: string }

		const putPermissions = async (path: string, body: unknown, sub?: string) =>
			SELF.fetch(`${ORIGIN}${path}`, {
				method: 'PUT',
				headers: { ...(sub ? await bearer(sub) : {}), 'Content-Type': 'application/json' },
				body: JSON.stringify(body),
			})

		// Put a player in an instance of the given subroom, then read the permission table
		// the client would apply when it spawns there.
		const permissionsIn = async (accountId: number, subRoomId: number): Promise<Permission[]> => {
			await env.DB.prepare('INSERT OR REPLACE INTO presence (data) VALUES (?1)')
				.bind(
					JSON.stringify({
						accountId,
						roomInstance: { roomInstanceId: 1000900 + subRoomId, roomId: 2, subRoomId },
						expiresAt: Math.floor(Date.now() / 1000) + 900,
					})
				)
				.run()
			const res = await SELF.fetch(`${ORIGIN}/photon_access_token`, {
				headers: await bearer(String(accountId)),
			})
			expect(res.status).toBe(200)
			return ((await res.json()) as { Permissions: Permission[] }).Permissions
		}

		/**
		 * The value a non-manager's table serves for a permission (every row of theirs
		 * agrees), or the value a manager's table serves at one role (`at`): the cell the
		 * permissions screen draws for that pair.
		 */
		const valueOf = (list: Permission[], permission: string, at?: number) => {
			const rows = list.filter(
				(p) => p.Permission === permission && (at === undefined || p.Role === at)
			)
			const values = new Set(rows.map((p) => p.Value))
			expect(values.size).toBeLessThanOrEqual(1)
			return [...values][0]
		}
		/** One cell of a manager's table, as the permissions screen reads it. */
		const cell = (list: Permission[], permission: string, at: number) =>
			list.find((p) => p.Permission === permission && p.Role === at)
		// Room 2's seeded co-owner is account 2 — one of the hardcoded dev accounts, whose
		// global maker pen no table takes away — so the role-holder cases use 748 (a Host)
		// and 749 (a co-owner), given their roles here.
		const setRoles = async () => {
			await env.DB.prepare(
				`UPDATE room SET data = json_set(data, '$.Roles', json(?1)) WHERE room_id = 2`
			)
				.bind(
					JSON.stringify([
						{ AccountId: 2, Role: 30 },
						{ AccountId: 748, Role: 10 },
						{ AccountId: 749, Role: 30 },
						{ AccountId: 750, Role: 25 },
					])
				)
				.run()
		}

		type Envelope = {
			Value: { RoomId: number; SubRooms: unknown[] } | null
			Success: boolean
			Error: string | null
			error_id: null
		}
		const refusal = async (res: Response): Promise<string | null> => {
			expect(res.status).toBe(200)
			const env = (await res.json()) as Envelope
			expect(env.Success).toBe(false)
			expect(env.Value).toBeNull()
			expect(env.error_id).toBeNull()
			return env.Error
		}

		it('is auth-gated and open to the room’s managers only', async () => {
			const body = [
				{ Permission: 'CAN_SAVE_INVENTIONS', Role: 30, Override: false, Type: 0, Value: 'True' },
			]
			// No token → 401.
			expect((await putPermissions('/rooms/2/subrooms/2/permissions', body)).status).toBe(401)
			// A valid token that isn't the room's creator or a co-owner → a `Success: false`
			// rejection, as the other PascalCase-envelope routes answer.
			expect(
				await refusal(await putPermissions('/rooms/2/subrooms/2/permissions', body, '999'))
			).toBe('You are not the owner of this room!')
			// A co-owner may: account 2 holds Role 30 on the seeded rooms. (This body clears a
			// pair that was never stored, so it changes nothing.)
			expect((await putPermissions('/rooms/2/subrooms/2/permissions', body, '2')).status).toBe(200)
			// A Host (a lower tier) may not.
			await setRoles()
			expect(
				await refusal(await putPermissions('/rooms/2/subrooms/2/permissions', body, '748'))
			).toBe('You are not the owner of this room!')
			// Unknown room / unknown subroom.
			expect(
				await refusal(await putPermissions('/rooms/99999/subrooms/2/permissions', body, '1'))
			).toBe('This room does not exist!')
			// A subroom id belonging to another room doesn't resolve either.
			expect(
				await refusal(await putPermissions('/rooms/2/subrooms/9999/permissions', body, '1'))
			).toBe('This subroom does not exist!')
		})

		it('answers the whole room in the PascalCase `{ Value, Success, Error, error_id }` envelope', async () => {
			const res = await putPermissions(
				'/rooms/2/subrooms/2/permissions',
				[{ Permission: 'CAN_SPAWN_INVENTIONS', Role: 30, Override: true, Type: 0, Value: 'True' }],
				'1'
			)
			expect(res.status).toBe(200)
			const env = (await res.json()) as Envelope
			expect(env.Success).toBe(true)
			expect(env.Error).toBeNull()
			expect(env.error_id).toBeNull()
			// `Value` is the same Room DTO `GET /rooms/2` serves — subrooms re-attached and all.
			const room = (await (
				await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1') })
			).json()) as Envelope['Value']
			expect(env.Value).toEqual(room)
		})

		it('a Role 0 grant reaches a visitor; a Role 30 grant does not', async () => {
			// Rien n'est stocké pour tout le monde : les inventions sont ouvertes par défaut, les
			// boutons destructeurs ne le sont pas.
			expect(valueOf(await permissionsIn(743, 2), 'CAN_SPAWN_INVENTIONS')).toBe('True')
			expect(valueOf(await permissionsIn(743, 2), 'CAN_USE_DELETE_ALL_BUTTON')).toBe('False')

			// The creator lets everyone spawn inventions in this subroom.
			expect(
				(
					await putPermissions(
						'/rooms/2/subrooms/2/permissions',
						[
							{
								Permission: 'CAN_SPAWN_INVENTIONS',
								Role: 0,
								Override: true,
								Type: 0,
								Value: 'True',
							},
						],
						'1'
					)
				).status
			).toBe(200)
			const granted = await permissionsIn(743, 2)
			expect(valueOf(granted, 'CAN_SPAWN_INVENTIONS')).toBe('True')
			// Only that one: the rest of the visitor's table is still False, and one row each.
			expect(valueOf(granted, 'CAN_USE_DELETE_ALL_BUTTON')).toBe('False')
			expect(granted.length).toBe(6)

			// A grant stored for co-owners is not the visitor's — and nor is it listed for them.
			await putPermissions(
				'/rooms/2/subrooms/2/permissions',
				[{ Permission: 'CAN_INVITE', Role: 30, Override: true, Type: 0, Value: 'True' }],
				'1'
			)
			const after = await permissionsIn(743, 2)
			expect(after.find((p) => p.Permission === 'CAN_INVITE')).toBeUndefined()
			expect(after.length).toBe(6)
			// The co-owner is a manager and reads the whole table: that entry at its own role
			// with `Override: true`, inherited (`false`) by the creator above it, and absent
			// below it where nothing reaches — a pair the defaults don't carry has no cell.
			await setRoles()
			const coOwner = await permissionsIn(749, 2)
			expect(cell(coOwner, 'CAN_INVITE', 30)).toMatchObject({ Override: true, Value: 'True' })
			expect(cell(coOwner, 'CAN_INVITE', 255)).toMatchObject({ Override: false, Value: 'True' })
			expect(coOwner.filter((p) => p.Permission === 'CAN_INVITE').map((p) => p.Role)).toEqual([
				30, 255,
			])
			// And the Role 0 grant stored above: its own cell overridden, every tier above
			// inheriting it — except Role 30, where the envelope test stored its own entry.
			expect(cell(coOwner, 'CAN_SPAWN_INVENTIONS', 0)).toMatchObject({ Override: true })
			expect(cell(coOwner, 'CAN_SPAWN_INVENTIONS', 30)).toMatchObject({ Override: true })
			for (const at of [10, 20, 25, 255]) {
				expect(cell(coOwner, 'CAN_SPAWN_INVENTIONS', at)).toMatchObject({
					Override: false,
					Value: 'True',
				})
			}
		})

		it('serves a manager every role’s row, so a Host grant reads back at Role 10', async () => {
			// The creator switches a permission on for hosts. Served only at Role 0 and the
			// creator's own role (as this once was), the Host cell had no row to read and the
			// switch snapped back to the default every time.
			await putPermissions(
				'/rooms/2/subrooms/2/permissions',
				[{ Permission: 'CAN_SELF_REVIVE', Role: 10, Override: true, Type: 0, Value: 'True' }],
				'1'
			)
			const creator = await permissionsIn(1, 2)
			expect(cell(creator, 'CAN_SELF_REVIVE', 10)).toEqual({
				Override: true,
				Permission: 'CAN_SELF_REVIVE',
				Role: 10,
				Type: 0,
				Value: 'True',
			})
			// Nothing reaches "everyone", so there is no Role 0 cell; the tiers above inherit.
			expect(cell(creator, 'CAN_SELF_REVIVE', 0)).toBeUndefined()
			expect(cell(creator, 'CAN_SELF_REVIVE', 255)).toMatchObject({
				Override: false,
				Value: 'True',
			})
			// A default cell is NOT an override — otherwise un-checking it could never stick.
			expect(cell(creator, 'CAN_USE_DELETE_ALL_BUTTON', 10)).toMatchObject({
				Override: false,
				Value: 'False',
			})
			// The host themself (not a manager) gets only their own rows, at 0 and 10.
			const host = await permissionsIn(748, 2)
			expect(host.filter((p) => p.Permission === 'CAN_SELF_REVIVE').map((p) => p.Role)).toEqual([
				0, 10,
			])
			expect(valueOf(host, 'CAN_SELF_REVIVE')).toBe('True')
			await putPermissions(
				'/rooms/2/subrooms/2/permissions',
				[{ Permission: 'CAN_SELF_REVIVE', Role: 10, Override: false, Type: 0, Value: 'True' }],
				'1'
			)
			expect(cell(await permissionsIn(1, 2), 'CAN_SELF_REVIVE', 10)).toBeUndefined()
			await env.DB.prepare('DELETE FROM presence WHERE account_id = 1').run()
		})

		it('pushes permission changes only to the affected subroom without inventing restrictions', async () => {
			await permissionsIn(2, 2)
			await permissionsIn(747, 3)
			const hub = env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
			await hub.fetch('http://do/all', { method: 'DELETE' })
			const entry = { Permission: 'CAN_SAVE_INVENTIONS', Role: 30, Override: true, Type: 0, Value: 'False' }
			expect((await putPermissions('/rooms/2/subrooms/2/permissions', [entry], '2')).status).toBe(200)
			const frames = (await (await hub.fetch('http://do/all')).json()) as Array<{
				playerId: number
				notificationType: string | number
				data: { Permissions?: Permission[] }
			}>
			const update = frames.find((f) => f.playerId === 2 && f.notificationType === NotificationType.PhotonAccessToken)
			expect(update).toBeDefined()
			expect(cell(update!.data.Permissions!, entry.Permission, 30)).toMatchObject(entry)
			expect(update!.data.Permissions!.some((p) => p.Permission === 'CAN_EDIT_ROOM_ROLES')).toBe(false)
			expect(frames.some((f) => f.playerId === 747 && f.notificationType === NotificationType.PhotonAccessToken)).toBe(false)
			expect(cell(await permissionsIn(2, 2), entry.Permission, 30)).toMatchObject(entry)
			await putPermissions('/rooms/2/subrooms/2/permissions', [{ ...entry, Override: false }], '2')
			await clearPresence(2)
			await clearPresence(747)
		})

		it('treats a future role as a non-manager in Photon reads and live updates', async () => {
			await setRoles()
			const addRole = env.DB.prepare(`UPDATE room SET data = json_insert(data, '$.Roles[#]', json(?1)) WHERE room_id = 2`)
			for (const entry of [{ AccountId: 751, Role: 40 }, { AccountId: 752, Role: 30 }, { AccountId: 752, Role: 40 }]) {
				await addRole.bind(JSON.stringify(entry)).run()
			}
			await permissionsIn(751, 2)
			await permissionsIn(749, 2)
			await permissionsIn(752, 2)
			const hub = env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
			await hub.fetch('http://do/all', { method: 'DELETE' })
			const lower = { Permission: 'FUTURE_ROLE_TEST', Role: 25, Override: true, Type: 1, Value: '12' }
			const higher = { ...lower, Role: 255, Value: '99' }
			const denied = await putPermissions('/rooms/2/subrooms/2/permissions', [lower], '751')
			expect(await refusal(denied)).toBe('You are not the owner of this room!')
			expect((await putPermissions('/rooms/2/subrooms/2/permissions', [lower, higher], '1')).status).toBe(200)

			const assertNonManager = (table: Permission[]) => {
				expect([...new Set(table.map((p) => p.Role))].sort((a, b) => a - b)).toEqual([0, 40])
				for (const role of [0, 40]) {
					expect(cell(table, lower.Permission, role)).toMatchObject({ Override: true, Type: 1, Value: '12' })
				}
			}
			assertNonManager(await permissionsIn(751, 2))
			const manager = await permissionsIn(749, 2)
			expect(cell(manager, lower.Permission, 25)).toMatchObject({ Override: true, Type: 1, Value: '12' })
			expect(cell(manager, lower.Permission, 255)).toMatchObject({ Override: true, Type: 1, Value: '99' })
			const mixedManager = await permissionsIn(752, 2)
			expect(cell(mixedManager, lower.Permission, 255)).toMatchObject({ Override: true, Type: 1, Value: '99' })
			const frames = (await (await hub.fetch('http://do/all')).json()) as Array<{
				playerId: number
				notificationType: string | number
				data: { Permissions: Permission[] }
			}>
			const update = frames.find((f) => f.playerId === 751 && f.notificationType === NotificationType.PhotonAccessToken)
			expect(update).toBeDefined()
			assertNonManager(update!.data.Permissions)
			const managerUpdate = frames.find((f) => f.playerId === 749 && f.notificationType === NotificationType.PhotonAccessToken)
			expect(managerUpdate).toBeDefined()
			expect(cell(managerUpdate!.data.Permissions, lower.Permission, 255)).toMatchObject({ Value: '99' })
			const mixedUpdate = frames.find((f) => f.playerId === 752 && f.notificationType === NotificationType.PhotonAccessToken)
			expect(mixedUpdate).toBeDefined()
			expect(cell(mixedUpdate!.data.Permissions, lower.Permission, 255)).toMatchObject({ Value: '99' })
			await env.DB.prepare("DELETE FROM subroom_permission WHERE sub_room_id = 2 AND permission = 'FUTURE_ROLE_TEST'").run()
			await clearPresence(751)
			await clearPresence(749)
			await clearPresence(752)
		})

		it('preserves Contributor and typed overrides through inheritance, live push and reload', async () => {
			await setRoles()
			await permissionsIn(750, 2)
			const hub = env.RECFLARE_NOTIFICATIONS_HUB.getByName('global')
			await hub.fetch('http://do/all', { method: 'DELETE' })
			const lower = { Permission: 'MAX_CUSTOM_OBJECTS', Role: 20, Override: true, Type: 1, Value: '12' }
			const own = { ...lower, Role: 25, Value: '6' }
			const future = { Permission: 'CUSTOM_LIST', Role: 27, Override: true, Type: 2, Value: '[1,2]' }
			expect((await putPermissions('/rooms/2/subrooms/2/permissions', [lower, own, future], '1')).status).toBe(200)

			const manager = await permissionsIn(749, 2)
			expect(cell(manager, lower.Permission, 25)).toMatchObject({ Override: true, Type: 1, Value: '6' })
			expect(cell(manager, future.Permission, 27)).toMatchObject({ Override: true, Type: 2, Value: '[1,2]' })
			expect(cell(manager, future.Permission, 30)).toMatchObject({ Override: false, Type: 2, Value: '[1,2]' })
			const contributor = await permissionsIn(750, 2)
			expect(cell(contributor, lower.Permission, 25)).toMatchObject({ Override: true, Type: 1, Value: '6' })
			expect(cell(contributor, future.Permission, 25)).toBeUndefined()

			const sent = (await (await hub.fetch('http://do/all')).json()) as Array<{
				playerId: number
				data: { Permissions?: Permission[] }
			}>
			const pushed = sent.find((entry) => entry.playerId === 750 && entry.data.Permissions)
			expect(cell(pushed!.data.Permissions!, lower.Permission, 25)).toMatchObject({ Type: 1, Value: '6' })

			await putPermissions('/rooms/2/subrooms/2/permissions', [{ ...own, Override: false }], '1')
			expect(cell(await permissionsIn(750, 2), lower.Permission, 25)).toMatchObject({ Type: 1, Value: '12' })
			expect(cell(await permissionsIn(749, 2), lower.Permission, 25)).toMatchObject({ Override: false, Type: 1, Value: '12' })
			await env.DB.prepare("DELETE FROM subroom_permission WHERE sub_room_id = 2 AND permission IN ('MAX_CUSTOM_OBJECTS', 'CUSTOM_LIST')").run()
			await env.DB.prepare('DELETE FROM presence WHERE account_id = 750').run()
		})

		it('a stored entry at the caller’s role beats one below it, and revokes a default', async () => {
			// Take the maker pen away from co-owners, while everyone may spawn inventions.
			await putPermissions(
				'/rooms/2/subrooms/2/permissions',
				[{ Permission: 'CAN_USE_MAKER_PEN', Role: 30, Override: true, Type: 0, Value: 'False' }],
				'1'
			)
			const coOwner = await permissionsIn(749, 2)
			expect(cell(coOwner, 'CAN_USE_MAKER_PEN', 30)).toMatchObject({
				Override: true,
				Value: 'False',
			})
			expect(cell(coOwner, 'CAN_SPAWN_INVENTIONS', 30)).toMatchObject({ Value: 'True' })
			// The revocation reaches the creator's cell too (the highest lower role with an
			// entry) — but account 1 is a dev account, whose own-role maker pen nothing takes.
			expect(valueOf(await permissionsIn(1, 2), 'CAN_USE_MAKER_PEN', 255)).toBe('True')

			// A Host (Role 10) sits between: the Role 0 grant reaches them, the Role 30
			// revocation does not, and their own default is no maker pen either way.
			const host = await permissionsIn(748, 2)
			expect(host.map((p) => p.Role).filter((r) => r === 10).length).toBe(6)
			expect(valueOf(host, 'CAN_SPAWN_INVENTIONS')).toBe('True')
			expect(valueOf(host, 'CAN_USE_MAKER_PEN')).toBe('False')
			expect(valueOf(host, 'CAN_USE_DELETE_ALL_BUTTON')).toBe('False')
			// Now the creator opens the delete-all button to hosts and up.
			await putPermissions(
				'/rooms/2/subrooms/2/permissions',
				[
					{
						Permission: 'CAN_USE_DELETE_ALL_BUTTON',
						Role: 10,
						Override: true,
						Type: 0,
						Value: 'True',
					},
				],
				'1'
			)
			expect(valueOf(await permissionsIn(748, 2), 'CAN_USE_DELETE_ALL_BUTTON')).toBe('True')
			// Which reaches a co-owner (above 10) but not a visitor (below it).
			expect(valueOf(await permissionsIn(749, 2), 'CAN_USE_DELETE_ALL_BUTTON', 30)).toBe('True')
			expect(valueOf(await permissionsIn(749, 2), 'CAN_USE_DELETE_ALL_BUTTON', 0)).toBe('False')
			expect(valueOf(await permissionsIn(743, 2), 'CAN_USE_DELETE_ALL_BUTTON')).toBe('False')
			await env.DB.prepare('DELETE FROM presence WHERE account_id = 1').run()
		})

		it('an unchecked Override erases the entry, back to the default', async () => {
			const stored = async () =>
				(await env.DB.prepare(
					`SELECT COUNT(*) AS n FROM subroom_permission
					 WHERE sub_room_id = 2 AND permission = 'CAN_USE_MAKER_PEN' AND role = 30`
				).first<{ n: number }>())!.n

			// The previous test left this pair overridden.
			expect(await stored()).toBe(1)

			// `Override: false` means "fall back to the default" — the `Value` riding along is
			// not stored, it's whatever the picker happened to show.
			expect(
				(
					await putPermissions(
						'/rooms/2/subrooms/2/permissions',
						[
							{
								Permission: 'CAN_USE_MAKER_PEN',
								Role: 30,
								Override: false,
								Type: 0,
								Value: 'False',
							},
						],
						'1'
					)
				).status
			).toBe(200)

			// The row is gone, and the co-owner has their default maker pen again — a default
			// cell, no longer an override.
			expect(await stored()).toBe(0)
			expect(cell(await permissionsIn(749, 2), 'CAN_USE_MAKER_PEN', 30)).toMatchObject({
				Override: false,
				Value: 'True',
			})

			// Clearing a pair that was never overridden is a no-op, not an insert.
			await putPermissions(
				'/rooms/2/subrooms/2/permissions',
				[{ Permission: 'CAN_INVITE', Role: 0, Override: false, Type: 0, Value: 'True' }],
				'1'
			)
			expect((await permissionsIn(743, 2)).length).toBe(6)
		})

		it('scopes the table to its subroom', async () => {
			// Subroom 2 lets everyone spawn inventions (set above); subroom 3 does not.
			expect(valueOf(await permissionsIn(744, 2), 'CAN_SPAWN_INVENTIONS')).toBe('True')
			// La subroom 3 n'a pas de table à elle : le débogage destructeur y reste fermé.
			expect(valueOf(await permissionsIn(744, 3), 'CAN_USE_DELETE_ALL_BUTTON')).toBe('False')
			// And a player in no instance at all is a visitor with the defaults.
			await env.DB.prepare('DELETE FROM presence WHERE account_id = ?1').bind(744).run()
			const lobby = await SELF.fetch(`${ORIGIN}/photon_access_token`, {
				headers: await bearer('744'),
			})
			const table = ((await lobby.json()) as { Permissions: Permission[] }).Permissions
			expect(table.length).toBe(6)
			// Seules les deux permissions d'invention sont ouvertes ; le reste est fermé.
			expect(table.filter((p) => p.Value === 'True').map((p) => p.Permission)).toEqual([
				'CAN_SAVE_INVENTIONS',
				'CAN_SPAWN_INVENTIONS',
			])
		})

		it('keeps a Value that isn’t True/False verbatim', async () => {
			// Not every permission's UI is the True/False picker, so nothing interprets the
			// string — it goes to the client exactly as the creator set it.
			await putPermissions(
				'/rooms/2/subrooms/2/permissions',
				[{ Permission: 'MAX_SPAWNED_INVENTIONS', Role: 0, Override: true, Type: 0, Value: '25' }],
				'1'
			)
			expect(valueOf(await permissionsIn(747, 2), 'MAX_SPAWNED_INVENTIONS')).toBe('25')
		})

		it('applies over the dev accounts’ global maker pen', async () => {
			// Account 3 is one of the hardcoded dev accounts, so it holds the global maker pen
			// in every room — the one grant a subroom's table doesn't take away.
			await putPermissions(
				'/rooms/2/subrooms/2/permissions',
				[{ Permission: 'CAN_USE_MAKER_PEN', Role: 0, Override: true, Type: 0, Value: 'False' }],
				'1'
			)
			const devTable = await permissionsIn(3, 2)
			expect(devTable.filter((p) => p.Permission === 'CAN_USE_MAKER_PEN')).toEqual([
				{ Override: true, Permission: 'CAN_USE_MAKER_PEN', Role: 0, Type: 0, Value: 'True' },
			])
			// A normal player in the same subroom has none, as before.
			expect(valueOf(await permissionsIn(745, 2), 'CAN_USE_MAKER_PEN')).toBe('False')
		})

		it('a cloned subroom inherits the source’s permission table', async () => {
			const res = await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/clone`, {
				method: 'POST',
				headers: await bearer('1'),
			})
			const room = (await res.json()) as { value: { SubRooms: Array<{ SubRoomId: number }> } }
			const cloneId = Math.max(...room.value.SubRooms.map((s) => s.SubRoomId))

			const inClone = await permissionsIn(746, cloneId)
			expect(valueOf(inClone, 'CAN_SPAWN_INVENTIONS')).toBe('True')
			expect(valueOf(inClone, 'MAX_SPAWNED_INVENTIONS')).toBe('25')
		})
	})
})
