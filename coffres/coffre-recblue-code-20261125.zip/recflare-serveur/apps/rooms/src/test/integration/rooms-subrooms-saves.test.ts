// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { countRoomsUsingInvention, decodeInventionUsage, seedRoomWithSubRooms } from '@repo/domain'

import { NotificationType } from '../../../../notify/src/notification-types'
import {
	bearer,
	bodyOf,
	clearPresence,
	envOf,
	ORIGIN,
	putForm,
	putInRoom,
	resetNotifications,
	sentNotifications,
	setupSchema,
	subRoomOf,
} from './support/harness'

beforeAll(setupSchema)

describe('rooms endpoints', () => {
	it('there is no GET for a single subroom — only the room carries them', async () => {
		// The real API has no `GET …/subrooms/{id}/data`; the client reads subrooms off the
		// room. Only the POST (the room save) exists on that path, and it is auth-gated.
		expect((await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/data`)).status).toBe(404)
		expect(await subRoomOf(2, 2)).toMatchObject({ SubRoomId: 2 })
	})

	it('POST /rooms/:id/subrooms/:sid/data is auth-gated, owner-only, and saves the blobs', async () => {
		const save = {
			UnityAssetId: null,
			RoomData: { Filename: '5c618c920f6247efb8327e327d0b4417', Hash: null, OwnershipProof: null },
			SubRoomData: {
				Filename: 'a84167b16796452ab70ee8a6a5b1dc5f',
				Hash: null,
				OwnershipProof: null,
			},
			InventionUsage: 'CAE=',
			PersistenceVersion: 41,
			Description: 'mydescription here',
			AutoPublish: true,
		}
		// No token → 401.
		expect(
			(
				await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/data`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(save),
				})
			).status
		).toBe(401)

		const authed = async (roomId: number, subRoomId: number, sub = '1') =>
			SELF.fetch(`${ORIGIN}/rooms/${roomId}/subrooms/${subRoomId}/data`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', ...(await bearer(sub)) },
				body: JSON.stringify(save),
			})

		// A valid token but no role on the room → 403.
		expect((await authed(2, 2, '999')).status).toBe(403)
		// Rejections use the same lowercase envelope as the success case.
		expect(await envOf(await authed(99999, 2, '1'))).toMatchObject({
			success: false,
			error: 'This room does not exist!',
		})
		expect(await envOf(await authed(2, 9999, '1'))).toMatchObject({ success: false })

		// The room's own fields are read first: a save is a revision of a SUBROOM and must
		// leave them alone. `Description` in the body is the save comment, not the room's
		// description — that is `PUT /rooms/:id/description`'s to set.
		const before = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			Description: string
			PersistenceVersion: number
		}
		expect(before.Description).not.toBe('mydescription here')

		// Owner saves → 200. `value` carries BOTH the updated room and the new save, and
		// `error` is null (not ''). This fixture sends `AutoPublish: true`, so it goes live.
		const ok = await authed(2, 2, '1')
		expect(ok.status).toBe(200)
		const saved = (await ok.json()) as {
			success: boolean
			error: string | null
			value: {
				room: Record<string, unknown>
				subRoomDataSave: Record<string, unknown>
			}
		}
		expect(saved.success).toBe(true)
		expect(saved.error).toBeNull()
		expect(saved.value.room).toMatchObject({ RoomId: 2, Description: before.Description })

		// The save is a camelCase projection, NOT the PascalCase CurrentSave shape.
		expect(saved.value.subRoomDataSave).toEqual({
			referencedUnityAssetIds: [],
			persistenceVersion: 41,
			omVersion: 0,
			ugcSubVersion: 0,
			subRoomDataSaveId: expect.any(Number),
			subRoomId: 2,
			unityAssetId: null,
			unityAsset: null,
			unityAssetHash: null,
			dataBlob: 'a84167b16796452ab70ee8a6a5b1dc5f',
			dataBlobHash: null,
			savedByAccountId: 1,
			savedOnPlatform: 0,
			savedOnDeviceClass: 0,
			description: 'mydescription here',
			createdAt: expect.any(String),
		})

		// The saved subroom rides along inside the room's SubRooms, carrying the new save.
		const savedSub = (saved.value.room.SubRooms as Array<Record<string, unknown>>).find(
			(s) => s.SubRoomId === 2
		)!
		expect(savedSub).toMatchObject({
			CreatorAccountId: 1,
			PersistenceVersion: 41,
		})
		// `RoomData` is the ROOM-level metadata blob: it lands on the room as `DataBlob`, which
		// is where the client reads it — not on the subroom, which has no field for it.
		expect(savedSub).not.toHaveProperty('RoomDataBlob')
		expect(saved.value.room).toMatchObject({
			DataBlob: '5c618c920f6247efb8327e327d0b4417',
			DataBlobHash: null,
		})
		expect(
			await (
				await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
			).json()
		).toMatchObject({
			DataBlob: '5c618c920f6247efb8327e327d0b4417',
			DataBlobHash: null,
		})
		expect(savedSub.CurrentSave).toMatchObject({
			DataBlob: 'a84167b16796452ab70ee8a6a5b1dc5f',
		})

		// It also persists — reading the room back shows the save live.
		const sub = (await subRoomOf(2, 2)) as unknown as {
			SubRoomId: number
			CreatorAccountId: number
			CurrentSave: {
				DataBlob: string
				SubRoomDataSaveId: number
				SavedByAccountId: number
				PersistenceVersion: number
				Description: string
				UnitySubAssets: unknown[]
				Tags: unknown[]
			}
			StagedSubRoomDataSaveId: number | null
		}
		expect(sub).toMatchObject({ SubRoomId: 2, CreatorAccountId: 1 })
		expect(sub.CurrentSave).toMatchObject({
			DataBlob: 'a84167b16796452ab70ee8a6a5b1dc5f',
			SavedByAccountId: 1,
			PersistenceVersion: 41,
			UnitySubAssets: [],
			Tags: [],
		})
		expect(sub.CurrentSave.SubRoomDataSaveId).toBeGreaterThan(0)
		expect(sub.StagedSubRoomDataSaveId).toBeNull()

		// The save comment and the scene fields land on the SUBROOM's revision, and the
		// room's own fields are untouched — a save must never rewrite the room.
		expect(sub.CurrentSave.Description).toBe('mydescription here')
		expect(sub).toMatchObject({ PersistenceVersion: 41, InventionUsage: 'CAE=' })
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			Description: string
			PersistenceVersion: number
			InventionUsage?: string
		}
		expect(room.Description).toBe(before.Description)
		expect(room.PersistenceVersion).toBe(before.PersistenceVersion)
		expect(room.InventionUsage).toBeUndefined()

		// A CoOwner (account 2 holds Role 30 in the seeded rooms) may also save — 200
		// with the room envelope. The creator stays account 1 (not clobbered).
		const coOwner = await authed(2, 2, '2')
		expect(coOwner.status).toBe(200)
		const coOwnerEnv = (await coOwner.json()) as {
			success: boolean
			value: { room: { SubRooms: Array<Record<string, unknown>> }; subRoomDataSave: unknown }
		}
		expect(coOwnerEnv.success).toBe(true)
		expect(coOwnerEnv.value.room.SubRooms.find((s) => s.SubRoomId === 2)).toMatchObject({
			CreatorAccountId: 1,
		})
		// The save records who actually saved it, not the room's creator.
		expect(coOwnerEnv.value.subRoomDataSave).toMatchObject({ savedByAccountId: 2 })
	})

	it('GET /rooms/:id gives every subroom a CurrentSave key (null before the first save)', async () => {
		// The client loads a subroom's scene data from CurrentSave and nothing else, so
		// the key must be PRESENT — the seeded rooms predate it and have no such field in
		// their stored blob. `in` rather than a value check: absent and null differ here.
		// Room 3 is seeded and never saved by another test (room 2 is the save fixture).
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/3`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			SubRooms: Array<Record<string, unknown>>
		}
		expect(room.SubRooms.length).toBeGreaterThan(0)
		for (const sub of room.SubRooms) {
			expect('CurrentSave' in sub).toBe(true)
			expect(sub.CurrentSave).toBeNull()
		}
	})

	it('a room save records which inventions the room uses in room_invention', async () => {
		const save = async (inventionUsage: string) => {
			const res = await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/data`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', ...(await bearer('1')) },
				body: JSON.stringify({ InventionUsage: inventionUsage, AutoPublish: true }),
			})
			expect(((await res.json()) as { success: boolean }).success).toBe(true)
		}
		const rows = async (): Promise<number[]> =>
			(
				await env.DB.prepare(
					'SELECT invention_id FROM room_invention WHERE room_id = 2 ORDER BY invention_id'
				).all<{ invention_id: number }>()
			).results.map((r) => r.invention_id)

		// The invention records the counts are written onto (the `api` worker's table).
		for (const id of [257, 27941]) {
			await env.DB.prepare('INSERT INTO invention (data) VALUES (?1)')
				.bind(JSON.stringify({ InventionId: id, NumPlayersHaveUsedInRoom: 0 }))
				.run()
		}
		const usedIn = async (id: number): Promise<number> =>
			(
				await env.DB.prepare(
					"SELECT json_extract(data, '$.NumPlayersHaveUsedInRoom') AS n FROM invention WHERE id = ?1"
				)
					.bind(id)
					.first<{ n: number }>()
			)?.n ?? -1

		// A real client value: `{ 1: 1, 2: [{ 1: 27941, 2: 1 }, { 1: 257, 2: 1 }] }`.
		expect(decodeInventionUsage('CAESBgil2gEQARIFCIECEAE=')).toEqual([27941, 257])
		await save('CAESBgil2gEQARIFCIECEAE=')
		expect(await rows()).toEqual([257, 27941])
		expect(await countRoomsUsingInvention(env.DB, 27941)).toBe(1)
		// The invention's own counter is the number of rooms it is in.
		expect([await usedIn(257), await usedIn(27941)]).toEqual([1, 1])

		// Saving the same inventions again is not a second use.
		await save('CAESBgil2gEQARIFCIECEAE=')
		expect([await usedIn(257), await usedIn(27941)]).toEqual([1, 1])

		// An invention taken out of the room drops out, and its counter comes back down.
		await save('CAESBQiBAhAB')
		expect(await rows()).toEqual([257])
		expect(await countRoomsUsingInvention(env.DB, 27941)).toBe(0)
		expect([await usedIn(257), await usedIn(27941)]).toEqual([1, 0])

		// A value that doesn't decode records nothing and does not fail the save.
		await save('not base64 !!')
		expect(await rows()).toEqual([])
		expect(await usedIn(257)).toBe(0)
	})

	it('a real client room-save body stages, and publish_save makes it live', async () => {
		const save = async (body: unknown) =>
			SELF.fetch(`${ORIGIN}/rooms/5/subrooms/5/data`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', ...(await bearer('1')) },
				body: JSON.stringify(body),
			})
		type Sub = {
			CurrentSave: Record<string, unknown> | null
			StagedSubRoomDataSaveId: number | null
		}
		const subOf = async () => (await subRoomOf(5, 5)) as unknown as Sub
		const publish = async (saveId: number, sub = '1') =>
			SELF.fetch(`${ORIGIN}/rooms/5/subrooms/5/publish_save`, {
				method: 'POST',
				headers: {
					...(await bearer(sub)),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: new URLSearchParams({ subRoomDataSaveId: String(saveId) }).toString(),
			})

		// The exact body the live client posts after uploading both blobs to `storage`:
		// SubRoomData is the scene blob, RoomData the metadata blob.
		const res = await save({
			UnityAssetId: null,
			RoomData: { Filename: '2026-07-28/b266ccd5-metadata', Hash: null, OwnershipProof: null },
			SubRoomData: { Filename: '2026-07-28/f176fc3b-scene', Hash: null, OwnershipProof: null },
			InventionUsage: 'CAE=',
			PersistenceVersion: 51,
			Description: 'TEST',
			AutoPublish: false,
		})
		expect(res.status).toBe(200)

		// Room 5 is not a dorm → staged, nothing live yet.
		const stagedSub = await subOf()
		expect(stagedSub.CurrentSave).toBeNull()
		const firstId = stagedSub.StagedSubRoomDataSaveId!
		expect(firstId).toBeGreaterThan(0)

		// Publishing makes it what the loader fetches, and clears the staging slot.
		expect((await publish(firstId)).status).toBe(200)
		const live = await subOf()
		expect(live.StagedSubRoomDataSaveId).toBeNull()
		expect(live.CurrentSave).toMatchObject({
			SubRoomId: 5,
			SubRoomDataSaveId: firstId,
			DataBlob: '2026-07-28/f176fc3b-scene',
			PersistenceVersion: 51,
			SavedByAccountId: 1,
			Description: 'TEST',
			OMVersion: 0,
			UgcSubVersion: 0,
			ModerationState: 0,
		})
		// DataBlobHash rides along (null — the client sent `Hash: null`); UnityAssetId is
		// omitted entirely rather than nulled, since the save carried none.
		expect(live.CurrentSave!.DataBlobHash).toBeNull()
		expect('UnityAssetId' in live.CurrentSave!).toBe(false)

		// It's on the room read too — that's what the loader actually fetches.
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/5`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			SubRooms: Array<{ SubRoomId: number; CurrentSave: { SubRoomDataSaveId: number } | null }>
		}
		expect(room.SubRooms.find((s) => s.SubRoomId === 5)!.CurrentSave!.SubRoomDataSaveId).toBe(
			firstId
		)

		// A second save appends and stages — what players load does NOT change.
		await save({ SubRoomData: { Filename: 'second.room' } })
		const afterSecond = await subOf()
		const secondId = afterSecond.StagedSubRoomDataSaveId!
		expect(secondId).toBeGreaterThan(firstId)
		expect(afterSecond.CurrentSave).toMatchObject({ SubRoomDataSaveId: firstId })

		// Both saves are in the history, newest first — the first one is not lost.
		const history = (await (
			await SELF.fetch(`${ORIGIN}/rooms/5/subrooms/5/saves`, { headers: await bearer('1') })
		).json()) as {
			Results: Array<{ DataBlob: string; Description: string }>
			TotalResults: number
		}
		expect(history.TotalResults).toBe(2)
		expect(history.Results.map((s) => s.DataBlob)).toEqual([
			'second.room',
			'2026-07-28/f176fc3b-scene',
		])
		// A save with no Description records an empty string, not null.
		expect(history.Results[0]!.Description).toBe('')

		// Publishing an OLDER save is a restore — and keeps the newer staged work.
		expect((await publish(secondId)).status).toBe(200)
		expect((await subOf()).StagedSubRoomDataSaveId).toBeNull()
		expect((await publish(firstId)).status).toBe(200)
		const restored = await subOf()
		expect(restored.CurrentSave).toMatchObject({ SubRoomDataSaveId: firstId })

		// A save id from a different subroom is rejected, even though ids are global.
		const foreign = (await (
			await publish(
				((await subRoomOf(2, 2)) as unknown as Sub).CurrentSave!.SubRoomDataSaveId as number
			)
		).json()) as { success: boolean; error: string }
		expect(foreign.success).toBe(false)
		expect(foreign.error).toBe('That save does not exist!')

		// Co-owners may publish too — whoever may save decides what goes live — and a
		// stranger may not.
		expect(((await (await publish(firstId, '2')).json()) as { success: boolean }).success).toBe(
			true
		)
		expect(((await (await publish(firstId, '999')).json()) as { success: boolean }).success).toBe(
			false
		)
	})

	it('migrates a pre-CurrentSave subroom into a real save row (0008 backfill 2)', async () => {
		// A subroom saved by the older code has its blob in the flat DataBlob field and no
		// CurrentSave at all. seedRoomWithSubRooms mirrors the migration, so this covers
		// the backfill: the flat fields become a save row the subroom points at, rather
		// than reading as never-saved and hiding real content from the loader.
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 820,
			Name: 'LegacyShaped',
			CreatorAccountId: 1,
			SubRooms: [
				{
					SubRoomId: 830,
					Name: 'Legacy',
					CreatorAccountId: 7,
					UnitySceneId: '76d98498-60a1-430c-ab76-b54a29b7a163',
					MaxPlayers: 4,
					Accessibility: 2,
					DataBlob: 'legacy-blob.room',
					DataSavedAt: '2024-03-04T05:06:07.000Z',
					PersistenceVersion: 12,
				},
			],
		})

		const sub = (await subRoomOf(820, 830)) as unknown as {
			CurrentSave: Record<string, unknown>
		}
		expect(sub.CurrentSave).toMatchObject({
			SubRoomId: 830,
			DataBlob: 'legacy-blob.room',
			PersistenceVersion: 12,
			SavedByAccountId: 7,
			CreatedAt: '2024-03-04T05:06:07.000Z',
			UnitySubAssets: [],
			Tags: [],
		})
		// Stable across reads — it's a stored row now, not something rebuilt per request.
		const again = (await subRoomOf(820, 830)) as unknown as {
			CurrentSave: { SubRoomDataSaveId: number }
		}
		expect(again.CurrentSave.SubRoomDataSaveId).toBe(sub.CurrentSave.SubRoomDataSaveId)
	})

	it('a dorm save publishes immediately instead of staging', async () => {
		// Room 1 is the seeded DormRoom (IsDorm). A dorm is the player's own space with no
		// publish step in the client, so staging one would make their edits permanently
		// invisible — dorm saves go straight live.
		const res = await SELF.fetch(`${ORIGIN}/rooms/1/subrooms/1/data`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json', ...(await bearer('1')) },
			body: JSON.stringify({ SubRoomData: { Filename: 'dorm.room' } }),
		})
		expect(res.status).toBe(200)

		const sub = (await subRoomOf(1, 1)) as unknown as {
			CurrentSave: { DataBlob: string } | null
			StagedSubRoomDataSaveId: number | null
		}
		expect(sub.CurrentSave).toMatchObject({ DataBlob: 'dorm.room' })
		expect(sub.StagedSubRoomDataSaveId).toBeNull()
	})

	it('save ids are globally unique across subrooms, so a bare id resolves', async () => {
		// StagedSubRoomDataSaveId points at a save by bare id with no subroom context, so
		// per-subroom numbering (every subroom's first save being 1) would be ambiguous.
		const save = async (roomId: number, subRoomId: number) =>
			SELF.fetch(`${ORIGIN}/rooms/${roomId}/subrooms/${subRoomId}/data`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', ...(await bearer('1')) },
				body: JSON.stringify({ SubRoomData: { Filename: `blob-${subRoomId}.room` } }),
			})
		// Non-dorm saves stage, so the fresh id lands on StagedSubRoomDataSaveId.
		const idOf = async (roomId: number, subRoomId: number) =>
			((await subRoomOf(roomId, subRoomId)) as unknown as { StagedSubRoomDataSaveId: number })
				.StagedSubRoomDataSaveId

		// Two different subrooms, each getting their FIRST save.
		await save(6, 6)
		await save(7, 7)
		expect(await idOf(6, 6)).not.toBe(await idOf(7, 7))
	})

	it('a cloned subroom re-points CurrentSave at the copy, not the source', async () => {
		// Save room 2's subroom so there is a CurrentSave to copy.
		await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/data`, {
			method: 'POST',
			headers: { ...(await bearer('1')), 'Content-Type': 'application/json' },
			body: JSON.stringify({ SubRoomData: { Filename: 'cloned-source.room' } }),
		})

		const res = await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/clone`, {
			method: 'POST',
			headers: await bearer('1'),
		})
		const body = (await res.json()) as {
			value: { SubRooms: Array<{ SubRoomId: number; CurrentSave: { SubRoomId: number } | null }> }
		}
		const clone = body.value.SubRooms.find((s) => s.SubRoomId !== 2 && s.CurrentSave !== null)!
		expect(clone).toBeDefined()
		// The copy's save must claim the COPY, or the client resolves it against the source.
		expect(clone.CurrentSave!.SubRoomId).toBe(clone.SubRoomId)
	})

	it('PUT /rooms/:id/tags is auth-gated, owner/co-owner-only, and toggles (add/remove)', async () => {
		// The lowercase `{ success, error, value }` envelope this endpoint returns.
		type TagResult = {
			success: boolean
			error: string
			value: { Tags?: Array<{ Tag: string }> } | null
		}
		const envOf = async (res: Response) => (await res.json()) as TagResult
		const tagsIn = (r: TagResult) => (r.value?.Tags ?? []).map((t) => t.Tag)

		// No token → 401.
		expect((await putForm('/rooms/2/tags', { tag: 'quest' })).status).toBe(401)
		// A valid token but no role on the room → 403.
		expect((await putForm('/rooms/2/tags', { tag: 'quest' }, '999')).status).toBe(403)
		// Unknown room → failure envelope.
		expect(await envOf(await putForm('/rooms/99999/tags', { tag: 'quest' }, '1'))).toMatchObject({
			success: false,
			error: 'This room does not exist!',
		})
		// Empty tag → failure envelope.
		expect(await envOf(await putForm('/rooms/2/tags', { tag: '  ' }, '1'))).toMatchObject({
			success: false,
			error: 'You must provide a tag!',
		})

		// Owner adds a non-main tag → success envelope carries the updated room.
		const added = await envOf(await putForm('/rooms/2/tags', { tag: 'spooky' }, '1'))
		expect(added).toMatchObject({ success: true, error: '' })
		expect(tagsIn(added)).toContain('spooky')

		// The same call again toggles it back off (no delete endpoint).
		const removed = await envOf(await putForm('/rooms/2/tags', { tag: 'SPOOKY' }, '1'))
		expect(tagsIn(removed)).not.toContain('spooky')

		// Main tags are radio buttons: setting one clears any other main tag, but
		// leaves non-main tags alone.
		await putForm('/rooms/2/tags', { tag: 'campfire' }, '1') // non-main, stays put
		const pvp = await envOf(await putForm('/rooms/2/tags', { tag: 'pvp' }, '1'))
		expect(tagsIn(pvp)).toEqual(expect.arrayContaining(['pvp', 'campfire']))

		const quest = await envOf(await putForm('/rooms/2/tags', { tag: 'quest' }, '1'))
		expect(tagsIn(quest)).toContain('quest')
		expect(tagsIn(quest)).not.toContain('pvp') // the previous main tag was cleared
		expect(tagsIn(quest)).toContain('campfire') // non-main tag untouched

		// Toggling the current main tag off just removes it (no other change).
		const off = await envOf(await putForm('/rooms/2/tags', { tag: 'quest' }, '1'))
		expect(tagsIn(off)).not.toContain('quest')
		expect(tagsIn(off)).toContain('campfire')

		// The co-owner (account 2, Role 30) may edit tags too.
		const byCoOwner = await envOf(await putForm('/rooms/2/tags', { tag: 'spooky' }, '2'))
		expect(byCoOwner).toMatchObject({ success: true, error: '' })
		expect(tagsIn(byCoOwner)).toContain('spooky')
	})

	it('PUT /rooms/:id/tags sets the primary genre from primaryGenreTag', async () => {
		type TagResult = {
			success: boolean
			error: string
			value: { Tags?: Array<{ Tag: string; Type: number; IsPrimaryGenre?: boolean }> } | null
		}
		const tags = async (res: Response) => ((await res.json()) as TagResult).value?.Tags ?? []
		const genre = (list: Awaited<ReturnType<typeof tags>>) =>
			list.filter((t) => t.IsPrimaryGenre).map((t) => t.Tag)

		// Same gates as the toggle body — the second shape doesn't open a second door.
		expect((await putForm('/rooms/4/tags', { primaryGenreTag: 'social' })).status).toBe(401)
		expect((await putForm('/rooms/4/tags', { primaryGenreTag: 'social' }, '999')).status).toBe(403)
		// A blank value is a malformed post, not "unset the genre".
		expect(
			await (await putForm('/rooms/4/tags', { primaryGenreTag: '  ' }, '1')).json()
		).toMatchObject({ success: false, error: 'You must provide a tag!' })

		// Room 4 is seeded with the auto-derived `rro` (Type 2); add an ordinary tag too, so
		// the genre can be seen not to disturb either of them.
		await putForm('/rooms/4/tags', { tag: 'puzzle' }, '1')

		// The genre tag is ADDED when the room lacks it — a Type 0 tag, flagged.
		const set = await tags(await putForm('/rooms/4/tags', { primaryGenreTag: 'social' }, '1'))
		expect(set).toContainEqual({ Tag: 'social', Type: 0, IsPrimaryGenre: true })
		// …and the key is absent on the others rather than false.
		expect(set).toContainEqual({ Tag: 'puzzle', Type: 0 })

		// Choosing another genre MOVES the flag. Unlike the old five-way radio it does not
		// remove the tag it displaced: `social` stays on the room, just no longer the genre.
		const moved = await tags(await putForm('/rooms/4/tags', { primaryGenreTag: 'horror' }, '1'))
		expect(genre(moved)).toEqual(['horror'])
		expect(moved.map((t) => t.Tag).sort()).toEqual(['horror', 'puzzle', 'rro', 'social'])

		// A tag the room already carries keeps its Type and simply becomes the genre — the
		// seeded `rro` is Type 2 and stays Type 2.
		const promoted = await tags(await putForm('/rooms/4/tags', { primaryGenreTag: 'rro' }, '1'))
		expect(promoted).toContainEqual({ Tag: 'rro', Type: 2, IsPrimaryGenre: true })
		expect(genre(promoted)).toEqual(['rro'])

		// Stored on the row, so a cold read says the same thing.
		expect(
			await env.DB.prepare(
				'SELECT tag, is_primary_genre FROM room_tag WHERE room_id = 4 AND is_primary_genre = 1'
			).all<{ tag: string; is_primary_genre: number }>()
		).toMatchObject({ results: [{ tag: 'rro', is_primary_genre: 1 }] })
		const read = (await (
			await SELF.fetch(`${ORIGIN}/rooms/4`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			Tags: Array<{ Tag: string; IsPrimaryGenre?: boolean }>
		}
		expect(read.Tags.filter((t) => t.IsPrimaryGenre).map((t) => t.Tag)).toEqual(['rro'])

		// The toggle body still works on the same room, and toggling the flagged tag off
		// takes the genre with it — the room's genre WAS that tag.
		const toggledOff = await tags(await putForm('/rooms/4/tags', { tag: 'rro' }, '1'))
		expect(toggledOff.map((t) => t.Tag)).not.toContain('rro')
		expect(genre(toggledOff)).toEqual([])
		// …while toggling an unrelated tag leaves a genre alone.
		await putForm('/rooms/4/tags', { primaryGenreTag: 'social' }, '1')
		const other = await tags(await putForm('/rooms/4/tags', { tag: 'campfire' }, '1'))
		expect(genre(other)).toEqual(['social'])

		// A `tag` alongside the genre is a whole-state save, NOT a toggle: `campfire` stays
		// rather than being toggled back off. (The set semantics themselves are next.)
		const both = await tags(
			await putForm('/rooms/4/tags', { tag: 'campfire', primaryGenreTag: 'puzzle' }, '1')
		)
		expect(genre(both)).toEqual(['puzzle'])
		expect(both.map((t) => t.Tag)).toContain('campfire')

		// Put room 4 back the way it was seeded — its `rro` tag is what the rro feeds count.
		await env.DB.batch([
			env.DB.prepare('DELETE FROM room_tag WHERE room_id = 4'),
			env.DB.prepare(
				"INSERT INTO room_tag (room_id, tag, type, is_primary_genre) VALUES (4, 'rro', 2, 0)"
			),
		])
	})

	it('PUT /rooms/:id/tags takes the whole-state save: repeated tag, autoTag, genre', async () => {
		type Tag = { Tag: string; Type: number; IsPrimaryGenre?: boolean }
		// A room of this test's own: the whole-state save REPLACES the user tags, and doing
		// that to a seeded room would strip tags the feeds above are asserted on.
		const ROOM = 9700
		await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					RoomId: ROOM,
					Name: 'TagSaveRoom',
					CreatorAccountId: 1,
					IsDorm: false,
					Accessibility: 1,
					SubRooms: [],
				})
			)
			.run()

		const save = async (query: string, sub = '1') => {
			const res = await SELF.fetch(`${ORIGIN}/rooms/${ROOM}/tags`, {
				method: 'PUT',
				headers: {
					...(await bearer(sub)),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: query,
			})
			expect(res.status).toBe(200)
			const body = (await res.json()) as { success: boolean; value: { Tags?: Tag[] } | null }
			expect(body.success).toBe(true)
			return [...(body.value?.Tags ?? [])].sort((a, b) => a.Tag.localeCompare(b.Tag))
		}

		// The form room settings posts. `tag` repeats — without `all: true` on the parse only
		// the last would arrive, and a three-tag save would land as one.
		const saved = await save(
			'autoTag=limitsv2&tag=roleplay&tag=social&tag=sports&primaryGenreTag=roleplay'
		)
		expect(saved).toEqual([
			{ Tag: 'limitsv2', Type: 1 },
			{ Tag: 'roleplay', Type: 0, IsPrimaryGenre: true },
			{ Tag: 'social', Type: 0 },
			{ Tag: 'sports', Type: 0 },
		])

		// Idempotent — the same save twice is the same room. This is why a lone `tag` toggles
		// but a `tag` in company does not: toggling here would clear the room on every save.
		expect(
			await save('autoTag=limitsv2&tag=roleplay&tag=social&tag=sports&primaryGenreTag=roleplay')
		).toEqual(saved)

		// `tag` is the COMPLETE user set: dropping one removes it. The auto tag is NOT the
		// client's to send here and survives a save that never mentions it.
		expect(await save('tag=roleplay&primaryGenreTag=roleplay')).toEqual([
			{ Tag: 'limitsv2', Type: 1 },
			{ Tag: 'roleplay', Type: 0, IsPrimaryGenre: true },
		])

		// autoTag is additive and repeatable, and re-categorises a tag the room already has
		// rather than duplicating it — `tag` is the table's key, so there is one row per name.
		expect(await save('autoTag=beta&autoTag=roleplay')).toEqual([
			{ Tag: 'beta', Type: 1 },
			{ Tag: 'limitsv2', Type: 1 },
			// Was a Type 0 user tag; posting it as an auto tag moves its category, and the
			// genre flag rides along with the row.
			{ Tag: 'roleplay', Type: 1, IsPrimaryGenre: true },
		])

		// An autoTag alone is a valid request — it names no `tag`, and must not be refused
		// for it.
		const bare = await save('autoTag=limitsv2')
		expect(bare.map((t) => t.Tag)).toContain('limitsv2')

		// A save that names no user tags at all clears them, leaving the derived ones.
		expect((await save('tag=&autoTag=limitsv2')).map((t) => t.Tag)).toEqual([
			'beta',
			'limitsv2',
			'roleplay',
		])

		// Same gates as every other body.
		expect(
			(
				await SELF.fetch(`${ORIGIN}/rooms/${ROOM}/tags`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body: 'autoTag=limitsv2',
				})
			).status
		).toBe(401)

		await env.DB.batch([
			env.DB.prepare('DELETE FROM room_tag WHERE room_id = ?1').bind(ROOM),
			env.DB.prepare('DELETE FROM room WHERE room_id = ?1').bind(ROOM),
		])
	})

	// Tags live in `room_tag`, not in the room blob (migration 0013). These pin the
	// invariant that makes that safe: the table is the only copy, and the DTO is rebuilt
	// from it on read.
	it('stores tags in room_tag and never in the room blob', async () => {
		await putForm('/rooms/2/tags', { tag: 'ghostly' }, '1')

		// The blob must carry no `Tags` key at all — a second copy is what the table exists
		// to eliminate, and it would only be kept current by the writes that go through
		// toggleRoomTag.
		const row = await env.DB.prepare('SELECT data FROM room WHERE room_id = 2').first<{
			data: string
		}>()
		expect(JSON.parse(row!.data).Tags).toBeUndefined()

		// The table has it, lowercased — `tag` is the lookup key the index is on.
		const tagRow = await env.DB.prepare(
			'SELECT tag, type FROM room_tag WHERE room_id = 2 AND tag = ?1'
		)
			.bind('ghostly')
			.first<{ tag: string; type: number }>()
		expect(tagRow).toEqual({ tag: 'ghostly', type: 0 })

		// And the read re-attaches it, so the client sees an unchanged DTO.
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			Tags: Array<{ Tag: string; Type: number }>
		}
		expect(room.Tags).toContainEqual({ Tag: 'ghostly', Type: 0 })

		// Toggle back off: the row goes, rather than lingering to answer `#ghostly` searches.
		await putForm('/rooms/2/tags', { tag: 'ghostly' }, '1')
		expect(
			await env.DB.prepare('SELECT COUNT(*) AS n FROM room_tag WHERE room_id = 2 AND tag = ?1')
				.bind('ghostly')
				.first<{ n: number }>()
		).toEqual({ n: 0 })
	})

	// D1 caps a statement at 100 bound parameters. The seeded database has 45 rooms, so
	// every `IN (…)` list built per-room fitted and the cap went unnoticed until a real
	// server crossed it: the hot feed attaches tags to EVERY room, so the bind list grew
	// with the database and the query failed with "variable number must be between ?1 and
	// ?100". This seeds past the cap so the feeds are exercised above it.
	it('serves the feeds when there are more rooms than D1 allows bound parameters', async () => {
		const FIRST = 20000
		const COUNT = 150
		for (let i = 0; i < COUNT; i++) {
			const roomId = FIRST + i
			await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
				.bind(
					JSON.stringify({
						RoomId: roomId,
						Name: `BulkRoom${i}`,
						CreatorAccountId: 700,
						IsDorm: false,
						Accessibility: 1,
						CreatedAt: '2026-05-01T00:00:00Z',
						SubRooms: [],
					})
				)
				.run()
			// Every third one tagged, so the tag map is non-trivial above the cap too.
			if (i % 3 === 0) {
				await env.DB.prepare('INSERT INTO room_tag (room_id, tag, type) VALUES (?1, ?2, 0)')
					.bind(roomId, 'bulky')
					.run()
			}
		}

		// The feed that failed: it reads every room, so it attaches tags for all of them.
		const hot = await SELF.fetch(`${ORIGIN}/rooms/hot?take=5`)
		expect(hot.status).toBe(200)

		// Rooms owned by one account — this hydrates the WHOLE result set rather than a page,
		// so its subroom and save reads run above the cap too. Those had the same latent bug.
		const mine = await SELF.fetch(`${ORIGIN}/rooms/createdby/me`, { headers: await bearer('700') })
		expect(mine.status).toBe(200)
		expect(((await mine.json()) as unknown[]).length).toBe(COUNT)

		// And the tag lookup still answers correctly above the cap.
		const tagged = (await (
			await SELF.fetch(`${ORIGIN}/rooms/search?query=%23bulky&take=200`)
		).json()) as { Results: Array<{ RoomId: number }> }
		expect(tagged.Results.length).toBe(Math.ceil(COUNT / 3))

		// Clean up so the room counts other tests assert stay put.
		await env.DB.prepare('DELETE FROM room WHERE room_id >= ?1').bind(FIRST).run()
		await env.DB.prepare('DELETE FROM room_tag WHERE room_id >= ?1').bind(FIRST).run()
	})

	it("drops a deleted room's tag rows", async () => {
		// Throwaway room owned by account 1, seeded directly the way the DELETE test above
		// does, so this doesn't disturb the imported rooms.
		await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					RoomId: 9600,
					Name: 'TagCascadeRoom',
					CreatorAccountId: 1,
					IsDorm: false,
					Accessibility: 1,
					SubRooms: [],
				})
			)
			.run()
		await putForm('/rooms/9600/tags', { tag: 'doomed' }, '1')

		const count = async () =>
			(await env.DB.prepare('SELECT COUNT(*) AS n FROM room_tag WHERE room_id = 9600').first<{
				n: number
			}>())!.n
		expect(await count()).toBe(1)

		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/9600`, { method: 'DELETE', headers: await bearer('1') }))
				.status
		).toBe(200)
		// Otherwise the tag rows keep answering `#doomed` searches and category rows for a
		// room nobody can open.
		expect(await count()).toBe(0)
	})

	it('PUT /rooms/:id/name is auth-gated, owner-only, unique, and persists', async () => {
		// No token → 401 (auth gate).
		expect((await putForm('/rooms/2/name', { name: 'Whatever' })).status).toBe(401)
		// Wrong owner / unknown room → Success:false envelopes.
		expect(await bodyOf(await putForm('/rooms/2/name', { name: 'Whatever' }, '999'))).toMatchObject(
			{
				Success: false,
				ErrorId: 'Rooms.NotOwner',
			}
		)
		expect(
			await bodyOf(await putForm('/rooms/99999/name', { name: 'Whatever' }, '1'))
		).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.DoesntExist',
		})
		// Empty name → Success:false.
		expect(await bodyOf(await putForm('/rooms/2/name', { name: '  ' }, '1'))).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.InvalidName',
		})
		// A name already used by a different room (GoldenTrophy is room 12).
		expect(
			await bodyOf(await putForm('/rooms/2/name', { name: 'GoldenTrophy' }, '1'))
		).toMatchObject({
			Success: false,
			ErrorId: 'Rooms.AlreadyExists',
			Error: 'A room with that name already exists!',
		})

		// Owner renames to a free name, and it persists (findable by the new name).
		const ok = await putForm('/rooms/2/name', { name: 'RenamedCenter' }, '1')
		expect(await bodyOf(ok)).toMatchObject({ Success: true })
		const room = (await (await SELF.fetch(`${ORIGIN}/rooms?name=RenamedCenter`)).json()) as {
			RoomId: number
			Name: string
		}
		expect(room.RoomId).toBe(2)
		expect(room.Name).toBe('RenamedCenter')
		// A rename must not resurrect the retired display name.
		expect(room).not.toHaveProperty('FriendlyName')
	})

	it('a rename pushes a RoomUpdate to the owner carrying the new name', async () => {
		// The rename answers a bare `{ Success }` with no room in it, so the push is the only
		// thing that tells the client to redraw — without it the old name stays on screen.
		await resetNotifications()
		expect(
			await bodyOf(await putForm('/rooms/2/name', { name: 'PushedRename' }, '1'))
		).toMatchObject({ Success: true })

		const sent = await sentNotifications()
		expect(sent).toHaveLength(1)
		// RoomUpdate, to the OWNER, carrying the room as it now stands.
		expect(sent[0].playerId).toBe(1)
		expect(sent[0].notificationType).toBe(NotificationType.SubscriptionUpdateRoom)
		expect(sent[0].data).toMatchObject({ RoomId: 2, Name: 'PushedRename' })
		expect(sent[0].data).not.toHaveProperty('FriendlyName')

		// Put it back for the tests that read room 2 by name.
		await putForm('/rooms/2/name', { name: 'RenamedCenter' }, '1')
	})

	it('a description edit and a tag toggle push a RoomUpdate too', async () => {
		// Same reason for the description: its envelope carries no room either.
		await resetNotifications()
		await putForm('/rooms/2/description', { description: 'Pushed description' }, '1')
		const afterDescription = await sentNotifications()
		expect(afterDescription).toHaveLength(1)
		expect(afterDescription[0].data).toMatchObject({
			RoomId: 2,
			Description: 'Pushed description',
		})

		// The tag toggle DOES answer the updated room, so its push is for the owner's other
		// sessions rather than for the caller's own redraw.
		await resetNotifications()
		await putForm('/rooms/2/tags', { tag: 'pushedtag' }, '1')
		const afterTag = await sentNotifications()
		expect(afterTag).toHaveLength(1)
		expect(afterTag[0].playerId).toBe(1)
		const tags = afterTag[0].data.Tags as Array<{ Tag: string }>
		expect(tags.map((t) => t.Tag)).toContain('pushedtag')

		// Toggle it back off — the same call removes it.
		await putForm('/rooms/2/tags', { tag: 'pushedtag' }, '1')
	})

	it('GET /rooms/:id/subrooms/:sid/saves pages the save history, newest first', async () => {
		type Page = {
			Results: Array<{ SubRoomId: number; SubRoomDataSaveId: number }>
			TotalResults: number
			TotalCount: number
		}
		const page = async (query: string) =>
			(await (
				await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/saves${query}`, {
					headers: await bearer('1'),
				})
			).json()) as Page

		// Room 2's subroom is saved several times by the tests above — each save appended.
		const all = await page('?unityAssetTarget=0&unityAssetVersion=1')
		expect(all.Results.length).toBeGreaterThan(1)
		expect(all.Results.every((s) => s.SubRoomId === 2)).toBe(true)
		// Newest first: ids descend.
		const ids = all.Results.map((s) => s.SubRoomDataSaveId)
		expect([...ids].sort((a, b) => b - a)).toEqual(ids)
		// Both spellings of the count, and they agree with the list.
		expect(all.TotalResults).toBe(all.Results.length)
		expect(all.TotalCount).toBe(all.TotalResults)

		// skip/take actually page rather than being ignored.
		const paged = await page('?skip=1&take=1')
		expect(paged.Results).toHaveLength(1)
		expect(paged.Results[0]!.SubRoomDataSaveId).toBe(ids[1])
		expect(paged.TotalResults).toBe(all.TotalResults)

		// A never-saved subroom pages empty rather than 404ing.
		const empty = await SELF.fetch(`${ORIGIN}/rooms/3/subrooms/3/saves`, {
			headers: await bearer('1'),
		})
		expect(await empty.json()).toEqual({ Results: [], TotalResults: 0, TotalCount: 0 })

		// The list exposes unpublished saves, so it isn't public: no token → 401, and a
		// valid token from someone who neither manages the room nor is in it → 403.
		expect((await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/saves`)).status).toBe(401)
		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/saves`, { headers: await bearer('999') }))
				.status
		).toBe(403)
		// Account 2 is a co-owner (Role 30 on the seeded rooms) and reads it from anywhere:
		// the client opens the save history from the room's settings, not from inside it.
		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/saves`, { headers: await bearer('2') }))
				.status
		).toBe(200)

		// …but a player standing IN the room reads it: the client resolves which version to
		// load from this list, so a visitor who can't read it can't load the instance.
		await putInRoom(999, 2)
		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/saves`, { headers: await bearer('999') }))
				.status
		).toBe(200)
		// Presence in a DIFFERENT room is not presence in this one.
		await putInRoom(999, 5)
		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/saves`, { headers: await bearer('999') }))
				.status
		).toBe(403)
		// And the grant lasts only as long as the presence does — an expired row reads as
		// absent, so the visitor is refused again the moment they leave.
		await putInRoom(999, 2, { expired: true })
		expect(
			(await SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/saves`, { headers: await bearer('999') }))
				.status
		).toBe(403)
		await clearPresence(999)
	})

	it('GET /rooms/:id/subrooms/:sid/saves/no_unity_assets lists the same history, lighter', async () => {
		const get = async (path: string, sub?: string) =>
			SELF.fetch(`${ORIGIN}${path}`, sub === undefined ? {} : { headers: await bearer(sub) })
		const light = '/rooms/2/subrooms/2/saves/no_unity_assets'

		const res = await get(light, '1')
		expect(res.status).toBe(200)
		const page = (await res.json()) as {
			Results: Array<Record<string, unknown>>
			TotalResults: number
			TotalCount: number
		}
		// The same history the full list serves — same rows, same order, same counts.
		const full = (await (await get('/rooms/2/subrooms/2/saves', '1')).json()) as {
			Results: Array<{ SubRoomDataSaveId: number; DataBlob: string }>
			TotalResults: number
		}
		expect(page.TotalResults).toBe(full.TotalResults)
		expect(page.TotalCount).toBe(page.TotalResults)
		expect(page.Results.map((r) => r.SubRoomDataSaveId)).toEqual(
			full.Results.map((r) => r.SubRoomDataSaveId)
		)

		// The lighter row: the Unity-asset PAYLOADS are gone (and `Tags` with them), the asset
		// IDs stay, and `UnityAssetId` is present-and-null rather than omitted.
		const row = page.Results[0]!
		expect(Object.keys(row)).toEqual([
			'SubRoomDataSaveId',
			'SubRoomId',
			'UnityAssetId',
			'ReferencedUnityAssetIds',
			'DataBlob',
			'DataBlobHash',
			'PersistenceVersion',
			'OMVersion',
			'SavedByAccountId',
			'SavedOnPlatform',
			'SavedOnDeviceClass',
			'Description',
			'ModerationState',
			'CreatedAt',
			'UgcSubVersion',
		])
		expect(row.UnityAssetId).toBe(null)
		expect(row.ReferencedUnityAssetIds).toEqual([])
		expect(row.SubRoomId).toBe(2)
		expect(row.DataBlob).toBe(full.Results[0]!.DataBlob)

		// skip/take page it the same way.
		const paged = (await (await get(`${light}?skip=1&take=1`, '1')).json()) as {
			Results: Array<{ SubRoomDataSaveId: number }>
			TotalResults: number
		}
		expect(paged.Results).toHaveLength(1)
		expect(paged.Results[0]!.SubRoomDataSaveId).toBe(full.Results[1]!.SubRoomDataSaveId)
		expect(paged.TotalResults).toBe(full.TotalResults)

		// A never-saved subroom pages empty rather than 404ing, as the full list does.
		expect(await (await get('/rooms/3/subrooms/3/saves/no_unity_assets', '1')).json()).toEqual({
			Results: [],
			TotalResults: 0,
			TotalCount: 0,
		})

		// Same gate as the list it mirrors — it exposes the same unpublished saves.
		expect((await get(light)).status).toBe(401)
		expect((await get(light, '999')).status).toBe(403)
		expect((await get(light, '2')).status).toBe(200)
		await putInRoom(999, 2)
		expect((await get(light, '999')).status).toBe(200)
		await clearPresence(999)
		expect((await get(light, '999')).status).toBe(403)

		// Staff read it from anywhere: the client asks for this list BEFORE it matchmakes a
		// private instance, so a developer with no role on the room and no presence in it
		// would otherwise be refused the instance.
		const staff = async (roles: string[]) =>
			SELF.fetch(`${ORIGIN}${light}`, { headers: await bearer('999', roles) })
		expect((await staff(['gameClient', 'developer'])).status).toBe(200)
		expect((await staff(['gameClient', 'moderator'])).status).toBe(200)
		expect((await staff(['gameClient'])).status).toBe(403)
	})

	it('GET /rooms/:id/subrooms/:sid/saves/:saveId is the detail behind a history row', async () => {
		const get = async (path: string, sub?: string) =>
			SELF.fetch(`${ORIGIN}${path}`, sub === undefined ? {} : { headers: await bearer(sub) })

		// Pick a real save off the history the previous test paged.
		const list = (await (await get('/rooms/2/subrooms/2/saves', '1')).json()) as {
			Results: Array<{
				SubRoomDataSaveId: number
				DataBlob: string
				Description: string
				PersistenceVersion: number
				UgcSubVersion: number
			}>
		}
		const row = list.Results[0]!

		const res = await get(`/rooms/2/subrooms/2/saves/${row.SubRoomDataSaveId}`, '1')
		expect(res.status).toBe(200)
		// A PascalCase row like the list serves — NOT the camelCase projection the room save
		// returns (served that, the client showed a save with every value missing). Its
		// bundle fields are the detail's own: top-level `UnityAsset`/`UnityAssetHash`, no
		// `Tags`, and `UnityAssetId` present-and-null rather than omitted.
		const detailRow = (await res.json()) as Record<string, unknown>
		expect(Object.keys(detailRow)).toEqual([
			'UnitySubAssets',
			'ReferencedUnityAssets',
			'UnityAsset',
			'UnityAssetHash',
			'SubRoomDataSaveId',
			'SubRoomId',
			'UnityAssetId',
			'ReferencedUnityAssetIds',
			'DataBlob',
			'DataBlobHash',
			'PersistenceVersion',
			'OMVersion',
			'SavedByAccountId',
			'SavedOnPlatform',
			'SavedOnDeviceClass',
			'Description',
			'ModerationState',
			'CreatedAt',
			'UgcSubVersion',
		])
		expect(detailRow).toMatchObject({
			UnitySubAssets: [],
			ReferencedUnityAssets: [],
			UnityAsset: null,
			UnityAssetHash: null,
			SubRoomDataSaveId: row.SubRoomDataSaveId,
			SubRoomId: 2,
			UnityAssetId: null,
			ReferencedUnityAssetIds: [],
			DataBlob: row.DataBlob,
			DataBlobHash: null,
			SavedByAccountId: expect.any(Number),
			SavedOnPlatform: 0,
			SavedOnDeviceClass: 0,
			Description: row.Description,
			ModerationState: 0,
			CreatedAt: expect.any(String),
		})
		// The versions come off the row, not the room save's trimmed projection.
		expect(detailRow.PersistenceVersion).toBe(row.PersistenceVersion)
		expect(detailRow.UgcSubVersion).toBe(row.UgcSubVersion)

		// Unknown save, and a save that exists but belongs to ANOTHER subroom (ids are
		// global, so an unscoped lookup would happily resolve this one) — both 404.
		expect((await get('/rooms/2/subrooms/2/saves/99999', '1')).status).toBe(404)
		const foreign = (
			(await subRoomOf(5, 5)) as unknown as { CurrentSave: { SubRoomDataSaveId: number } }
		).CurrentSave.SubRoomDataSaveId
		expect((await get(`/rooms/2/subrooms/2/saves/${foreign}`, '1')).status).toBe(404)
		// …and it does resolve on its own subroom, so the 404 above is the scoping, not a
		// missing row.
		expect((await get(`/rooms/5/subrooms/5/saves/${foreign}`, '1')).status).toBe(200)

		// Unknown room or subroom is a 404 too (the LIST answers an empty page instead).
		expect((await get('/rooms/99999/subrooms/2/saves/1', '1')).status).toBe(404)
		expect((await get('/rooms/2/subrooms/99999/saves/1', '1')).status).toBe(404)

		// Same gate as the list it details: 401 unauthed, 403 for someone who neither manages
		// the room nor is in it — it reads unpublished saves. A co-owner (account 2) passes.
		const detail = `/rooms/2/subrooms/2/saves/${row.SubRoomDataSaveId}`
		expect((await get(detail)).status).toBe(401)
		expect((await get(detail, '999')).status).toBe(403)
		expect((await get(detail, '2')).status).toBe(200)
		// A player standing in the room reads it, for as long as they're there.
		await putInRoom(999, 2)
		expect((await get(detail, '999')).status).toBe(200)
		await clearPresence(999)
		expect((await get(detail, '999')).status).toBe(403)
	})
})

it('POST /rooms/:id/subrooms/:sid/data lets staff save into a room they hold no role on (audited)', async () => {
		const save = {
			SubRoomData: { Filename: 'b84167b16796452ab70ee8a6a5b1dc5f', Hash: null },
			Description: 'restored by staff',
			AutoPublish: true,
		}
		const post = async (roles: string[]) =>
			SELF.fetch(`${ORIGIN}/rooms/2/subrooms/2/data`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					...(await bearer('997', ['gameClient', ...roles])),
				},
				body: JSON.stringify(save),
			})
		expect((await post([])).status).toBe(403)

		const res = await post(['developer'])
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			success: boolean
			value: { subRoomDataSave: { subRoomDataSaveId: number } }
		}
		expect(body.success).toBe(true)
		const sub = (await subRoomOf(2, 2)) as {
			CreatorAccountId: number | null
			CurrentSave: { DataBlob: string } | null
		}
		expect(sub.CurrentSave?.DataBlob).toBe(save.SubRoomData.Filename)
		// The save doesn't make the staff member the subroom's creator.
		expect(sub.CreatorAccountId).not.toBe(997)

		const { results: audit } = await env.DB.prepare(
			'SELECT player_id, data FROM audit_log WHERE action = ?1'
		)
			.bind('room_save')
			.all<{ player_id: number; data: string }>()
		expect(audit).toHaveLength(1)
		expect(audit[0].player_id).toBe(997)
		expect(JSON.parse(audit[0].data)).toMatchObject({
			roomId: 2,
			subRoomId: 2,
			saveId: body.value.subRoomDataSave.subRoomDataSaveId,
		})
	})
