// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import {
	createExecutionContext,
	createScheduledController,
	env,
	waitOnExecutionContext,
} from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { scheduled } from '../../rooms.app'
import { setupSchema } from './support/harness'

beforeAll(setupSchema)

describe('sweep cron', () => {
	async function castBallot(voterId: number, agoMs: number, init = 0): Promise<void> {
		await env.DB.prepare(
			`INSERT INTO room_vote (game_session_id, player_id, response, voter_id, voted_at, init)
			 VALUES (1, 205, 1, ?1, ?2, ?3)`
		)
			.bind(voterId, new Date(Date.now() - agoMs).toISOString(), init)
			.run()
	}

	async function voterIds(): Promise<number[]> {
		const rows = await env.DB.prepare('SELECT voter_id FROM room_vote ORDER BY voter_id').all<{
			voter_id: number
		}>()
		return rows.results.map((r) => r.voter_id)
	}

	it('deletes ballots older than 5 minutes and keeps the rest', async () => {
		await env.DB.prepare('DELETE FROM room_vote').run()
		// A vote called long ago, and one that just closed: both dead weight.
		await castBallot(1, 6 * 60_000, 1)
		await castBallot(2, 5 * 60_000 + 1_000)
		// A caller still inside their 5-minute cooldown, an open vote, and its answer.
		await castBallot(3, 4 * 60_000 + 30_000, 1)
		await castBallot(4, 30_000, 1)
		await castBallot(5, 0)

		// Driven through the module's own export rather than the `exports` proxy — a
		// ScheduledController can't cross the isolate boundary the proxy serializes over.
		const ctx = createExecutionContext()
		await scheduled(createScheduledController(), env, ctx)
		await waitOnExecutionContext(ctx)

		expect(await voterIds()).toEqual([3, 4, 5])
	})

	async function sendInvite(fromPlayerId: number, agoSeconds: number): Promise<void> {
		await env.DB.prepare(
			`INSERT INTO room_invite (from_player_id, to_player_id, room_id, created_at)
			 VALUES (?1, 790, 823, ?2)`
		)
			.bind(fromPlayerId, Math.floor(Date.now() / 1000) - agoSeconds)
			.run()
	}

	async function inviterIds(): Promise<number[]> {
		const rows = await env.DB.prepare(
			'SELECT from_player_id FROM room_invite ORDER BY from_player_id'
		).all<{ from_player_id: number }>()
		return rows.results.map((r) => r.from_player_id)
	}

	it('deletes invites older than 5 minutes and keeps the rest', async () => {
		await env.DB.prepare('DELETE FROM room_invite').run()
		await sendInvite(1, 6 * 60)
		await sendInvite(2, 5 * 60 + 1)
		await sendInvite(3, 4 * 60 + 30)
		await sendInvite(4, 0)

		const ctx = createExecutionContext()
		await scheduled(createScheduledController(), env, ctx)
		await waitOnExecutionContext(ctx)

		expect(await inviterIds()).toEqual([3, 4])
	})

	it('is a no-op on empty tables', async () => {
		await env.DB.prepare('DELETE FROM room_vote').run()
		await env.DB.prepare('DELETE FROM room_invite').run()
		const ctx = createExecutionContext()
		await scheduled(createScheduledController(), env, ctx)
		await waitOnExecutionContext(ctx)
		expect(await voterIds()).toEqual([])
		expect(await inviterIds()).toEqual([])
	})
})
