// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, expect, it } from 'vitest'

import { seedRoomWithSubRooms } from '@repo/domain'

import { bearer, ORIGIN, setupSchema } from './support/harness'

beforeAll(setupSchema)

it('2026 room experience retains upstream progression in the native object shape', async () => {
	await seedRoomWithSubRooms(env.DB, {
		RoomId: 900092,
		Name: '2026ExperienceTest',
		CreatorAccountId: 42,
		SubRooms: [],
	})
	const res = await SELF.fetch(`${ORIGIN}/rooms/900092/experience/player`, {
		headers: await bearer('42', undefined, '20260323.14'),
	})
	expect(res.status).toBe(200)
	expect(await res.json()).toEqual({
		RoomExperienceEnabled: false,
		Experience: 0,
		ConcurrencyCode: expect.any(String),
	})
})

it('omits hydrated Badges when persisting a room settings edit', async () => {
	await seedRoomWithSubRooms(env.DB, {
		RoomId: 987670,
		Name: 'BadgeSerialization',
		CreatorAccountId: 987670,
		SubRooms: [],
	})
	await env.DB.prepare(
		"UPDATE room SET data=json_set(data,'$.Badges',json(?)) WHERE room_id=987670"
	)
		.bind(JSON.stringify([{ Name: 'derived badge' }]))
		.run()
	const response = await SELF.fetch(`${ORIGIN}/rooms/987670/warning`, {
		method: 'PUT',
		headers: await bearer('987670'),
		body: new URLSearchParams({ warningMask: '1' }),
	})
	expect(response.status).toBe(200)
	const stored = await env.DB.prepare('SELECT data FROM room WHERE room_id=987670').first<{
		data: string
	}>()
	expect(JSON.parse(stored!.data)).not.toHaveProperty('Badges')
})

// The badge lookup runs on every room page, served by a partial index over the badge rows
// (api migrations/0035, mirrored in SCHEMA_DDL above). Only a PUBLISHED badge with a built save
// hydrates; a draft stays on its creator's Studio shelf.
it("GET /rooms/:id hydrates the room's published badges", async () => {
	await seedRoomWithSubRooms(env.DB, {
		RoomId: 987671,
		Name: 'BadgeHydration',
		CreatorAccountId: 987671,
		SubRooms: [],
	})
	const badge = (id: string, roomId: number, accessibility: number, saves: unknown[]) =>
		JSON.stringify({
			CustomAvatarItemId: id,
			CreatorAccountId: 987671,
			Name: id,
			OutfitType: 1000,
			Accessibility: accessibility,
			CurrentSaves: saves,
			CustomBadgeMetadata: { RoomId: roomId },
		})
	const insert = env.DB.prepare('INSERT INTO custom_avatar_item (data) VALUES (?)')
	await env.DB.batch([
		insert.bind(badge('badge-published', 987671, 1, [{ BodyType: 0 }])),
		insert.bind(badge('badge-draft', 987671, 0, [{ BodyType: 0 }])),
		insert.bind(badge('badge-unbuilt', 987671, 1, [])),
		insert.bind(badge('badge-other-room', 987670, 1, [{ BodyType: 0 }])),
	])
	// Twice: the second read takes the path that remembers the table exists.
	for (let i = 0; i < 2; i++) {
		const res = await SELF.fetch(`${ORIGIN}/rooms/987671`, {
			headers: await bearer('1', ['developer']),
		})
		expect(res.status).toBe(200)
		const room = (await res.json()) as { Badges: Array<{ CustomAvatarItemId: string }> }
		expect(room.Badges.map((b) => b.CustomAvatarItemId)).toEqual(['badge-published'])
	}
})
