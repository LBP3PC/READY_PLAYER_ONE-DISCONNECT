// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { getRoomById, putUnityAsset, seedRoomWithSubRooms } from '@repo/domain'

import { bearer, ORIGIN, setupSchema } from './support/harness'

beforeAll(setupSchema)

describe('Studio source revision permissions', () => {
	it('keeps drafts and historical source behind save-history permissions', async () => {
		const roomId = 987650
		await seedRoomWithSubRooms(env.DB, {
			RoomId: roomId,
			Name: 'PrivateStudioDraft',
			CreatorAccountId: 987650,
			Accessibility: 0,
			Roles: [{ AccountId: 987651, Role: 30 }],
			SubRooms: [{ SubRoomId: roomId, Name: 'Home', CurrentSave: null }],
		})
		const url = `${ORIGIN}/rooms/${roomId}/subrooms/${roomId}/unityasset`
		const save = async (id: string, filename: string, autoPublish: boolean) => {
			const response = await SELF.fetch(`${ORIGIN}/rooms/${roomId}/subrooms/${roomId}/data`, {
				method: 'POST',
				headers: { ...(await bearer(String(roomId))), 'Content-Type': 'application/json' },
				body: JSON.stringify({
					UnityAssetId: id,
					UnityAsset: { Filename: filename, Hash: 'source-hash' },
					SubRoomData: { Filename: 'draft.room' },
					AutoPublish: autoPublish,
				}),
			})
			expect(response.status).toBe(200)
		}
		const oldId = '11111111-3333-4444-8555-666666666666'
		const currentId = '22222222-3333-4444-8555-666666666666'
		const draftId = '33333333-3333-4444-8555-666666666666'
		await save(oldId, 'old.json', true)
		await save(currentId, 'published.json', true)
		await save(draftId, 'draft.json', false)
		for (const headers of [{}, await bearer('987652')]) {
			for (const query of ['', `?unityAssetId=${currentId}`]) {
				const response = await SELF.fetch(url + query, { headers })
				expect(response.status).toBe(200)
				expect(await response.json()).toMatchObject({ filename: 'published.json' })
			}
		}
		for (const id of [draftId, oldId]) {
			expect((await SELF.fetch(url + `?unityAssetId=${id}`)).status).toBe(401)
			expect(
				(await SELF.fetch(url + `?unityAssetId=${id}`, { headers: await bearer('987652') })).status
			).toBe(403)
			for (const account of ['987650', '987651']) {
				const response = await SELF.fetch(url + `?unityAssetId=${id}`, {
					headers: await bearer(account),
				})
				expect(response.status).toBe(200)
				expect(await response.json()).toMatchObject({
					filename: id === draftId ? 'draft.json' : 'old.json',
				})
			}
		}
		for (const account of ['987650', '987651']) {
			const response = await SELF.fetch(url, { headers: await bearer(account) })
			expect(await response.json()).toMatchObject({ filename: 'draft.json' })
		}
		// A reused asset ID must not make a newer draft public or hide it from its owner.
		await save(currentId, 'replacement-draft.json', false)
		const publicSource = await SELF.fetch(url + `?unityAssetId=${currentId}`)
		expect(await publicSource.json()).toMatchObject({ filename: 'published.json' })
		const ownerSource = await SELF.fetch(url + `?unityAssetId=${currentId}`, {
			headers: await bearer('987650'),
		})
		expect(await ownerSource.json()).toMatchObject({ filename: 'replacement-draft.json' })
	})
	it('does not expose an unpublished first revision through default lookup', async () => {
		await seedRoomWithSubRooms(env.DB, {
			RoomId: 987660,
			Name: 'UnpublishedStudioSource',
			CreatorAccountId: 987660,
			Roles: [],
			SubRooms: [{ SubRoomId: 987660, Name: 'Home', CurrentSave: null }],
		})
		const url = `${ORIGIN}/rooms/987660/subrooms/987660`
		const saved = await SELF.fetch(url + '/data', {
			method: 'POST',
			headers: { ...(await bearer('987660')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				UnityAssetId: '44444444-3333-4444-8555-666666666666',
				UnityAsset: { Filename: 'first-draft.json', Hash: null },
				AutoPublish: false,
			}),
		})
		expect(saved.status).toBe(200)
		expect((await SELF.fetch(url + '/unityasset')).status).toBe(404)
		expect(
			(await SELF.fetch(url + '/unityasset', { headers: await bearer('987661') })).status
		).toBe(404)
		const source = await SELF.fetch(url + '/unityasset', { headers: await bearer('987660') })
		expect(source.status).toBe(200)
		expect(await source.json()).toMatchObject({ filename: 'first-draft.json' })
	})
})

it('retains Studio invention dependencies through room save and reload without a root Studio build', async () => {
	const roomId = 987690
	const assetId = '55555555-3333-4444-8555-666666666666'
	await seedRoomWithSubRooms(env.DB, {
		RoomId: roomId,
		Name: 'InventionDependencySave',
		CreatorAccountId: roomId,
		IsDorm: true,
		SubRooms: [{ SubRoomId: roomId, Name: 'Home', CurrentSave: null }],
	})
	for (const target of [0, 2])
		await putUnityAsset(env.DB, {
			UnityAssetId: assetId,
			Target: target,
			Version: 5,
			Filename: `studio/123/${assetId}.${target}.assetbundle`,
			Hash: `hash-${target}`,
		})
	const root = `${ORIGIN}/rooms/${roomId}/subrooms/${roomId}`
	const save = async (ids: string[]) => {
		const r = await SELF.fetch(root + '/data', {
			method: 'POST',
			headers: { ...(await bearer(String(roomId))), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				SubRoomData: { Filename: 'invention-scene.room' },
				ReferencedUnityAssetIds: ids,
			}),
		})
		expect(r.status).toBe(200)
		return (await r.json()) as {
			value: { subRoomDataSave: { subRoomDataSaveId: number; referencedUnityAssetIds: string[] } }
		}
	}
	const saved = await save([assetId])
	expect(saved.value.subRoomDataSave.referencedUnityAssetIds).toEqual([assetId])
	const room = await getRoomById(env.DB, roomId)
	expect((room!.SubRooms as Array<{ CurrentSave: unknown }>)[0]!.CurrentSave).toMatchObject({
		ReferencedUnityAssetIds: [assetId],
	})
	for (const target of [0, 2]) {
		const response = await SELF.fetch(
			`${root}/saves/${saved.value.subRoomDataSave.subRoomDataSaveId}?unityAssetTarget=${target}`,
			{ headers: await bearer(String(roomId)) }
		)
		expect(await response.json()).toMatchObject({
			UnityAssetId: null,
			UnitySubAssets: [],
			ReferencedUnityAssetIds: [assetId],
			ReferencedUnityAssets: [
				{
					UnityAssetId: assetId,
					UnityAsset: `studio/123/${assetId}.${target}.assetbundle`,
					UnityAssetHash: `hash-${target}`,
				},
			],
		})
	}
	const repeated = await save([assetId, assetId.toUpperCase()])
	const deduplicated = await SELF.fetch(
		`${root}/saves/${repeated.value.subRoomDataSave.subRoomDataSaveId}?unityAssetTarget=0`,
		{ headers: await bearer(String(roomId)) }
	)
	expect(await deduplicated.json()).toMatchObject({
		ReferencedUnityAssets: [{ UnityAssetId: assetId, UnityAssetHash: 'hash-0' }],
	})
	await save([])
	const cleared = await getRoomById(env.DB, roomId)
	expect((cleared!.SubRooms as Array<{ CurrentSave: unknown }>)[0]!.CurrentSave).toMatchObject({
		ReferencedUnityAssetIds: [],
		ReferencedUnityAssets: [],
	})
})

it('reviews Studio saves for invention creation without publishing drafts or overriding staff', async () => {
	const roomId = 987680
	const subRoomId = 987680
	await seedRoomWithSubRooms(env.DB, {
		RoomId: roomId,
		Name: 'StudioInventionReview',
		CreatorAccountId: 987680,
		Roles: [{ AccountId: 987681, Role: 30 }],
		SubRooms: [{ SubRoomId: subRoomId, Name: 'Home', CurrentSave: null }],
	})
	const root = `${ORIGIN}/rooms/${roomId}/subrooms/${subRoomId}`
	const save = async (autoPublish: boolean) => {
		const response = await SELF.fetch(root + '/data', {
			method: 'POST',
			headers: { ...(await bearer('987680')), 'Content-Type': 'application/json' },
			body: JSON.stringify({
				UnityAssetId: '44444444-3333-4444-8555-666666666666',
				UnityAsset: { Filename: 'review-source.json', Hash: 'source-hash' },
				AutoPublish: autoPublish,
			}),
		})
		const body = (await response.json()) as {
			value: { subRoomDataSave: { subRoomDataSaveId: number } }
		}
		return body.value.subRoomDataSave.subRoomDataSaveId
	}
	const currentId = await save(true)
	const draftId = await save(false)
	const review = async (id: number, account?: string, prefix = root) =>
		SELF.fetch(`${prefix}/datasaves/${id}/requestAutomatedModeration`, {
			method: 'POST',
			headers: account ? await bearer(account) : {},
		})
	expect((await review(currentId)).status).toBe(401)
	expect((await review(currentId, '987682')).status).toBe(403)
	expect(
		(await review(currentId, '987680', `${ORIGIN}/rooms/1/subrooms/${subRoomId}`)).status
	).toBe(404)
	expect((await review(99999999, '987680')).status).toBe(404)
	for (const id of [currentId, currentId, draftId]) {
		const response = await review(id, '987681')
		expect(response.status).toBe(200)
		expect(await response.json()).toMatchObject({
			success: true,
			value: {
				RoomId: roomId,
				SubRooms: [
					{
						LastModeratedSaveModerationState: 2,
						StagedSubRoomDataSaveId: draftId,
						CurrentSave: { SubRoomDataSaveId: currentId, ModerationState: 2 },
					},
				],
			},
		})
	}
	const detail = await SELF.fetch(root + `/saves/${draftId}`, { headers: await bearer('987680') })
	expect(await detail.json()).toMatchObject({
		ModerationState: 2,
		UnityAssetId: '44444444-3333-4444-8555-666666666666',
	})
	for (const state of [3, 4, 5, 6]) {
		await env.DB.prepare(
			"UPDATE subroom_save SET data=json_set(data, '$.ModerationState', ?1) WHERE sub_room_data_save_id=?2"
		)
			.bind(state, draftId)
			.run()
		expect((await review(draftId, '987680')).status).toBe(200)
		const stored = await env.DB.prepare(
			"SELECT json_extract(data, '$.ModerationState') AS state FROM subroom_save WHERE sub_room_data_save_id=?1"
		)
			.bind(draftId)
			.first<{ state: number }>()
		expect(stored!.state).toBe(state)
	}
})
