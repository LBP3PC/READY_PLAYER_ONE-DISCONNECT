// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import { bearer, ORIGIN, setupSchema } from './support/harness'

beforeAll(setupSchema)

// Room and subroom names take letters, digits, dashes, underscores and commas, at most 32
// (see `roomNameRejection` in @repo/domain — usernames are held to the narrower rule, with
// none of the punctuation). All four routes that take a player-supplied name enforce it, and each
// keeps its OWN refusal shape: the create
// paths answer the lowercase `{ success, error, value }` envelope, the two settings
// routes answer `{ Success, ErrorId, Error }` with the same `Rooms.InvalidName` id they
// already used for an empty name. The client keys off those, so the rule had to fit the
// existing shapes rather than introduce a fifth one.
//
// Names the SERVER generates are exempt on purpose — a dorm is `@<username>'s Dorm`,
// which this rule would reject. That's why the check lives in the handlers.
describe('room name validation', () => {
	const bad = ['My Room', 'punct!', 'a'.repeat(33)]

	const post = async (path: string, fields: Record<string, string>, sub: string) =>
		SELF.fetch(`${ORIGIN}${path}`, {
			method: 'POST',
			headers: { ...(await bearer(sub)), 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams(fields).toString(),
		})

	const put = async (path: string, fields: Record<string, string>, sub: string) =>
		SELF.fetch(`${ORIGIN}${path}`, {
			method: 'PUT',
			headers: { ...(await bearer(sub)), 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams(fields).toString(),
		})

	it('refuses a bad name when a player clones a room into existence', async () => {
		for (const name of bad) {
			const res = await post('/rooms/2/clone', { name }, '1')
			const body = (await res.json()) as { success: boolean; error: string; value: unknown }
			expect(body.success, name).toBe(false)
			expect(body.error).toMatch(
				/letters, numbers, dashes, underscores and commas|at most 32 characters/
			)
			expect(body.value).toBeNull()
		}
	})

	it('refuses a bad name on rename, with the id the client already handles', async () => {
		for (const name of bad) {
			const res = await put('/rooms/2/name', { name }, '1')
			const body = (await res.json()) as { Success: boolean; ErrorId: string; Error: string }
			expect(body.Success, name).toBe(false)
			expect(body.ErrorId).toBe('Rooms.InvalidName')
			expect(body.Error).toMatch(
				/letters, numbers, dashes, underscores and commas|at most 32 characters/
			)
		}

		// Unchanged: the refusals above never reached the write.
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/2`, { headers: await bearer('1', ['developer']) })
		).json()) as { Name: string }
		expect(room.Name).not.toMatch(/[^A-Za-z0-9_,-]/)
	})

	it('refuses a bad name when creating or modifying a subroom', async () => {
		for (const name of bad) {
			const created = await post('/rooms/2/subrooms', { name }, '1')
			const env1 = (await created.json()) as { success: boolean; error: string }
			expect(env1.success, name).toBe(false)
			expect(env1.error).toMatch(
				/letters, numbers, dashes, underscores and commas|at most 32 characters/
			)

			const modified = await put(
				'/rooms/2/subrooms/2/modify',
				{ name, accessibility: '1', maxPlayers: '20' },
				'1'
			)
			const res2 = (await modified.json()) as { Success: boolean; ErrorId: string }
			expect(res2.Success, name).toBe(false)
			expect(res2.ErrorId).toBe('Rooms.InvalidName')
		}
	})

	it('accepts a 32-character name, and a dash, underscore or comma where a space is refused', async () => {
		for (const name of ['a'.repeat(32), 'Laser_Tag', 'Laser-Tag', 'Lasers,Tags']) {
			const res = await post('/rooms/2/subrooms', { name }, '1')
			const body = (await res.json()) as {
				success: boolean
				value: { SubRooms: Array<{ Name: string }> }
			}
			expect(body.success, name).toBe(true)
			expect(body.value.SubRooms.some((s) => s.Name === name)).toBe(true)
		}
	})
})
