// Split out of api.test.ts: each file runs in its own isolate, so no isolate serves more than a
// few hundred requests — in the single file the per-request time grew from ~2ms to ~3.8s and
// five tests ran past the 5s default. The seeded schema lives in ./support/harness.
import { env, SELF } from 'cloudflare:test'
import { beforeAll, describe, expect, it } from 'vitest'

import {
	answerRoomRoleInvite,
	getRoomById,
	RelationshipType,
	removeRoomRole,
	roomRoleWrites,
	seedRoomWithSubRooms,
	setListItems,
	setRoomRole,
	showcaseListKey,
} from '@repo/domain'

import importRooms from '../../../static/ImportRooms.json'
import { bearer, clearPresence, ORIGIN, putInRoom, setupSchema } from './support/harness'

import type { Room } from '@repo/domain'

beforeAll(setupSchema)

describe('rooms endpoints', () => {
	it('GET / reports service status', async () => {
		const res = await SELF.fetch(`${ORIGIN}/`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({ service: 'rooms', status: 'ok' })
	})

	it('GET /rooms/1 returns the seeded dorm with its SubRoom scene', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/1?include=1325`, {
			headers: await bearer('1', ['developer']),
		})
		expect(res.status).toBe(200)
		const body = (await res.json()) as {
			RoomId: number
			Name: string
			IsDorm: boolean
			SubRooms: Array<{ UnitySceneId: string }>
		}
		expect(body).toMatchObject({ RoomId: 1, Name: 'DormRoom', IsDorm: true })
		expect(body.SubRooms[0].UnitySceneId).toBe('76d98498-60a1-430c-ab76-b54a29b7a163')
	})

	// The client needs these fields even when no boosts or snapshots exist. FriendlyName is
	// deliberately absent: migration 0017 strips it and this server uses Name instead.
	it('GET /rooms/:id carries BoostCount, CurrentSnapshotId and CCU, and no FriendlyName', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/1`, { headers: await bearer('1', ['developer']) })
		expect(res.status).toBe(200)
		const body = (await res.json()) as Record<string, unknown>
		expect(body).toHaveProperty('BoostCount', 0)
		expect(body).toHaveProperty('CurrentSnapshotId', null)
		expect(body).toHaveProperty('CCU', null)
		expect(body).not.toHaveProperty('FriendlyName')
	})

	it('GET /rooms/:id/boosts/:playerId/count answers a bare 0 for an unknown room', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/112/boosts/205/count`)
		expect(res.status).toBe(200)
		expect(await res.json()).toBe(0)
	})

	it('serves active boost counts for rooms and players, excluding expired boosts', async () => {
		const day = 24 * 60 * 60 * 1000
		const insert = env.DB.prepare(
			`INSERT INTO room_boost (room_id, account_id, request_id, amount, created_at)
			 VALUES (1, ?1, ?2, ?3, ?4)`
		)
		await env.DB.batch([
			insert.bind(900, 'boost-a', 3, new Date().toISOString()),
			insert.bind(901, 'boost-b', 1, new Date(Date.now() - day).toISOString()),
			insert.bind(900, 'boost-c', 5, new Date(Date.now() - 40 * day).toISOString()),
		])
		const get = async (path: string) => (await SELF.fetch(`${ORIGIN}${path}`)).json()
		expect(await get('/rooms/1/boosts/count')).toBe(4)
		expect(await get('/rooms/99999999/boosts/count')).toBe(0)
		expect(await get('/rooms/1/boosts/900/count')).toBe(3)
		expect(await get('/rooms/1/boosts/902/count')).toBe(0)
		const counts = async (body: string, roomId = 1) =>
			(await SELF.fetch(`${ORIGIN}/rooms/${roomId}/boosts/counts`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body,
			})).json()
		expect(await counts('id=900&id=901&id=902&id=abc&id=900')).toEqual({ '900': 3, '901': 1, '902': 0 })
		expect(await counts('')).toEqual({})
		expect(await counts('id=900', 99999999)).toEqual({ '900': 0 })
		expect(((await get('/rooms/1')) as { BoostCount: number }).BoostCount).toBe(4)
		expect(((await get('/rooms/2')) as { BoostCount: number }).BoostCount).toBe(0)
		await env.DB.prepare('DELETE FROM room_boost WHERE room_id = 1').run()
	})

	it('derives room capacity from subrooms according to MaxPlayerCalculationMode', async () => {
		const sub = (SubRoomId: number, MaxPlayers: number, Accessibility: number) => ({
			SubRoomId, Name: `Sub${SubRoomId}`,
			UnitySceneId: '76d98498-60a1-430c-ab76-b54a29b7a163', MaxPlayers, Accessibility,
		})
		const cases: Array<[number, Record<string, unknown>, number]> = [
			[97001, { MaxPlayers: 20, SubRooms: [sub(970011, 10, 2)] }, 10],
			[97002, { MaxPlayers: 20, SubRooms: [sub(970021, 12, 1), sub(970022, 4, 2)] }, 4],
			[97003, { MaxPlayers: 20, MaxPlayerCalculationMode: 1, SubRooms: [sub(970031, 12, 1), sub(970032, 4, 2), sub(970033, 16, 1)] }, 12],
			[97004, { MaxPlayers: 20, MaxPlayerCalculationMode: 1, SubRooms: [sub(970041, 8, 2), sub(970042, 6, 0)] }, 6],
		]
		for (const [RoomId, room, expected] of cases) {
			await seedRoomWithSubRooms(env.DB, {
				Name: `CapRoom${RoomId}`, CreatorAccountId: 2, Accessibility: 2,
				MaxPlayerCalculationMode: 0, RoomId, ...room,
			})
			const res = await SELF.fetch(`${ORIGIN}/rooms/${RoomId}`, { headers: await bearer('2') })
			expect(res.status).toBe(200)
			expect(((await res.json()) as { MaxPlayers: number }).MaxPlayers, String(RoomId)).toBe(expected)
		}
		await env.DB.prepare('DELETE FROM subroom WHERE room_id BETWEEN 97001 AND 97004').run()
		await env.DB.prepare('DELETE FROM room WHERE room_id BETWEEN 97001 AND 97004').run()
	})

	it('serves fixed PublishStateAvailability on direct and feed reads', async () => {
		const availability = {
			CanSaveAsBeta: true, CanSaveAsUpdate: true, AvailableUpdateTokenCount: 99,
			NextAvailableUpdateDateTimeUtc: '2026-10-22T00:00:00Z',
		}
		const one = await SELF.fetch(`${ORIGIN}/rooms/1`, { headers: await bearer('1', ['developer']) })
		expect(((await one.json()) as Record<string, unknown>).PublishStateAvailability).toEqual(availability)
		const hot = (await (await SELF.fetch(`${ORIGIN}/rooms/hot`)).json()) as { Results: Array<Record<string, unknown>> }
		expect(hot.Results.length).toBeGreaterThan(0)
		for (const room of hot.Results) expect(room.PublishStateAvailability).toEqual(availability)
	})

	// Pinned whole: these are the numbers the client's publish UI counts against, and
	// `error: null` / `error_id` is a different envelope from the room mutations' — a
	// "cleanup" that unified the two would break the client silently.
	it('GET /publishState/configs returns the republish limits', async () => {
		const res = await SELF.fetch(`${ORIGIN}/publishState/configs`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual({
			value: {
				UpdateMaxCount: 3,
				UpdateRollingWindowInDays: 365,
				UpdateExpirationInDays: 30,
				UpdateCooldownInDays: 45,
			},
			success: true,
			error_id: null,
			error: null,
		})
	})

	// A player without showcased rooms, including an unknown player, gets an empty list.
	it('GET /showcase/:playerId returns [] for a player without a showcase', async () => {
		const res = await SELF.fetch(`${ORIGIN}/showcase/205`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([])

		const unknown = await SELF.fetch(`${ORIGIN}/showcase/99999`)
		expect(unknown.status).toBe(200)
		expect(await unknown.json()).toEqual([])
	})

	it('serves the showcased public rooms owned by the player in list order', async () => {
		for (const room of [
			{ RoomId: 96101, Name: 'ShowA', CreatorAccountId: 9610, Accessibility: 1 },
			{ RoomId: 96102, Name: 'ShowB', CreatorAccountId: 9610, Accessibility: 1 },
			{ RoomId: 96103, Name: 'ShowPrivate', CreatorAccountId: 9610, Accessibility: 0 },
			{ RoomId: 96104, Name: 'NotMine', CreatorAccountId: 9611, Accessibility: 1 },
		]) {
			await env.DB.prepare('INSERT INTO room (data) VALUES (?1)').bind(JSON.stringify(room)).run()
		}
		await setListItems(env.DB, showcaseListKey(9610), ['96102', '96103', '96104', '96101', '96199'])

		const res = await SELF.fetch(`${ORIGIN}/showcase/9610`)
		expect(res.status).toBe(200)
		expect(await res.json()).toEqual([96102, 96101])
		await env.DB.prepare('DELETE FROM room WHERE room_id BETWEEN 96101 AND 96104').run()
	})

	it('GET /showcase/:playerId 404s on a non-numeric id', async () => {
		expect((await SELF.fetch(`${ORIGIN}/showcase/abc`)).status).toBe(404)
	})

	// The friends list resolves each friend's room through GET /rooms/:id, and a friend is
	// usually in their dorm, which is Private. A 404 there blanked the whole list.
	it('GET /rooms/:id serves an unpublished room to a friend of someone in it, and nobody else', async () => {
		await env.DB.prepare('INSERT INTO room (data) VALUES (?1)')
			.bind(
				JSON.stringify({
					RoomId: 30951,
					Name: 'FriendsDorm',
					CreatorAccountId: 901,
					Accessibility: 0,
					IsDorm: true,
					SubRooms: [],
				})
			)
			.run()
		// 902 is friends with the owner (the row runs either way); 903 has only a pending request.
		await env.DB.prepare(
			`INSERT INTO relationship (requester_id, target_id, relationship_type)
			 VALUES (902, 901, ?1), (901, 903, ?2)`
		)
			.bind(RelationshipType.Friend, RelationshipType.FriendRequestSent)
			.run()
		const read = async (player: string) =>
			(await SELF.fetch(`${ORIGIN}/rooms/30951?include=767277`, { headers: await bearer(player) }))
				.status

		// Owner not online: nobody but the owner sees it.
		expect(await read('901')).toBe(200)
		expect(await read('902')).toBe(404)
		expect(await read('904')).toBe(404)

		// Owner in their dorm: their friend sees it; a pending request and a stranger don't.
		await putInRoom(901, 30951)
		expect(await read('902')).toBe(200)
		expect(await read('903')).toBe(404)
		expect(await read('904')).toBe(404)

		// A lapsed presence row grants nothing.
		await putInRoom(901, 30951, { expired: true })
		expect(await read('902')).toBe(404)
		await clearPresence(901)
	})

	it('GET /rooms/:id 404s for a room not in D1', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/99999`, {
			headers: await bearer('1', ['developer']),
		})
		expect(res.status).toBe(404)
	})

	it('GET /rooms?name= resolves a real room case-insensitively', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms?name=reccenter`)
		expect(res.status).toBe(200)
		expect(await res.json()).toMatchObject({ Name: 'RecCenter' })
	})

	it('GET /rooms?name= returns {} when nothing matches', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms?name=NoSuchRoomHere`)
		expect(await res.json()).toEqual({})
	})

	it('GET /rooms with no id or name returns 400', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms`)
		expect(res.status).toBe(400)
	})

	it('GET /rooms/bulk?id= returns the matching rooms', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/bulk?id=1,2`)
		expect(res.status).toBe(200)
		const body = (await res.json()) as Array<{ RoomId: number; Name: string }>
		expect(body.map((r) => r.Name).sort()).toEqual(['DormRoom', 'RecCenter'])
	})

	it('GET /rooms/bulk takes repeated id params, like the POST form', async () => {
		// The client spells the GET's id list the same way it spells the POST body's — one
		// `id` per room. Reading only the first left it rendering a single room.
		const res = await SELF.fetch(
			`${ORIGIN}/rooms/bulk?id=1&id=2&id=999999&excludePrivateRooms=False`
		)
		expect(res.status).toBe(200)
		const body = (await res.json()) as Array<{ Name: string }>
		expect(body.map((r) => r.Name).sort()).toEqual(['DormRoom', 'RecCenter'])
	})

	it('GET /rooms/bulk?name=RecCenter returns [RecCenter]', async () => {
		const res = await SELF.fetch(`${ORIGIN}/rooms/bulk?name=RecCenter`)
		const body = (await res.json()) as Array<{ Name: string }>
		expect(body.map((r) => r.Name)).toEqual(['RecCenter'])
	})

	it('POST /rooms/bulk takes repeated id fields in a form body', async () => {
		const post = async (body: string) =>
			SELF.fetch(`${ORIGIN}/rooms/bulk`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body,
			})

		// The client's form: one `id` per room, plus the filter. An id that isn't in D1 is
		// simply absent, so the answer can be shorter than the request.
		const res = await post('id=1&id=2&id=999999&excludePrivateRooms=False')
		expect(res.status).toBe(200)
		const body = (await res.json()) as Array<{ RoomId: number; Name: string }>
		expect(body.map((r) => r.Name).sort()).toEqual(['DormRoom', 'RecCenter'])

		// Comma-separated values inside an `id` work too, as they do on the GET.
		const commas = (await (await post('id=1,2')).json()) as Array<{ Name: string }>
		expect(commas.map((r) => r.Name).sort()).toEqual(['DormRoom', 'RecCenter'])

		// `excludePrivateRooms=True` drops the non-public rooms — the dorm here.
		const publicOnly = (await (await post('id=1&id=2&excludePrivateRooms=True')).json()) as Array<{
			Name: string
			Accessibility: number
		}>
		expect(publicOnly.map((r) => r.Name)).toEqual(['RecCenter'])
		expect(publicOnly.every((r) => r.Accessibility === 1)).toBe(true)

		// No ids is an empty array, not a 400 — unlike the GET, which needs an `id` or `name`.
		expect(await (await post('excludePrivateRooms=False')).json()).toEqual([])

		// D1 binds one parameter per id and caps a query at 100, so a longer list is refused
		// rather than split — a caller asking about more than a hundred rooms at once has lost
		// track of what it is rendering.
		const idList = (n: number) => Array.from({ length: n }, (_, i) => 500000 + i)
		expect(
			(
				await post(
					idList(100)
						.map((id) => `id=${id}`)
						.join('&')
				)
			).status
		).toBe(200)
		const overCap = await post(
			idList(101)
				.map((id) => `id=${id}`)
				.join('&')
		)
		expect(overCap.status).toBe(400)
		expect(await overCap.json()).toBe('At most 100 room ids may be looked up at once')

		// The GET form has the same cap, counting the ids inside its comma-separated `id`.
		const overCapGet = await SELF.fetch(`${ORIGIN}/rooms/bulk?id=${idList(101).join(',')}`)
		expect(overCapGet.status).toBe(400)
	})

	it('GET /rooms/ownedby/me is auth-gated and scoped to the caller', async () => {
		// No token → 401, no stub-account fallback (would otherwise leak account 1).
		const noAuth = await SELF.fetch(`${ORIGIN}/rooms/ownedby/me`)
		expect(noAuth.status).toBe(401)
		// Account 1 owns all the seeded rooms, but the dorm is excluded here.
		const mine = (await (
			await SELF.fetch(`${ORIGIN}/rooms/ownedby/me`, { headers: await bearer('1') })
		).json()) as Array<{ RoomId: number; IsDorm?: boolean }>
		expect(mine.length).toBe(importRooms.filter((r) => r.IsDorm !== true).length)
		// The dorm (RoomId 1) is auto-provisioned, so it never appears.
		expect(mine.some((r) => r.RoomId === 1 || r.IsDorm === true)).toBe(false)
		// A different account owns none of them.
		const other = (await (
			await SELF.fetch(`${ORIGIN}/rooms/ownedby/me`, { headers: await bearer('999') })
		).json()) as unknown[]
		expect(other).toEqual([])
	})

	it('GET /dormroom/me serves the caller’s dorm id, not the room', async () => {
		// No token → 401. Without this the endpoint would hand out (and provision) a dorm
		// for whichever account a fallback picked.
		const noAuth = await SELF.fetch(`${ORIGIN}/dormroom/me`)
		expect(noAuth.status).toBe(401)

		// Account 1 owns the seeded dorm (RoomId 1). The body is that id ALONE — a bare
		// JSON number, not the room and not an object wrapping the id.
		const res = await SELF.fetch(`${ORIGIN}/dormroom/me`, { headers: await bearer('1') })
		expect(res.status).toBe(200)
		expect(await res.json()).toBe(1)

		// It is the id of a room that really is the caller's dorm — the caller fetches the
		// room itself from /rooms/{id}.
		const room = (await (
			await SELF.fetch(`${ORIGIN}/rooms/1`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			RoomId: number
			IsDorm: boolean
			CreatorAccountId: number
		}
		expect(room).toMatchObject({ RoomId: 1, IsDorm: true, CreatorAccountId: 1 })

		// A player who has never entered their dorm gets one provisioned rather than a
		// 404 — the get-or-create still happens, only the payload shrank. And it belongs
		// to THEM, not the template dorm they were cloned from.
		const fresh = (await (
			await SELF.fetch(`${ORIGIN}/dormroom/me`, { headers: await bearer('999') })
		).json()) as number
		expect(typeof fresh).toBe('number')
		expect(fresh).not.toBe(1)

		const provisioned = (await (
			await SELF.fetch(`${ORIGIN}/rooms/${fresh}`, { headers: await bearer('1', ['developer']) })
		).json()) as {
			IsDorm: boolean
			CreatorAccountId: number
		}
		expect(provisioned).toMatchObject({ IsDorm: true, CreatorAccountId: 999 })

		// Idempotent: the second call is the same dorm, not a second one.
		const again = (await (
			await SELF.fetch(`${ORIGIN}/dormroom/me`, { headers: await bearer('999') })
		).json()) as number
		expect(again).toBe(fresh)
	})

	// The 2026 client picks between a player's dorms (custom dorms are clones of a dorm) and
	// expects `GET /dormroom/me` to answer the pick from then on.
	it('PUT /dormroom/me picks the caller’s dorm, and GET serves it', async () => {
		const put = async (roomId: string | undefined, sub = '878') =>
			SELF.fetch(`${ORIGIN}/dormroom/me`, {
				method: 'PUT',
				headers: {
					...(await bearer(sub)),
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: roomId === undefined ? '' : new URLSearchParams({ roomId }).toString(),
			})
		const get = async () =>
			(await (
				await SELF.fetch(`${ORIGIN}/dormroom/me`, { headers: await bearer('878') })
			).json()) as number

		const provisioned = await get()
		const seed = async (room: Record<string, unknown>) =>
			env.DB.prepare('INSERT INTO room (data) VALUES (?1)').bind(JSON.stringify(room)).run()
		await seed({
			RoomId: 30591,
			Name: 'PickCustomDorm',
			CreatorAccountId: 878,
			IsDorm: true,
			SubRooms: [],
			Roles: [{ AccountId: 878, Role: 255 }],
		})
		await seed({
			RoomId: 30592,
			Name: 'PickNotADorm',
			CreatorAccountId: 878,
			SubRooms: [],
			Roles: [{ AccountId: 878, Role: 255 }],
		})
		await seed({
			RoomId: 30593,
			Name: 'PickSomeoneElsesDorm',
			CreatorAccountId: 879,
			IsDorm: true,
			SubRooms: [],
			Roles: [{ AccountId: 879, Role: 255 }],
		})

		// No token → 401, and nothing stored.
		expect((await SELF.fetch(`${ORIGIN}/dormroom/me`, { method: 'PUT' })).status).toBe(401)

		// The reply is the picked id in the PascalCase envelope (the GET still answers a bare
		// number), and the GET serves it from then on.
		const ok = await put('30591')
		expect(ok.status).toBe(200)
		expect(await ok.json()).toEqual({ Value: 30591, Success: true, Error: null, error_id: null })
		expect(await get()).toBe(30591)

		// Refusals are the same envelope, and leave the pick alone.
		const refused = await put('30592')
		expect(refused.status).toBe(403)
		expect(await refused.json()).toEqual({
			Value: null,
			Success: false,
			Error: expect.any(String),
			error_id: null,
		})
		expect((await put(undefined)).status).toBe(400)
		expect((await put('abc')).status).toBe(400)
		expect((await put('99999999')).status).toBe(404)
		expect((await put('30592')).status).toBe(403)
		expect((await put('30593')).status).toBe(403)
		expect(await get()).toBe(30591)

		// The pick MERGES into the settings map — the player's other settings survive it.
		await env.RECFLARE_PLAYER_SETTINGS.put(
			'player:878',
			JSON.stringify({
				...(await env.RECFLARE_PLAYER_SETTINGS.get<Record<string, string>>('player:878', 'json')),
				Other: '1',
			})
		)
		expect((await put(String(provisioned))).status).toBe(200)
		expect(await env.RECFLARE_PLAYER_SETTINGS.get('player:878', 'json')).toEqual({
			DormRoomId: String(provisioned),
			Other: '1',
		})
		expect(await get()).toBe(provisioned)

		// A pick that went stale (the room is gone) falls back to the provisioned dorm.
		expect((await put('30591')).status).toBe(200)
		await env.DB.prepare('DELETE FROM room WHERE room_id = 30591').run()
		expect(await get()).toBe(provisioned)

		// Room ids are MAX + 1, so leaving these high ids behind would shift the ids every
		// later test's rooms get.
		await env.DB.prepare('DELETE FROM room WHERE room_id IN (30592, 30593)').run()
	})

	// The website's "My rooms" list is a browser calling this worker from another origin,
	// so a response without CORS headers is one the browser throws away — and the page
	// can't tell that apart from the server being down. Pinned on the preflight too: the
	// SPA sends `Authorization`, which makes even the GET a preflighted request.
	it('answers CORS so the website can read a room list from the browser', async () => {
		const preflight = await SELF.fetch(`${ORIGIN}/rooms/ownedby/me`, {
			method: 'OPTIONS',
			headers: {
				origin: 'https://www.example.com',
				'access-control-request-method': 'GET',
				'access-control-request-headers': 'authorization',
			},
		})
		expect(preflight.status).toBe(204)
		expect(preflight.headers.get('access-control-allow-origin')).toBe('*')
		expect(preflight.headers.get('access-control-allow-headers')?.toLowerCase()).toContain(
			'authorization'
		)

		const res = await SELF.fetch(`${ORIGIN}/rooms/ownedby/me`, {
			headers: { ...(await bearer('1')), origin: 'https://www.example.com' },
		})
		expect(res.status).toBe(200)
		expect(res.headers.get('access-control-allow-origin')).toBe('*')
	})

	it('GET /rooms/ownedby|createdby/me lists the caller’s UNPUBLISHED rooms too', async () => {
		// "My Rooms" is the owner's own list, not a catalog: it must show a room that
		// isn't public yet, or a freshly created room (which starts Private — see
		// cloneRoom) would be invisible to the person who just made it. Only the
		// PUBLIC-facing `ownedby/:accountId` profile list filters on accessibility.
		const headers = {
			...(await bearer('804')),
			'Content-Type': 'application/x-www-form-urlencoded',
		}
		await SELF.fetch(`${ORIGIN}/rooms/24/clone`, {
			method: 'POST',
			headers,
			body: new URLSearchParams({ name: 'MyUnpublishedRoom' }).toString(),
		})

		const listOf = async (path: string) =>
			(await (await SELF.fetch(`${ORIGIN}${path}`, { headers })).json()) as Array<{
				Name: string
				Accessibility: number
			}>

		for (const path of [
			'/rooms/ownedby/me',
			'/rooms/createdby/me',
			'/roomserver/rooms/createdby/me',
		]) {
			const mine = await listOf(path)
			const room = mine.find((r) => r.Name === 'MyUnpublishedRoom')
			expect(room, `${path} must list the caller's unpublished room`).toBeDefined()
			expect(room!.Accessibility).toBe(0)
		}

		// The same room is absent from the account's PUBLIC profile list.
		const publicList = (await (await SELF.fetch(`${ORIGIN}/rooms/ownedby/804`)).json()) as Array<{
			Name: string
		}>
		expect(publicList.some((r) => r.Name === 'MyUnpublishedRoom')).toBe(false)
	})

	it('GET /rooms/contributedby/me lists rooms the caller owns or has a role in', async () => {
		// The roles half reads `room_role`, so a seeded room's roles go there too, as every
		// write in rooms-db does.
		const seed = (data: Record<string, unknown>) =>
			env.DB.batch([
				env.DB.prepare('INSERT INTO room (data) VALUES (?1)').bind(JSON.stringify(data)),
				...roomRoleWrites(env.DB, Number(data.RoomId), data as Room),
			])
		const contributed = async (accountId: string) => {
			const res = await SELF.fetch(`${ORIGIN}/rooms/contributedby/me`, {
				headers: await bearer(accountId),
			})
			const rooms = (await res.json()) as Array<{ RoomId: number }>
			return rooms.map((r) => r.RoomId).sort((a, b) => a - b)
		}

		// A room somebody else made, where 820 is a co-owner...
		await seed({
			RoomId: 30401,
			Name: 'ContribCoOwner',
			CreatorAccountId: 821,
			Accessibility: 1,
			SubRooms: [],
			Roles: [
				{ AccountId: 821, Role: 255 },
				{ AccountId: 820, Role: 30 },
			],
		})
		// ...one where they're only a host (every tier counts, not just owner-level)...
		await seed({
			RoomId: 30402,
			Name: 'ContribHost',
			CreatorAccountId: 821,
			// Unpublished: a contributor works on the room before it goes public, so
			// accessibility is not filtered here.
			Accessibility: 0,
			SubRooms: [],
			Roles: [{ AccountId: 820, Role: 10 }],
		})
		// ...one they created themselves, whose Roles name them as Creator (matched by BOTH
		// halves of the query, so it must still appear exactly once)...
		await seed({
			RoomId: 30403,
			Name: 'ContribOwn',
			CreatorAccountId: 820,
			Accessibility: 1,
			SubRooms: [],
			Roles: [{ AccountId: 820, Role: 255 }],
		})
		// ...one they created that names nobody in Roles at all — the older rooms have no
		// Roles key, and those reach the list on the creator half alone...
		await seed({
			RoomId: 30406,
			Name: 'ContribOwnNoRoles',
			CreatorAccountId: 820,
			Accessibility: 1,
			SubRooms: [],
		})
		// ...and their provisioned dorm, listed under "contributed" but not "owned".
		await seed({
			RoomId: 30407,
			Name: "@player820's Dorm",
			CreatorAccountId: 820,
			IsDorm: true,
			Accessibility: 2,
			SubRooms: [],
			Roles: [{ AccountId: 820, Role: 255 }],
		})
		// ...and a CUSTOM dorm, cloned after it: listed the same way.
		await seed({
			RoomId: 30409,
			Name: 'ContribCustomDorm',
			CreatorAccountId: 820,
			IsDorm: true,
			Accessibility: 0,
			SubRooms: [],
			Roles: [{ AccountId: 820, Role: 255 }],
		})
		// ...one they have nothing to do with, and one with no Roles key at all (the older
		// seeded rooms have none — json_each must drop them, not error).
		await seed({
			RoomId: 30404,
			Name: 'ContribOther',
			CreatorAccountId: 821,
			Accessibility: 1,
			SubRooms: [],
			Roles: [{ AccountId: 822, Role: 30 }],
		})
		await seed({ RoomId: 30405, Name: 'ContribNoRoles', CreatorAccountId: 821, SubRooms: [] })
		// ...and one where 820 has only been INVITED to co-own — `Role` 0 with the offer on
		// `InvitedRole`. They have no job in the room until they accept, so it stays out of
		// both of their lists, and the pending entry is not served as part of the room.
		await seed({
			RoomId: 30408,
			Name: 'ContribInvited',
			CreatorAccountId: 821,
			Accessibility: 1,
			SubRooms: [],
			Roles: [
				{ AccountId: 821, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 },
				{ AccountId: 820, Role: 0, LastChangedByAccountId: 821, InvitedRole: 30 },
			],
		})

		const res = await SELF.fetch(`${ORIGIN}/rooms/contributedby/me`, {
			headers: await bearer('820'),
		})
		expect(res.status).toBe(200)
		const rooms = (await res.json()) as Array<{ RoomId: number; Name: string }>
		// A bare array of the canonical room DTO — no envelope, no paging wrapper.
		expect(Array.isArray(rooms)).toBe(true)
		expect(rooms.map((r) => r.RoomId).sort((a, b) => a - b)).toEqual([
			30401, 30402, 30403, 30406, 30407, 30409,
		])
		// Their own rooms are IN — the list overlaps createdby/me rather than coming back
		// empty for someone who only ever built their own — and so are both dorms.
		expect(rooms[0]).toMatchObject({ Name: expect.any(String), Accessibility: expect.any(Number) })

		// The unanswered invite lists the room for NOBODY: not under "contributed" (above),
		// not under "owned".
		const owned = await SELF.fetch(`${ORIGIN}/rooms/ownedby/me`, { headers: await bearer('820') })
		const ownedIds = ((await owned.json()) as Array<{ RoomId: number }>).map((r) => r.RoomId)
		expect(ownedIds).toContain(30401)
		expect(ownedIds).not.toContain(30408)
		// Neither dorm is "owned": dorms are listed under "contributed" only.
		expect(ownedIds).not.toContain(30407)
		expect(ownedIds).not.toContain(30409)

		// Nor is the invited player part of the room as served: the room DTO carries only HELD
		// roles. `GET /rooms/:id/roles` DOES list the invite — the client shows pending invites
		// from it — and the stored room keeps the entry for the accept.
		type Served = { Roles: Array<{ AccountId: number; Role: number; InvitedRole: number }> }
		const servedRoles = async () =>
			(
				(await (
					await SELF.fetch(`${ORIGIN}/rooms/30408`, { headers: await bearer('1', ['developer']) })
				).json()) as Served
			).Roles
		expect(await servedRoles()).toEqual([
			{ AccountId: 821, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 },
		])
		expect(await (await SELF.fetch(`${ORIGIN}/rooms/30408/roles`)).json()).toEqual([
			{ AccountId: 821, Role: 255, LastChangedByAccountId: null, InvitedRole: 0 },
			{ AccountId: 820, Role: 0, LastChangedByAccountId: 821, InvitedRole: 30 },
		])
		expect(
			await env.DB.prepare(
				'SELECT role, invited_role FROM room_role WHERE room_id = 30408 AND account_id = 820'
			).first()
		).toEqual({ role: 0, invited_role: 30 })

		// Accepting is what puts them in: the room appears in both lists and the entry is served.
		const invitedRoom = (await getRoomById(env.DB, 30408))!
		expect(await answerRoomRoleInvite(env.DB, 30408, 820, 30, invitedRoom)).not.toBeNull()
		expect(await contributed('820')).toContain(30408)
		const ownedAfter = await SELF.fetch(`${ORIGIN}/rooms/ownedby/me`, {
			headers: await bearer('820'),
		})
		expect(((await ownedAfter.json()) as Array<{ RoomId: number }>).map((r) => r.RoomId)).toContain(
			30408
		)
		expect(await servedRoles()).toContainEqual(
			expect.objectContaining({ AccountId: 820, Role: 30, InvitedRole: 0 })
		)

		// A player who contributes to nothing gets an empty array, not a 404.
		const none = await SELF.fetch(`${ORIGIN}/rooms/contributedby/me`, {
			headers: await bearer('829'),
		})
		expect(await none.json()).toEqual([])

		// Auth-scoped: `me` is the token, so no token is a 401.
		expect((await SELF.fetch(`${ORIGIN}/rooms/contributedby/me`)).status).toBe(401)

		// Role changes move a room in and out of the list: granting 829 a role in 30404
		// lists it for them, and taking the role back drops it again.
		const other = (await getRoomById(env.DB, 30404))!
		const granted = await setRoomRole(env.DB, 30404, 829, 10, 821, other)
		expect(await contributed('829')).toEqual([30404])
		// The row carries the whole entry, as the blob does.
		expect(
			await env.DB.prepare(
				'SELECT role, invited_role, last_changed_by_account_id FROM room_role WHERE room_id = 30404 AND account_id = 829'
			).first()
		).toEqual({ role: 10, invited_role: 0, last_changed_by_account_id: 821 })
		await removeRoomRole(env.DB, 30404, 829, 821, granted!)
		expect(await contributed('829')).toEqual([])

		// The DB is shared across this file, and these are the only player-made public rooms
		// in it — leaving them behind changes what the `new`/`community` room feeds serve.
		await env.DB.prepare('DELETE FROM room WHERE room_id BETWEEN 30401 AND 30408').run()
		await env.DB.prepare('DELETE FROM room_role WHERE room_id BETWEEN 30401 AND 30408').run()
	})
})
