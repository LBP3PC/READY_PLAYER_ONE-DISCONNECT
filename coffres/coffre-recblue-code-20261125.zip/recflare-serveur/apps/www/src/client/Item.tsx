import { useEffect, useState } from 'react'

import { COACH_ACCOUNT_ID } from '../../../api/src/custom-avatar-items-load'
import { call, isAdmin, useAction, usernamesFor, where } from './api'

import type { CustomAvatarItem } from '../../../api/src/custom-avatar-items-db'
import type { SavedInvention } from '../../../api/src/inventions-db'
import type { PublicAccount } from './api'

/**
 * A custom avatar item's page, at `/d/store/customavataritem/<id>`.
 *
 * That path is what the game puts in the clipboard for "Share" on a store item — "Check
 * out this item in RecRoom: https://<www>/d/store/customavataritem/<uuid>" — so it has to
 * be exactly this, and it's the one URL on this site whose shape isn't ours to choose.
 * The uuid is a `CustomAvatarItemId` on `api`'s `custom_avatar_item` table.
 *
 * Read through `api`'s bulk lookup (`POST /api/customAvatarItems/v1/bulk`), the same call
 * the game makes to draw a shelf of items, with a batch of one — there is no single-item
 * GET, and www reading the table itself would tie the site to a schema another worker
 * owns (the room and player pages go to `rooms` and `accounts` for the same reason). That
 * route wants a token, so a signed-out visitor is asked to sign in and brought back here
 * afterwards (the `?next=` on the login link). Unpublished items miss for everyone but
 * their creator, so a draft's link says "no item here" to anyone else, which is what the
 * store says too.
 *
 * Its own file for the reason Stats.tsx and Moderation.tsx are: a whole surface rather
 * than one more section of App.tsx. The invention page (`/d/store/invention/<id>`, the
 * other store share link) lives here too, at the bottom.
 */

/** The `/d/store/customavataritem/<uuid>` path, or null for any other path. */
export function customAvatarItemIdFromPath(path: string): string | null {
	// Case-insensitive on the fixed segments: the game writes them lower-case, but a link
	// retyped by hand shouldn't 404 on `CustomAvatarItem`. The id is normalised to lower
	// case to match how the table stores it.
	const match =
		/^\/d\/store\/customavataritem\/([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})\/?$/i.exec(path)
	return match ? match[1]!.toLowerCase() : null
}

/**
 * The item, or null when the lookup came back without it: unknown, or unpublished and not
 * the caller's. The bulk route answers a bare array of the ids that matched, in request
 * order, and a miss is silence rather than an error.
 */
async function fetchCustomAvatarItem(itemId: string): Promise<CustomAvatarItem | null> {
	const items = await call<CustomAvatarItem[]>(`${where().api}/api/customAvatarItems/v1/bulk`, {
		form: { customAvatarItemIds: itemId },
		authed: true,
	})
	if (!Array.isArray(items)) return null
	return items.find((i) => i.CustomAvatarItemId?.toLowerCase() === itemId) ?? null
}

/**
 * The image that stands for the item. A player-made shirt has a thumbnail of its own under
 * `ThumbnailImageFilename`; a first-party item has none and is drawn from its saves, each of
 * which carries the store thumbnail for one body type — the first is as good as any here.
 * Both are keys on the `img` worker. Null when there's nothing to show, which shouldn't
 * happen for a served item but must not break the page when it does.
 */
function thumbnailKey(item: CustomAvatarItem): string | null {
	if (item.ThumbnailImageFilename) return item.ThumbnailImageFilename
	const save = item.CurrentSaves?.find((s) => s.ThumbnailFileName)
	return save?.ThumbnailFileName ?? null
}

/**
 * The `OutfitType` slot's name — `RecRoom.Avatars.OutfitType`, banded by body region (see
 * the enum note in api's custom-avatar-items-db.ts). Only the members seen on this table
 * are named; anything else is shown by number rather than guessed at.
 */
const OUTFIT_TYPE_LABEL: Record<number, string> = {
	0: 'Hat',
	2: 'Hair',
	3: 'Ears',
	10: 'Eyes',
	20: 'Beard',
	100: 'Shoulders',
	101: 'Shirt',
	102: 'Waist',
	103: 'Neck',
	104: 'Team jersey',
	105: 'Custom shirt',
	200: 'Wrist',
	203: 'Team wrist',
	300: 'Legs',
	301: 'Feet',
	500: 'Roomie hat',
	501: 'Roomie waist',
	502: 'Roomie eyes',
}

function outfitTypeLabel(type: number): string {
	return OUTFIT_TYPE_LABEL[type] ?? `Slot ${type}`
}

function formatDate(iso: string): string {
	const date = new Date(iso)
	return Number.isNaN(date.getTime()) ? iso : date.toLocaleDateString()
}

export function ItemPage({
	itemId,
	signedIn,
	navigate,
}: {
	itemId: string
	/**
	 * undefined while the stored token is still being checked, null when signed out — the
	 * lookup can't be made without a session, so the page waits on this rather than on
	 * the config alone.
	 */
	signedIn: boolean | undefined
	navigate: (to: string) => void
}) {
	// undefined = not fetched yet; null = nothing served for this id.
	const [item, setItem] = useState<CustomAvatarItem | null | undefined>(undefined)
	const [creator, setCreator] = useState<PublicAccount | null>(null)
	const [error, setError] = useState('')
	const [deleted, setDeleted] = useState<string | null>(null)

	useEffect(() => {
		setDeleted(null)
		setItem(undefined)
		setCreator(null)
		setError('')
		if (!signedIn) return
		void fetchCustomAvatarItem(itemId)
			.then((found) => {
				setItem(found)
				if (found)
					void usernamesFor([found.CreatorAccountId]).then((names) =>
						setCreator(names.get(found.CreatorAccountId) ?? null)
					)
			})
			.catch((e) => setError(e instanceof Error ? e.message : String(e)))
	}, [itemId, signedIn])

	const here = `/d/store/customavataritem/${itemId}`

	if (signedIn === null || signedIn === false) {
		return (
			<main className="shell wide">
				<section className="card">
					<h1>Sign in to see this item</h1>
					<p className="muted">
						Items in the store are shown to signed-in players. Sign in and you&apos;ll be brought
						straight back here.
					</p>
					<p>
						<a
							className="cta"
							href={`/login?next=${encodeURIComponent(here)}`}
							onClick={(e) => {
								e.preventDefault()
								navigate(`/login?next=${encodeURIComponent(here)}`)
							}}
						>
							Sign in
						</a>
					</p>
				</section>
			</main>
		)
	}

	if (deleted !== null) {
		return (
			<main className="shell wide">
				<p className="ok">{deleted} was deleted.</p>
			</main>
		)
	}
	if (error) {
		return (
			<main className="shell wide">
				<p className="error">{error}</p>
			</main>
		)
	}
	if (item === undefined) {
		return (
			<main className="shell wide">
				<p className="muted">Loading…</p>
			</main>
		)
	}
	if (item === null) {
		return (
			<main className="shell wide">
				<p className="muted">
					There&apos;s no item here — it hasn&apos;t been published, or it doesn&apos;t exist.
				</p>
			</main>
		)
	}

	const thumb = thumbnailKey(item)
	// A first-party item is built as Unity assetbundles rather than painted on a base
	// shirt; that, not the creator id, is what tells the two kinds apart on the record.
	const firstParty = item.CurrentSaves?.length > 0 && !item.DesignFilename
	const published = item.Accessibility !== 0

	return (
		<main className="shell wide">
			<section className="card room-hero">
				{thumb ? (
					<img
						className="room-hero-img item-hero-img"
						src={`${where().img}/${thumb}?width=512`}
						alt=""
					/>
				) : (
					<div className="room-hero-img item-hero-img" />
				)}
				<div className="room-hero-body">
					<div className="room-head">
						<h1 className="room-hero-name">{item.Name}</h1>
						<span className={`badge ${published ? 'live' : ''}`}>
							{published ? 'Published' : 'Unpublished'}
						</span>
					</div>
					{creator && (
						<p className="room-hero-by">
							by{' '}
							<a
								href={`/user/${encodeURIComponent(creator.username)}`}
								onClick={(e) => {
									e.preventDefault()
									navigate(`/user/${encodeURIComponent(creator.username)}`)
								}}
							>
								{creator.displayName || creator.username}
							</a>
						</p>
					)}
					{item.Description ? (
						<p className="muted room-hero-desc">{item.Description}</p>
					) : (
						<p className="muted room-hero-desc">No description.</p>
					)}
					<p className="room-stats">
						{item.Price > 0 ? `${item.Price.toLocaleString()} tokens` : 'Free'}
						{item.IsFeatured ? ' · Featured' : ''}
						{item.IsRecRoomApproved ? ' · Approved' : ''}
					</p>
				</div>
			</section>

			<section className="card">
				<h2>About this item</h2>
				<dl className="facts">
					<dt>Price</dt>
					<dd>{item.Price > 0 ? `${item.Price.toLocaleString()} tokens` : 'Free'}</dd>
					<dt>Type</dt>
					<dd>
						{outfitTypeLabel(item.OutfitType)}
						{firstParty ? ' · official item' : ''}
					</dd>
					{item.BaseAvatarItemColor && (
						<>
							<dt>Base colour</dt>
							<dd>
								<span className="swatch" style={{ background: item.BaseAvatarItemColor }} />{' '}
								{item.BaseAvatarItemColor}
							</dd>
						</>
					)}
					<dt>Tags</dt>
					<dd>{item.Tags?.length ? item.Tags.map((t) => `#${t.Value}`).join(' ') : 'None'}</dd>
					<dt>Created</dt>
					<dd>{formatDate(item.CreatedAt)}</dd>
					<dt>Updated</dt>
					<dd>{formatDate(item.ModifiedAt)}</dd>
					<dt>Item id</dt>
					<dd>
						<code>{item.CustomAvatarItemId}</code>
					</dd>
				</dl>
			</section>

			{/* Staff only, and cosmetic: `api` checks the token's role on the delete itself.
			    Not offered on a first-party (Coach) item, which `api` refuses to delete. */}
			{isAdmin() && item.CreatorAccountId !== COACH_ACCOUNT_ID && (
				<StaffDelete
					noun="item"
					name={item.Name}
					consequence="This deletes the item for everyone, including its creator, and takes it out of the store. Players who bought it lose it. It can't be undone."
					onDelete={() => deleteCustomAvatarItem(item.CustomAvatarItemId)}
					onDeleted={() => setDeleted(item.Name)}
				/>
			)}
		</main>
	)
}

/**
 * Delete a custom avatar item through `api`'s `DELETE /api/customAvatarItems/v1/:id` —
 * creator-only, except that staff may take down anyone's (audit-logged there).
 */
async function deleteCustomAvatarItem(itemId: string): Promise<void> {
	await call(`${where().api}/api/customAvatarItems/v1/${itemId}`, {
		method: 'DELETE',
		authed: true,
	})
}

/** The `/d/store/invention/<id>` path's numeric invention id, or null for any other path. */
export function inventionIdFromPath(path: string): number | null {
	const match = /^\/d\/store\/invention\/(\d+)\/?$/i.exec(path)
	return match ? Number(match[1]) : null
}

/**
 * The invention, or null when there's no PUBLISHED invention with that id.
 *
 * Read through `api`'s `GET /api/inventions/v2/batch?id=<id>` WITHOUT the session token,
 * deliberately: auth there only widens the answer to the caller's own unpublished
 * inventions, and this page is a public link, so it shows what anyone could see. Not
 * `GET /api/inventions/v1`, which serves an unpublished invention to anyone.
 */
async function fetchPublishedInvention(inventionId: number): Promise<SavedInvention | null> {
	const found = await call<SavedInvention[]>(
		`${where().api}/api/inventions/v2/batch?id=${inventionId}`
	)
	if (!Array.isArray(found)) return null
	// The route already drops unpublished inventions for an anonymous caller; checked again
	// so this page can't show one if that ever changes.
	return found.find((i) => i.InventionId === inventionId && i.IsPublished) ?? null
}

/**
 * A published invention's page, at `/d/store/invention/<id>` — the store share link's
 * shape, like the custom avatar item page above. Public: no sign-in needed.
 */
export function InventionPage({
	inventionId,
	ready,
	navigate,
}: {
	inventionId: number
	/** Whether `/api/config` has landed — `where()` has no hostnames before it. */
	ready: boolean
	navigate: (to: string) => void
}) {
	// undefined = not fetched yet; null = no published invention with this id.
	const [invention, setInvention] = useState<SavedInvention | null | undefined>(undefined)
	const [creator, setCreator] = useState<PublicAccount | null>(null)
	const [error, setError] = useState('')
	const [deleted, setDeleted] = useState<string | null>(null)

	useEffect(() => {
		setDeleted(null)
		setInvention(undefined)
		setCreator(null)
		setError('')
		if (!ready) return
		void fetchPublishedInvention(inventionId)
			.then((found) => {
				setInvention(found)
				if (found)
					void usernamesFor([found.CreatorPlayerId]).then((names) =>
						setCreator(names.get(found.CreatorPlayerId) ?? null)
					)
			})
			.catch((e) => setError(e instanceof Error ? e.message : String(e)))
	}, [inventionId, ready])

	if (error) {
		return (
			<main className="shell wide">
				<p className="error">{error}</p>
			</main>
		)
	}
	if (deleted !== null) {
		return (
			<main className="shell wide">
				<p className="ok">{deleted} was deleted.</p>
			</main>
		)
	}
	if (invention === undefined) {
		return (
			<main className="shell wide">
				<p className="muted">Loading…</p>
			</main>
		)
	}
	if (invention === null) {
		return (
			<main className="shell wide">
				<p className="muted">
					There&apos;s no invention here — it hasn&apos;t been published, or it doesn&apos;t exist.
				</p>
			</main>
		)
	}

	const price = invention.Price > 0 ? `${invention.Price.toLocaleString()} tokens` : 'Free'

	return (
		<main className="shell wide">
			<section className="card room-hero">
				{invention.ImageName ? (
					<img
						className="room-hero-img"
						src={`${where().img}/${invention.ImageName}?width=512`}
						alt=""
					/>
				) : (
					<div className="room-hero-img" />
				)}
				<div className="room-hero-body">
					<div className="room-head">
						<h1 className="room-hero-name">{invention.Name}</h1>
					</div>
					{creator && (
						<p className="room-hero-by">
							by{' '}
							<a
								href={`/user/${encodeURIComponent(creator.username)}`}
								onClick={(e) => {
									e.preventDefault()
									navigate(`/user/${encodeURIComponent(creator.username)}`)
								}}
							>
								{creator.displayName || creator.username}
							</a>
						</p>
					)}
					<p className="muted room-hero-desc">{invention.Description || 'No description.'}</p>
					<p className="room-stats">
						{price}
						{invention.IsFeatured ? ' · Featured' : ''}
						{invention.IsCertifiedInvention ? ' · Certified' : ''}
					</p>
				</div>
			</section>

			<section className="card">
				<h2>About this invention</h2>
				<dl className="facts">
					<dt>Price</dt>
					<dd>{price}</dd>
					<dt>Downloads</dt>
					<dd>{invention.NumDownloads.toLocaleString()}</dd>
					<dt>Cheers</dt>
					<dd>{invention.CheerCount.toLocaleString()}</dd>
					<dt>Tags</dt>
					<dd>
						{invention.Tags?.length ? invention.Tags.map((t) => `#${t.Tag}`).join(' ') : 'None'}
					</dd>
					<dt>Published</dt>
					<dd>{formatDate(invention.FirstPublishedAt ?? invention.CreatedAt)}</dd>
					<dt>Updated</dt>
					<dd>{formatDate(invention.ModifiedAt)}</dd>
					<dt>Invention id</dt>
					<dd>
						<code>{invention.InventionId}</code>
					</dd>
				</dl>
			</section>

			{/* Staff only, and cosmetic: `api` checks the token's role on the delete itself. */}
			{isAdmin() && (
				<StaffDelete
					noun="invention"
					name={invention.Name}
					consequence="This deletes the invention for everyone, including its creator, and takes it out of the store. Players who already bought it lose it from their lists. It can't be undone."
					onDelete={() => deleteInvention(invention.InventionId)}
					onDeleted={() => setDeleted(invention.Name)}
				/>
			)}
		</main>
	)
}

/**
 * Delete an invention through `api`'s own `POST /api/inventions/v2/delete` — creator-only,
 * except that staff may take down anyone's (audit-logged there). The route refuses in-band,
 * `Success: false` with a message, so that's read here rather than the status.
 */
async function deleteInvention(inventionId: number): Promise<void> {
	const result = await call<{ Success?: boolean; Error?: string | null }>(
		`${where().api}/api/inventions/v2/delete`,
		{ json: { InventionId: inventionId }, authed: true }
	)
	if (result.Success !== true) throw new Error(result.Error || 'Couldn’t delete the invention.')
}

/**
 * The staff delete card at the foot of a public page (an invention, a photo): a button, then
 * a confirm step that says what deleting does. The same two steps as a room's takedown.
 */
export function StaffDelete({
	noun,
	name,
	consequence,
	onDelete,
	onDeleted,
}: {
	/** What's being deleted, lowercase: "invention", "photo". */
	noun: string
	/** Its name, for the confirm heading; empty for something without one. */
	name: string
	/** What deleting does, shown on the confirm step. */
	consequence: string
	onDelete: () => Promise<void>
	onDeleted: () => void
}) {
	const [confirming, setConfirming] = useState(false)
	const { pending, error, run } = useAction()

	if (!confirming) {
		return (
			<section className="card">
				<h2>Delete {noun}</h2>
				<p className="muted">Staff only.</p>
				<button type="submit" onClick={() => setConfirming(true)}>
					Delete {noun}
				</button>
			</section>
		)
	}

	return (
		<section className="card mod-dialog">
			<h2>{name ? `Delete ${name}?` : `Delete this ${noun}?`}</h2>
			<form
				className="takedown-confirm"
				onSubmit={(e) => {
					e.preventDefault()
					void run(async () => {
						await onDelete()
						onDeleted()
						return ''
					})
				}}
			>
				<p className="muted">{consequence}</p>
				{error && <p className="error">{error}</p>}
				<div className="mod-filter-actions">
					<button type="submit" disabled={pending}>
						{pending ? 'Deleting…' : `Delete ${noun}`}
					</button>
					<button
						type="button"
						className="linkish"
						onClick={() => setConfirming(false)}
						disabled={pending}
					>
						Cancel
					</button>
				</div>
			</form>
		</section>
	)
}
