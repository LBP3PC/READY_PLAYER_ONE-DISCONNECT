SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;
SELECT COUNT(*) AS total FROM account;
SELECT account_id,
       json_extract(data,'$.username') AS username,
       json_extract(data,'$.displayName') AS displayName,
       json_extract(data,'$.isDeveloper') AS dev,
       json_extract(data,'$.isModerator') AS mod,
       json_extract(data,'$.isInfluencer') AS inf,
       json_extract(data,'$.isJunior') AS junior,
       json_extract(data,'$.hasPlus') AS plus,
       json_extract(data,'$.hasScreenshare') AS screenshare,
       json_extract(data,'$.banned') AS banned
FROM account ORDER BY account_id LIMIT 60;
SELECT account_id, data FROM account WHERE account_id IN (0,1);
