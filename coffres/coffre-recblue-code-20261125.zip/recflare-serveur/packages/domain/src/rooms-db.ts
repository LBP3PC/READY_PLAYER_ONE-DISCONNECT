/**
 * Room storage on the shared `recflare` D1 database. Each room is a single JSON
 * blob in the `data` column; queryable fields (RoomId, Name, CreatorAccountId,
 * IsDorm) are SQLite generated (virtual) columns extracted from that JSON and
 * indexed. This keeps the room shape flexible while still allowing fast lookups
 * by id/name/creator — the same JSON-blob pattern `accounts-db` uses.
 *
 * `ROOM_SCHEMA_DDL` mirrors the head schema after all migrations (`0001_init.sql`
 * created the table as `rooms`; `0005_rename_room.sql` renamed it to `room`); the
 * room data is seeded from `apps/rooms/static/ImportRooms.json` by
 * `migrations/0002_import_rooms.sql`. Tests apply `ROOM_SCHEMA_DDL` then seed the
 * imported rooms directly.
 *
 * This module is the single source of truth for the helpers: the `rooms` worker
 * (which owns the schema/migrations) uses the read/write set; the `match` worker
 * uses the room lookups plus the dorm helpers; the `api` worker binds the same
 * database read-only and uses `getRoomById`. Each imports the subset it needs.
 */

import { escapeLike, prefixUpperBound } from './accounts-db'
import { chunkForBinds } from './d1-binds'
import { Accessibility, Role } from './enums'
import { getShowcasedRoomIds } from './lists-db'
import { readPlayerSettings } from './player-settings-kv'
import { activeBoostsSql, ROOM_BOOST_SCHEMA_DDL } from './room-boosts-db'
import { countPlayersByRoom } from './presence-db'
import { resyncInstanceCapacity } from './room-instance-db'
import { isStudioBundleFilename } from './studio-unity-assets'
import { bakedUnityAssets, listUnityAssetBuilds } from './unity-assets-db'

import type { UnityAssetBuild } from './unity-assets-db'

/** Schema DDL (mirror of the head migration schema, sans the seed INSERT). */
export const ROOM_SCHEMA_DDL: string[] = [
	`CREATE TABLE IF NOT EXISTS room (
		data TEXT NOT NULL,
		room_id INTEGER GENERATED ALWAYS AS (json_extract(data, '$.RoomId')) VIRTUAL,
		name TEXT GENERATED ALWAYS AS (json_extract(data, '$.Name')) VIRTUAL,
		name_lower TEXT GENERATED ALWAYS AS (lower(json_extract(data, '$.Name'))) VIRTUAL,
		creator_account_id INTEGER GENERATED ALWAYS AS (json_extract(data, '$.CreatorAccountId')) VIRTUAL,
		is_dorm INTEGER GENERATED ALWAYS AS (json_extract(data, '$.IsDorm')) VIRTUAL,
		-- Lifetime visit counter (migrations/0011_room_visits.sql, which appends it here):
		-- bumped once per successful matchmake into the room by {@link recordRoomVisit},
		-- and served as the room's \`Stats.VisitCount\`. A real column rather than a field
		-- in the blob so a visit is one atomic UPDATE that can't lose a concurrent
		-- read-modify-write of the whole room.
		visits INTEGER NOT NULL DEFAULT 0,
		-- Cheer and favorite counters (migrations/0031_room_engagement_counters.sql, which
		-- appends them here): how many players currently have \`interaction.cheered\` /
		-- \`favorited\` set on the room, served as \`Stats.CheerCount\`/\`FavoriteCount\`.
		-- Maintained by the toggles ({@link toggleCheer} and friends) in the same batch as the
		-- per-player row, as a \`cheers = cheers ± 1\` UPDATE like \`visits\`. They used to be
		-- aggregated from \`interaction\` on every read, and the feeds — which rank every
		-- listable room — aggregated the WHOLE table per call; see parseRow.
		cheers INTEGER NOT NULL DEFAULT 0,
		favorites INTEGER NOT NULL DEFAULT 0,
		-- The two flags every public feed filters on, alongside \`is_dorm\`
		-- (migrations/0014_room_listable.sql, which appends them here). Generated like the
		-- rest so the blob stays the only copy; they exist to be INDEXED — see
		-- {@link LISTABLE_WHERE}.
		accessibility INTEGER GENERATED ALWAYS AS (json_extract(data, '$.Accessibility')) VIRTUAL,
		exclude_from_lists INTEGER GENERATED ALWAYS AS (json_extract(data, '$.ExcludeFromLists')) VIRTUAL,
		-- The flag SEARCH filters on (migrations/0027_room_searchable.sql) — see
		-- {@link SEARCHABLE_WHERE}.
		exclude_from_search INTEGER GENERATED ALWAYS AS (json_extract(data, '$.ExcludeFromSearch')) VIRTUAL
	)`,
	`CREATE UNIQUE INDEX IF NOT EXISTS idx_rooms_room_id ON room (room_id)`,
	`CREATE INDEX IF NOT EXISTS idx_rooms_name_lower ON room (name_lower)`,
	`CREATE INDEX IF NOT EXISTS idx_rooms_creator ON room (creator_account_id)`,
	// PARTIAL index over the public, non-dorm rooms — the only rooms any feed can serve,
	// and a small minority of the table (most rooms are dorms, one per account). Scanning
	// it visits those rooms alone instead of every room in the database; see
	// {@link LISTABLE_WHERE} for why the feeds select on it.
	//
	// Indexed on `room_id` because a partial index needs some column to key on and the
	// feeds all order by it eventually; the WHERE clause is the point, not the key.
	`CREATE INDEX IF NOT EXISTS idx_room_public ON room (room_id)
	 WHERE is_dorm IS NOT 1 AND accessibility = 1`,
	// The searchable rooms by lowercased name (migrations/0032_room_search_name.sql) — what
	// {@link searchRoomsByName} seeks. PARTIAL over exactly {@link SEARCHABLE_WHERE}, so the
	// walk never steps over a dorm or a private room: the rows it reads are the rows it
	// serves. `idx_rooms_name_lower` can't do that — it holds every dorm, and a prefix seek
	// on it checks each private room it passes against the blob.
	`CREATE INDEX IF NOT EXISTS idx_room_search_name ON room (name_lower)
	 WHERE is_dorm IS NOT 1 AND accessibility = 1 AND exclude_from_search IS NOT 1`,
	// A room's tags, one row per tag (migrations/0013_room_tag.sql). Modelled on the
	// `api` worker's `event_tag`, and the table is AUTHORITATIVE: `serializeRoom` strips
	// `Tags` from the blob and the reads re-attach it, the same arrangement `subroom` and
	// `subroom_save` already use, so the two can't drift.
	//
	// `tag` is stored lowercased and is the lookup key, which is what lets a tag-filtered
	// feed (a discovery category row, a `#tag` search) select in SQL instead of parsing
	// every room blob to ask. `type` is the client's tag-category int — 0 user, 2 the
	// auto-derived ones like `rro` — echoed back as stored.
	//
	// `is_primary_genre` (migrations/0015_room_tag_primary_genre.sql) flags the ONE tag
	// that is the room's genre, which the 2025 client sets with `primaryGenreTag=` and
	// draws differently from the rest. It is orthogonal to `type`: the flagged tag is
	// still an ordinary Type 0 user tag, and a room carries other tags alongside it.
	`CREATE TABLE IF NOT EXISTS room_tag (
		room_id INTEGER NOT NULL,
		tag TEXT NOT NULL,
		type INTEGER NOT NULL DEFAULT 0,
		is_primary_genre INTEGER NOT NULL DEFAULT 0,
		PRIMARY KEY (room_id, tag)
	)`,
	`CREATE INDEX IF NOT EXISTS idx_room_tag_tag ON room_tag (tag)`,
	// A room's `Roles`, one row per entry (migrations/0029_room_role.sql, rebuilt with the
	// whole entry by 0030_room_role_entry.sql). Unlike `room_tag` this is a DERIVED copy: the
	// blob keeps `Roles` and stays authoritative, and every write that changes them batches
	// {@link roomRoleWrites} alongside. It exists so "which rooms name this account" (and at
	// what tier) is an index lookup instead of a `json_each` over every room in the table.
	// Columns mirror {@link roomRoles}, defaults included.
	`CREATE TABLE IF NOT EXISTS room_role (
		account_id INTEGER NOT NULL,
		room_id INTEGER NOT NULL,
		role INTEGER NOT NULL DEFAULT 0,
		invited_role INTEGER NOT NULL DEFAULT 0,
		last_changed_by_account_id INTEGER,
		PRIMARY KEY (account_id, room_id)
	) WITHOUT ROWID`,
	`CREATE INDEX IF NOT EXISTS idx_room_role_room ON room_role (room_id)`,
	// Per-player interaction state with a room (cheered/favorited + last visit).
	// One row per (player, room); cheer/favorite are toggled in place.
	`CREATE TABLE IF NOT EXISTS interaction (
		player_id INTEGER NOT NULL,
		room_id INTEGER NOT NULL,
		cheered INTEGER NOT NULL DEFAULT 0,
		favorited INTEGER NOT NULL DEFAULT 0,
		last_visited_at TEXT,
		PRIMARY KEY (player_id, room_id)
	)`,
	// Per-ROOM access (migrations/0021_interaction_room_index.sql): the primary key
	// serves the per-player reads; this serves deleting a room's rows ({@link deleteRoom})
	// and the one-off backfill of `room.cheers`/`favorites` (migration 0031). It was
	// added for a per-read cheer/favorite aggregate that no longer exists — the counters
	// are columns on `room` now — and covers the two flags from that era.
	`CREATE INDEX IF NOT EXISTS idx_interaction_room ON interaction (room_id, cheered, favorited)`,
	// Per-room player bans (migrations/0010_room_ban.sql). One row per (room, player),
	// so re-banning someone already banned updates their row rather than appending.
	// `ban_mask` is the client's `banMask` field kept verbatim — its meaning isn't known
	// yet (the client sends 0), so nothing interprets it.
	//
	// Deliberately NOT in the room's `data` blob: that blob is served to the client
	// verbatim as the room, and a ban list is not something every reader of a room
	// should receive.
	`CREATE TABLE IF NOT EXISTS room_ban (
		room_id INTEGER NOT NULL,
		banned_player_id INTEGER NOT NULL,
		ban_mask INTEGER NOT NULL DEFAULT 0,
		banned_by_account_id INTEGER NOT NULL,
		created_at TEXT NOT NULL,
		-- migrations/0018_room_ban_reason_expiry.sql. NULL expires_at is a permanent ban.
		reason TEXT,
		expires_at TEXT,
		PRIMARY KEY (room_id, banned_player_id)
	)`,
	`CREATE INDEX IF NOT EXISTS idx_room_ban_player ON room_ban (banned_player_id)`,
	// Room bans that have ENDED (migrations/0019_room_ban_history.sql). `room_ban` above holds
	// only the ban in force — one row per (room, player), deleted on unban and overwritten on
	// re-ban — so without this a lifted or lapsed ban leaves no trace. A row is written here
	// at the moment a ban stops being the live one: when it is lifted (`status` 2, Lifted,
	// `ended_at` the lift and `unbanned_by_account_id` who lifted it) or when a lapsed ban is
	// replaced by a new one (`status` 1, Elapsed, `ended_at` its expiry). Append-only.
	`CREATE TABLE IF NOT EXISTS room_ban_history (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		room_id INTEGER NOT NULL,
		banned_player_id INTEGER NOT NULL,
		ban_mask INTEGER NOT NULL DEFAULT 0,
		banned_by_account_id INTEGER NOT NULL,
		created_at TEXT NOT NULL,
		reason TEXT,
		expires_at TEXT,
		status INTEGER NOT NULL,
		ended_at TEXT,
		unbanned_by_account_id INTEGER
	)`,
	`CREATE INDEX IF NOT EXISTS idx_room_ban_history_player
		ON room_ban_history (room_id, banned_player_id)`,
	// Per-room leaderboard definitions (migrations/0016_room_leaderboard.sql). One row per
	// (room, leaderboard): `leaderboard_id` is the client's slot number — small ordinals
	// (1, 2, 3…), unique only within the room — so the pair is the key, and re-posting a
	// slot reconfigures it in place rather than appending.
	//
	// Deliberately NOT in the room's `data` blob, same reasoning as `room_ban`: the blob is
	// served verbatim as the room and the client doesn't read leaderboards off it.
	`CREATE TABLE IF NOT EXISTS room_leaderboard (
		room_id INTEGER NOT NULL,
		leaderboard_id INTEGER NOT NULL,
		leaderboard_title TEXT NOT NULL,
		stat_format INTEGER NOT NULL DEFAULT 0,
		sort_ascending INTEGER NOT NULL DEFAULT 0,
		PRIMARY KEY (room_id, leaderboard_id)
	)`,
	// Per-room, per-player variable data (migrations/0020_playerdata.sql) — what the client
	// saves through `PUT /rooms/:id/playerdata/me` and reads back from the GET. One row per
	// (room, player); `data` is the posted blob verbatim (a base64 string the server never
	// decodes), and a re-save overwrites it, so only each player's latest is kept.
	`CREATE TABLE IF NOT EXISTS playerdata (
		room_id INTEGER NOT NULL,
		player_id INTEGER NOT NULL,
		data TEXT NOT NULL,
		PRIMARY KEY (room_id, player_id)
	)`,
	// Room boosts (room-boosts-db.ts): every room read joins in the active count, so the table
	// belongs with the room schema wherever that is built.
	...ROOM_BOOST_SCHEMA_DDL,
]

/**
 * Subroom schema DDL (mirror of migrations/0007_subrooms.sql). Subrooms are
 * first-class entities with their own globally-unique, autoincrementing id — the
 * original game mints `SubRoomId` from a single sequence, not per-room — so they
 * live in their own table rather than inside the room JSON blob. `data` holds the
 * rest of the subroom's client shape; `sub_room_id`/`room_id` are the authoritative
 * columns (re-injected over `data` on read). Rooms re-embed their `SubRooms` array
 * on read (see {@link getRoomById}); nothing persists SubRooms back into the room blob.
 */
export const SUBROOM_SCHEMA_DDL: string[] = [
	`CREATE TABLE IF NOT EXISTS subroom (
		sub_room_id INTEGER PRIMARY KEY AUTOINCREMENT,
		room_id INTEGER NOT NULL,
		data TEXT NOT NULL,
		current_save_id INTEGER,
		staged_save_id INTEGER
	)`,
	`CREATE INDEX IF NOT EXISTS idx_subroom_room ON subroom (room_id)`,
	// Room saves (migrations/0008_subroom_saves.sql). A save is its own entity with a
	// globally-unique, autoincrementing `SubRoomDataSaveId` — the same reason subrooms got
	// their own table in 0007. It HAS to be global because a subroom points at saves by
	// bare id: `current_save_id` is the live/published save the loader downloads,
	// `staged_save_id` the creator's unpublished one. Per-subroom numbering would make
	// every subroom's first save id 1 and those pointers ambiguous.
	//
	// `data` holds the save's client shape minus its two id fields; the columns are
	// authoritative and are re-injected on read, exactly how `subroom` treats its own ids.
	// A subroom's `CurrentSave` is inlined from `current_save_id` on every read and is
	// never stored in the subroom blob.
	//
	// Part of this DDL rather than its own export: reading a subroom joins this table, so
	// applying one without the other yields a schema that can't serve a room.
	`CREATE TABLE IF NOT EXISTS subroom_save (
		sub_room_data_save_id INTEGER PRIMARY KEY AUTOINCREMENT,
		sub_room_id INTEGER NOT NULL,
		data TEXT NOT NULL
	)`,
	`CREATE INDEX IF NOT EXISTS idx_subroom_save_sub ON subroom_save (sub_room_id)`,
	// Per-subroom permission overrides (migrations/0009_subroom_permissions.sql). The room
	// owner's permission table for one subroom, keyed by (permission, role) — that pair is
	// what the client's PUT addresses, and re-sending it overwrites the stored row rather
	// than appending a second one.
	//
	// A row IS an override, which is why the client's `Override` flag is not a column: it's
	// the checkbox next to the permission, so clearing it deletes the row and the pair falls
	// back to its default. `value` is the client's string, stored verbatim.
	//
	// Deliberately NOT in the subroom's `data` blob: that blob is served to the client
	// verbatim as part of the room, and these overrides are read on one path only
	// (`GET /photon_access_token`, where they overwrite the matching default entries).
	`CREATE TABLE IF NOT EXISTS subroom_permission (
		sub_room_id INTEGER NOT NULL,
		permission TEXT NOT NULL,
		role INTEGER NOT NULL,
		type INTEGER NOT NULL DEFAULT 0,
		value TEXT NOT NULL,
		PRIMARY KEY (sub_room_id, permission, role)
	)`,
	// Which inventions a room has in it (migrations/0023_room_invention.sql): one row per
	// (room, invention), re-derived on every room save from the `InventionUsage` each of the
	// room's subrooms last reported — see {@link syncRoomInventions}. The second index is
	// the reverse lookup, "which rooms use this invention" — what an invention's
	// `NumPlayersHaveUsedInRoom` is counted from.
	`CREATE TABLE IF NOT EXISTS room_invention (
		room_id INTEGER NOT NULL,
		invention_id INTEGER NOT NULL,
		PRIMARY KEY (room_id, invention_id)
	)`,
	`CREATE INDEX IF NOT EXISTS idx_room_invention_invention ON room_invention (invention_id)`,
]

/** A stored room — the parsed JSON blob (full client-facing room response). */
export type Room = Record<string, unknown>

/** A room role assignment (the client's RoomRole shape). */
export interface RoomRole {
	AccountId: number
	Role: number
	LastChangedByAccountId: number | null
	InvitedRole: number
}

/**
 * A room's `Roles`, always as whole {@link RoomRole} records. Roles live inside the room
 * blob, and the older rooms either have no `Roles` key at all or carry entries written
 * before `LastChangedByAccountId`/`InvitedRole` existed; every reader wants the complete
 * shape, so the missing keys are filled in here rather than at each call site. Returns
 * copies, so a caller that edits an entry must write the returned array back to the room.
 */
export function roomRoles(room: Room): RoomRole[] {
	const roles = Array.isArray(room.Roles) ? (room.Roles as Array<Partial<RoomRole>>) : []
	return roles.map((r) => ({
		AccountId: Number(r.AccountId ?? 0),
		Role: Number(r.Role ?? Role.None),
		LastChangedByAccountId: r.LastChangedByAccountId ?? null,
		InvitedRole: Number(r.InvitedRole ?? Role.None),
	}))
}

/**
 * Whether a `Roles` entry records a role the account actually HOLDS, as opposed to one it has
 * only been offered. An invite is an entry with `Role` {@link Role.None} and the offer on
 * `InvitedRole`; it stays that way until the player accepts ({@link answerRoomRoleInvite})
 * or declines (which drops the entry). Tolerates the raw blob shape — older rooms carry
 * entries without a `Role` key, which read as None, and a malformed entry is not a role.
 */
function holdsRole(entry: unknown): boolean {
	if (entry === null || typeof entry !== 'object') return false
	return Number((entry as Partial<RoomRole>).Role ?? Role.None) !== Role.None
}

/**
 * The room as SERVED, with pending invites dropped from its `Roles` — a shallow copy; the
 * room passed in is untouched, so a caller can keep writing from it. Entries are kept in the
 * blob's own shape (not normalised through {@link roomRoles}), so a room that had no
 * pending invite serializes exactly as before. A room with no `Roles` array is returned as
 * is.
 *
 * Apply this at the response boundary ONLY, never to a room that is about to be written
 * back. Rooms are stored as whole blobs and every writer rewrites the blob from the loaded
 * room, so dropping the pending entries any earlier would silently erase every open invite
 * on the room's next unrelated edit (a renamed room, a new load screen).
 */
export function withConfirmedRoles<T extends Room>(room: T): T {
	if (!Array.isArray(room.Roles)) return room
	return { ...room, Roles: room.Roles.filter(holdsRole) }
}

/**
 * The statements that bring `room_role` in line with a room's `Roles`: drop the room's rows,
 * then insert each entry whole, as {@link roomRoles} reads it. Every entry is stored,
 * pending invites (`Role` 0 with an `InvitedRole`) included. An account named twice keeps
 * its first entry, which is the one {@link roomRoles}' `find` callers see.
 *
 * Batch these WITH the write that changes the blob, so the copy can't drift from it. The
 * entries go in as one JSON array rather than binds per row, so no role list can hit D1's
 * bound-parameter cap.
 */
export function roomRoleWrites(db: D1Database, roomId: number, room: Room): D1PreparedStatement[] {
	// A malformed tier reads as NaN, which JSON writes as null and the NOT NULL column would
	// refuse — failing the room write it is batched with. Store it as None instead.
	const tier = (n: number) => (Number.isFinite(n) ? n : Role.None)
	const entries = roomRoles(room)
		.filter((r) => Number.isInteger(r.AccountId) && r.AccountId > 0)
		.map((r) => ({ ...r, Role: tier(r.Role), InvitedRole: tier(r.InvitedRole) }))
	const statements = [db.prepare('DELETE FROM room_role WHERE room_id = ?1').bind(roomId)]
	if (entries.length > 0) {
		statements.push(
			db
				.prepare(
					`INSERT OR IGNORE INTO room_role
					   (account_id, room_id, role, invited_role, last_changed_by_account_id)
					 SELECT json_extract(value, '$.AccountId'), ?1, json_extract(value, '$.Role'),
					        json_extract(value, '$.InvitedRole'), json_extract(value, '$.LastChangedByAccountId')
					 FROM json_each(?2)`
				)
				.bind(roomId, JSON.stringify(entries))
		)
	}
	return statements
}

/**
 * Room roles that confer owner-level management of a room: Creator (255) and
 * CoOwner (30). The reference gates its room-admin actions on this set. (Host and
 * Moderator are lower tiers and are deliberately excluded.)
 */
const MANAGE_ROLES: ReadonlySet<number> = new Set([Role.Creator, Role.CoOwner])

/**
 * Whether an account may manage a room — its creator, or the holder of a
 * Creator/CoOwner role on the room's `Roles`. This is the owner-or-co-owner gate
 * the reference applies to room-admin actions (editing room data, viewing a room's
 * live instances). Shared so the `rooms` and `match` workers apply the same check
 * rather than each re-deriving the role set.
 */
export function canManageRoom(room: Room, accountId: number): boolean {
	if (room.CreatorAccountId === accountId) return true
	return roomRoles(room).some((r) => r.AccountId === accountId && MANAGE_ROLES.has(r.Role))
}

/**
 * Whether an account may manage the room with this id — {@link canManageRoom} against a room
 * this reads for itself. Null when there is no such room, which a caller answers differently
 * (a 404) from a room somebody else runs (a 403).
 *
 * Reads the room BLOB only, with none of {@link getRoomById}'s hydration. Ownership lives in
 * `CreatorAccountId` and `Roles`, both of which are in the blob; the subrooms, tags and stats
 * that hydration attaches are three more tables a caller would otherwise have to have just to
 * ask who runs a room. That matters for the workers outside `rooms` that gate on room
 * ownership — `econ` minting a room currency does not know what a subroom is.
 */
export async function canManageRoomById(
	db: D1Database,
	roomId: number,
	accountId: number
): Promise<boolean | null> {
	const room = parseOne(
		await db
			.prepare(`SELECT ${ROOM_COLUMNS} FROM room WHERE room_id = ?1`)
			.bind(roomId)
			.first<RoomRow>()
	)
	if (!room) return null
	return canManageRoom(room, accountId)
}

/**
 * Account ids that co-own a room: its creator, and every `Roles` entry at Creator or
 * CoOwner. Null when the room does not exist. A pending invite is not a co-owner yet
 * (`Role` stays None until they accept), and Host / Moderator are not in this set —
 * the same ownership set as {@link canManageRoom}. Ordered by account id.
 *
 * Reads the blob only, like {@link canManageRoomById}.
 */
export async function getRoomCoOwnerIds(db: D1Database, roomId: number): Promise<number[] | null> {
	const room = parseOne(
		await db
			.prepare(`SELECT ${ROOM_COLUMNS} FROM room WHERE room_id = ?1`)
			.bind(roomId)
			.first<RoomRow>()
	)
	if (!room) return null
	const ids = new Set<number>()
	const creator = Number(room.CreatorAccountId)
	if (Number.isSafeInteger(creator) && creator > 0) ids.add(creator)
	for (const role of roomRoles(room)) {
		if (role.AccountId > 0 && MANAGE_ROLES.has(role.Role)) ids.add(role.AccountId)
	}
	return [...ids].sort((a, b) => a - b)
}

/**
 * Whether an account may MODERATE a room — its creator, or the holder of a role at
 * Moderator (20) or above. The wider gate that {@link canManageRoom} is the narrow one
 * of: a moderator polices who is in the room right now (kicking someone out of an
 * instance) without being trusted to change the room itself, while everyone who can
 * manage a room can obviously also police it, so CoOwner and Creator pass here too.
 *
 * Host (10) is deliberately below the line: it is the "runs this session" tier, which the
 * client hands out freely, and a kick is a moderation power rather than a hosting one.
 */
export function canModerateRoom(room: Room, accountId: number): boolean {
	if (room.CreatorAccountId === accountId) return true
	return roomRoles(room).some((r) => r.AccountId === accountId && r.Role >= Role.Moderator)
}

/**
 * Whether an account OWNS a room — its `CreatorAccountId`, or the holder of the Creator
 * (255) role. The narrowest of the three room gates: {@link canManageRoom} lets a CoOwner
 * through and {@link canModerateRoom} a Moderator, but handing out co-ownership is the
 * owner's alone, or a co-owner could quietly grow the set of people who can change the
 * room, an offer the invited player then accepts themselves.
 */
export function isRoomOwner(room: Room, accountId: number): boolean {
	if (room.CreatorAccountId === accountId) return true
	return roomRoles(room).some((r) => r.AccountId === accountId && r.Role === Role.Creator)
}

/** A player banned from a room (a `room_ban` row). */
export interface RoomBan {
	RoomId: number
	BannedPlayerId: number
	/** The client's `banMask`, stored verbatim — its meaning isn't known yet. */
	BanMask: number
	BannedByAccountId: number
	CreatedAt: string
	/** Free text from whoever issued the ban. Null when none was given. */
	Reason: string | null
	/** When the ban lapses (ISO-8601 UTC). Null is a permanent ban, lifted only by DELETE. */
	ExpiresAt: string | null
}

interface RoomBanRow {
	room_id: number
	banned_player_id: number
	ban_mask: number
	banned_by_account_id: number
	created_at: string
	reason: string | null
	expires_at: string | null
}

const toRoomBan = (row: RoomBanRow): RoomBan => ({
	RoomId: row.room_id,
	BannedPlayerId: row.banned_player_id,
	BanMask: row.ban_mask,
	BannedByAccountId: row.banned_by_account_id,
	CreatedAt: row.created_at,
	Reason: row.reason,
	ExpiresAt: row.expires_at,
})

/**
 * The SQL that keeps a ban row in force: permanent, or not yet lapsed. An expired row is not
 * deleted when it lapses — nothing runs at that moment — so EVERY read that asks "is this
 * player banned" has to apply this, or a 30-minute ban would last forever. the time is bound
 * rather than using SQLite's clock so it compares in the same ISO-8601 format the rows are
 * written in (`datetime('now')` has no `T` or `Z` and would sort wrongly against them).
 * `now` names the placeholder the caller binds the current time to.
 */
const banInForce = (now: string): string => `(expires_at IS NULL OR expires_at > ${now})`

/** Where a ban stands, as the client's `Status` enum numbers it. */
export const RoomBanStatus = {
	/** In force now. Only ever the `room_ban` row. */
	Active: 0,
	/** Ran out on its own. */
	Elapsed: 1,
	/** Ended early by someone unbanning the player. */
	Lifted: 2,
} as const

/**
 * One ban in a player's history, whatever state it is in. Timestamps are ISO-8601 as stored.
 * `EndedAt` is when the ban stopped counting — its expiry if it lapsed, the moment it was
 * lifted if it was lifted — and for an Active ban the expiry it is scheduled to reach, null
 * when it is permanent.
 */
export interface RoomBanRecord {
	Status: (typeof RoomBanStatus)[keyof typeof RoomBanStatus]
	UnbannedByAccountId: number | null
	EndedAt: string | null
	Reason: string | null
	AccountId: number
	BannedByAccountId: number
	StartedAt: string
}

interface RoomBanHistoryRow {
	banned_player_id: number
	banned_by_account_id: number
	created_at: string
	reason: string | null
	status: RoomBanRecord['Status']
	ended_at: string | null
	unbanned_by_account_id: number | null
}

/**
 * A player's ban history in one room: the ban in force, if any, and every ban that has ended,
 * newest first.
 *
 * A `room_ban` row that has LAPSED is not active — but nothing moves it into
 * `room_ban_history` until the player is banned or unbanned again, so it is reported here as
 * an Elapsed previous ban rather than dropped. Only the row still in force is `active`.
 */
export async function getRoomBanHistory(
	db: D1Database,
	roomId: number,
	playerId: number
): Promise<{ active: RoomBanRecord | null; previous: RoomBanRecord[] }> {
	const now = new Date().toISOString()
	const [current, ended] = await db.batch([
		db
			.prepare('SELECT * FROM room_ban WHERE room_id = ?1 AND banned_player_id = ?2')
			.bind(roomId, playerId),
		db
			.prepare(
				`SELECT * FROM room_ban_history WHERE room_id = ?1 AND banned_player_id = ?2
				 ORDER BY created_at DESC, id DESC`
			)
			.bind(roomId, playerId),
	])

	const previous = (ended.results as RoomBanHistoryRow[]).map((row): RoomBanRecord => ({
		Status: row.status,
		UnbannedByAccountId: row.unbanned_by_account_id,
		EndedAt: row.ended_at,
		Reason: row.reason,
		AccountId: row.banned_player_id,
		BannedByAccountId: row.banned_by_account_id,
		StartedAt: row.created_at,
	}))

	const row = (current.results as RoomBanRow[])[0]
	if (!row) return { active: null, previous }
	const inForce = row.expires_at === null || row.expires_at > now
	const record: RoomBanRecord = {
		Status: inForce ? RoomBanStatus.Active : RoomBanStatus.Elapsed,
		UnbannedByAccountId: null,
		EndedAt: row.expires_at,
		Reason: row.reason,
		AccountId: row.banned_player_id,
		BannedByAccountId: row.banned_by_account_id,
		StartedAt: row.created_at,
	}
	if (inForce) return { active: record, previous }
	// Newer than anything already filed, since filing it is what a later ban would do.
	return { active: null, previous: [record, ...previous] }
}

/** Options for {@link banPlayerFromRoom}. */
export interface RoomBanOptions {
	/** Shown to nobody yet; kept on the row. Empty is stored as null. */
	reason?: string | null
	/** Minutes until the ban lapses. Absent, null or 0 is permanent. */
	durationMinutes?: number | null
}

/**
 * Ban a player from a room, returning the stored ban. One row per (room, player):
 * re-banning someone already banned rewrites their row with the new mask, issuer, reason and
 * expiry rather than appending a second one, so the call is idempotent.
 *
 * A re-ban REPLACES the duration rather than extending it, and the clock restarts from now:
 * banning someone for 30 minutes who has 5 left leaves them with 30, and re-banning with no
 * duration makes the ban permanent. The latest ban issued is the one in force.
 *
 * History: if the row being overwritten had already LAPSED, that ban is over and is filed in
 * `room_ban_history` as Elapsed first. A ban still in force is AMENDED rather than ended — the
 * player has been banned continuously — so it is overwritten without leaving a history row.
 * Both statements run as one batch, so the old ban is never lost between them.
 */
export async function banPlayerFromRoom(
	db: D1Database,
	roomId: number,
	bannedPlayerId: number,
	banMask: number,
	bannedByAccountId: number,
	options: RoomBanOptions = {}
): Promise<RoomBan> {
	const now = new Date()
	const minutes = options.durationMinutes ?? 0
	const expiresAt = minutes > 0 ? new Date(now.getTime() + minutes * 60_000).toISOString() : null
	const reason = options.reason?.trim() || null

	const [, upserted] = await db.batch([
		db
			.prepare(
				`INSERT INTO room_ban_history
					 (room_id, banned_player_id, ban_mask, banned_by_account_id, created_at, reason,
					  expires_at, status, ended_at, unbanned_by_account_id)
				 SELECT room_id, banned_player_id, ban_mask, banned_by_account_id, created_at, reason,
					 expires_at, ?4, expires_at, NULL
				 FROM room_ban
				 WHERE room_id = ?1 AND banned_player_id = ?2 AND NOT ${banInForce('?3')}`
			)
			.bind(roomId, bannedPlayerId, now.toISOString(), RoomBanStatus.Elapsed),
		db
			.prepare(
				`INSERT INTO room_ban
					 (room_id, banned_player_id, ban_mask, banned_by_account_id, created_at, reason, expires_at)
				 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)
				 ON CONFLICT(room_id, banned_player_id) DO UPDATE SET
					 ban_mask = ?3, banned_by_account_id = ?4, created_at = ?5, reason = ?6, expires_at = ?7
				 RETURNING *`
			)
			.bind(
				roomId,
				bannedPlayerId,
				banMask,
				bannedByAccountId,
				now.toISOString(),
				reason,
				expiresAt
			),
	])
	// RETURNING always yields the upserted row.
	return toRoomBan((upserted.results as RoomBanRow[])[0])
}

/**
 * Lift a player's ban on a room, returning the ban that was removed — or null when
 * they weren't banned, which lets the caller tell a real unban from a no-op. A ban that has
 * already LAPSED counts as not banned; its stale row is deleted all the same.
 *
 * History: the removed ban is filed in `room_ban_history` in the same batch as the delete. A
 * ban still in force is Lifted, ended now, by `unbannedByAccountId`. A lapsed one is Elapsed,
 * ended at its expiry, by nobody — deleting the stale row is housekeeping, not a lift.
 */
export async function unbanPlayerFromRoom(
	db: D1Database,
	roomId: number,
	bannedPlayerId: number,
	unbannedByAccountId: number
): Promise<RoomBan | null> {
	const now = new Date().toISOString()
	const inForce = banInForce('?3')
	const [, deleted] = await db.batch([
		db
			.prepare(
				`INSERT INTO room_ban_history
					 (room_id, banned_player_id, ban_mask, banned_by_account_id, created_at, reason,
					  expires_at, status, ended_at, unbanned_by_account_id)
				 SELECT room_id, banned_player_id, ban_mask, banned_by_account_id, created_at, reason,
					 expires_at,
					 CASE WHEN ${inForce} THEN ?5 ELSE ?6 END,
					 CASE WHEN ${inForce} THEN ?3 ELSE expires_at END,
					 CASE WHEN ${inForce} THEN ?4 ELSE NULL END
				 FROM room_ban WHERE room_id = ?1 AND banned_player_id = ?2`
			)
			.bind(
				roomId,
				bannedPlayerId,
				now,
				unbannedByAccountId,
				RoomBanStatus.Lifted,
				RoomBanStatus.Elapsed
			),
		db
			.prepare('DELETE FROM room_ban WHERE room_id = ?1 AND banned_player_id = ?2 RETURNING *')
			.bind(roomId, bannedPlayerId),
	])
	const row = (deleted.results as RoomBanRow[])[0]
	if (!row) return null
	const ban = toRoomBan(row)
	return ban.ExpiresAt !== null && ban.ExpiresAt <= new Date().toISOString() ? null : ban
}

/** Everyone CURRENTLY banned from a room, most recently banned first. Lapsed bans are left out. */
export async function getRoomBans(db: D1Database, roomId: number): Promise<RoomBan[]> {
	const { results } = await db
		.prepare(
			`SELECT * FROM room_ban WHERE room_id = ?1 AND ${banInForce('?2')} ORDER BY created_at DESC`
		)
		.bind(roomId, new Date().toISOString())
		.all<RoomBanRow>()
	return results.map(toRoomBan)
}

/**
 * Whether a player is banned from a room RIGHT NOW. A timed ban that has lapsed is not a ban.
 * This is the check `match` refuses matchmakes on, so the expiry has to be applied here.
 */
export async function isPlayerBannedFromRoom(
	db: D1Database,
	roomId: number,
	playerId: number
): Promise<boolean> {
	const row = await db
		.prepare(
			`SELECT 1 AS hit FROM room_ban
			 WHERE room_id = ?1 AND banned_player_id = ?2 AND ${banInForce('?3')}`
		)
		.bind(roomId, playerId, new Date().toISOString())
		.first<{ hit: number }>()
	return row !== null
}

/** A room's leaderboard definition — one configured slot (`leaderboard_id` is per-room). */
export interface RoomLeaderboard {
	RoomId: number
	LeaderboardId: number
	LeaderboardTitle: string
	StatFormat: number
	SortAscending: boolean
}

interface RoomLeaderboardRow {
	room_id: number
	leaderboard_id: number
	leaderboard_title: string
	stat_format: number
	sort_ascending: number
}

const toRoomLeaderboard = (row: RoomLeaderboardRow): RoomLeaderboard => ({
	RoomId: row.room_id,
	LeaderboardId: row.leaderboard_id,
	LeaderboardTitle: row.leaderboard_title,
	StatFormat: row.stat_format,
	SortAscending: row.sort_ascending === 1,
})

/**
 * Create or reconfigure one of a room's leaderboard slots, returning the stored
 * definition. One row per (room, leaderboard): re-posting a slot rewrites its title,
 * format and direction rather than appending a second row, so the call is idempotent.
 */
export async function setRoomLeaderboard(
	db: D1Database,
	roomId: number,
	leaderboardId: number,
	leaderboardTitle: string,
	statFormat: number,
	sortAscending: boolean
): Promise<RoomLeaderboard> {
	const row = await db
		.prepare(
			`INSERT INTO room_leaderboard (room_id, leaderboard_id, leaderboard_title, stat_format, sort_ascending)
			 VALUES (?1, ?2, ?3, ?4, ?5)
			 ON CONFLICT(room_id, leaderboard_id) DO UPDATE SET
				 leaderboard_title = ?3, stat_format = ?4, sort_ascending = ?5
			 RETURNING *`
		)
		.bind(roomId, leaderboardId, leaderboardTitle, statFormat, sortAscending ? 1 : 0)
		.first<RoomLeaderboardRow>()
	// RETURNING always yields the upserted row.
	return toRoomLeaderboard(row!)
}

/**
 * Remove one of a room's leaderboard slots, returning the definition that was removed —
 * or null when the slot wasn't configured, which lets the caller tell a real delete
 * from a no-op.
 */
export async function deleteRoomLeaderboard(
	db: D1Database,
	roomId: number,
	leaderboardId: number
): Promise<RoomLeaderboard | null> {
	const row = await db
		.prepare('DELETE FROM room_leaderboard WHERE room_id = ?1 AND leaderboard_id = ?2 RETURNING *')
		.bind(roomId, leaderboardId)
		.first<RoomLeaderboardRow>()
	return row ? toRoomLeaderboard(row) : null
}

/**
 * A player's saved data for one room — the blob the client posted, verbatim. Null when
 * the player has never saved anything there.
 */
export async function getPlayerData(
	db: D1Database,
	roomId: number,
	playerId: number
): Promise<string | null> {
	const row = await db
		.prepare('SELECT data FROM playerdata WHERE room_id = ?1 AND player_id = ?2')
		.bind(roomId, playerId)
		.first<{ data: string }>()
	return row ? row.data : null
}

/**
 * Store a player's data for one room, returning what was stored. One row per (room,
 * player): a re-save overwrites the blob in place rather than keeping history, so the
 * call is idempotent.
 */
export async function setPlayerData(
	db: D1Database,
	roomId: number,
	playerId: number,
	data: string
): Promise<string> {
	const row = await db
		.prepare(
			`INSERT INTO playerdata (room_id, player_id, data) VALUES (?1, ?2, ?3)
			 ON CONFLICT(room_id, player_id) DO UPDATE SET data = ?3
			 RETURNING data`
		)
		.bind(roomId, playerId, data)
		.first<{ data: string }>()
	// RETURNING always yields the upserted row.
	return row!.data
}

/**
 * Clone an existing room into a new one owned by `accountId`. Copies the source
 * room's content (scene/subrooms/settings), assigning a fresh RoomId, the given
 * name, and the new owner. The clone keeps only the source's SYSTEM tags (`Type` 1,
 * `RoomTagType.auto` — `beta`, `limitsv2`): the client posts those to describe what the
 * scene needs to run, so a copy of the scene needs them too. Every other tag (the owner's
 * `Type` 0 tags, the `base` template tag, the server-derived `rro`) is dropped, so the
 * owner tags the clone from scratch. `IsRRO` is cleared so the client doesn't render a
 * virtual "RRO" tag on it, `IsDeveloperOwned`/`CloningAllowed` are cleared, its `Stats`
 * start at zero, and it starts PRIVATE rather than inheriting the source's visibility.
 * `IsDorm` carries over: the 2026 client makes custom dorms by cloning one. The player's
 * own dorm stays their OLDEST dorm (see {@link getDormRoom}), so a cloned one never
 * replaces it.
 * Returns the new room, or null when the source isn't in D1 or disallows cloning.
 */
export async function cloneRoom(
	db: D1Database,
	sourceRoomId: number,
	name: string,
	accountId: number
): Promise<Room | null> {
	const source = await getRoomById(db, sourceRoomId)
	if (!source || source.CloningAllowed === false) return null

	const row = await db
		.prepare('SELECT MAX(room_id) AS maxId FROM room')
		.first<{ maxId: number | null }>()
	const newRoomId = (row?.maxId ?? 0) + 1

	// Ownership is reset to the cloner — the source room's Roles (its creator and
	// any co-owners, e.g. the seeded base-room roles for accounts 1/2) must NOT
	// carry over, or the clone would still list the template's owner as owner.
	const roles: RoomRole[] = [
		{
			AccountId: accountId,
			Role: Role.Creator,
			LastChangedByAccountId: null,
			InvitedRole: Role.None,
		},
	]

	// The system tags (`Type` 1: `beta`, `limitsv2`) carry over — the client derives them
	// from what the scene is built with and the clone is the same scene, so without them
	// the copy doesn't work. Nothing else does: no owner tags, no `base`, no `rro`, and no
	// primary-genre flag (an auto tag is never the genre).
	const sourceTags = Array.isArray(source.Tags) ? (source.Tags as RoomTag[]) : []
	const systemTags: RoomTag[] = sourceTags
		.filter((t) => t.Type === RoomTagType.auto)
		.map((t) => ({ Tag: t.Tag, Type: RoomTagType.auto }))

	const cloned: Room = {
		...source,
		RoomId: newRoomId,
		Name: name,
		CreatorAccountId: accountId,
		// Kept: a clone of a dorm is a custom dorm (see above).
		IsDorm: source.IsDorm === true,
		// Start fresh, except for the system tags the scene needs to run (see below).
		Tags: systemTags,
		// A user clone is not a Rec Room Original — clear the inherited flag, or the
		// client renders a virtual "RRO" tag on the clone.
		IsRRO: false,
		// Neither is the cloner a developer, and a copy doesn't inherit the source's consent
		// to be copied: the new owner opts their room into cloning themselves.
		IsDeveloperOwned: false,
		CloningAllowed: false,
		// A brand-new room is unpublished: the owner publishes it by setting the room's
		// accessibility. Inheriting the source's would put the clone straight into the
		// public feeds (hot/search/recommendations/similar all key on Accessibility === 1)
		// the moment it was made — every clone of a PUBLIC source, template or player room.
		Accessibility: Accessibility.Private,
		Roles: roles,
		// A fresh room has no engagement of its own — don't inherit any of the source's
		// counters. `storedStats` alone would keep the blob-owned `VisitorCount`, which
		// `hotScore` ranks on.
		Stats: { ...ZERO_STATS },
		CreatedAt: new Date().toISOString(),
	}

	// serializeRoom drops the hydrated SubRooms from the blob; the clone's subrooms are
	// inserted into the subroom table below with fresh globally-unique ids.
	await db.batch([
		db.prepare('INSERT INTO room (data) VALUES (?1)').bind(serializeRoom(cloned)),
		...roomRoleWrites(db, newRoomId, cloned),
	])
	// Tags live in `room_tag`, not the blob: the system tags need their own write.
	if (systemTags.length > 0) await setRoomTags(db, newRoomId, systemTags)
	const sourceSubRooms = Array.isArray(source.SubRooms) ? (source.SubRooms as SubRoom[]) : []
	const clonedSubRooms: SubRoom[] = []
	for (const sub of sourceSubRooms) {
		clonedSubRooms.push(await insertSubRoom(db, newRoomId, { ...sub, CreatorAccountId: accountId }))
	}
	cloned.SubRooms = clonedSubRooms
	// Inherited from the (parsed) source in practice; defaulted here too so a clone is
	// never the one room shape missing them.
	attachRoomDtoDefaults(cloned)
	return cloned
}

/** Create an empty Studio room, reserving its id and name in one write. */
export async function createStudioRoom(
	db: D1Database,
	name: string,
	accountId: number,
	ugcVersion: 1 | 2
): Promise<Room | null> {
	const room: Room = {
		RoomId: 0,
		Name: name,
		Description: '',
		ImageName: '',
		CreatorAccountId: accountId,
		Accessibility: Accessibility.Private,
		State: 0,
		PublishState: 0,
		WarningMask: 0,
		CustomWarning: null,
		SupportsScreens: true,
		SupportsWalkVR: true,
		SupportsTeleportVR: true,
		SupportsVRLow: true,
		SupportsQuest2: true,
		SupportsMobile: true,
		SupportsJuniors: true,
		SupportsLevelVoting: false,
		IsRRO: false,
		IsRecRoomApproved: false,
		IsDorm: false,
		IsPlacePlay: false,
		IsDeveloperOwned: false,
		IsJuniorCreated: false,
		ExcludeFromLists: false,
		ExcludeFromSearch: false,
		CloningAllowed: false,
		MinLevel: 0,
		AgeRating: 0,
		CreatedAt: new Date().toISOString(),
		PublishedAt: null,
		BecameRRStudioRoomAt: null,
		Stats: { ...ZERO_STATS },
		UgcVersion: ugcVersion,
		PersistenceVersion: 0,
		UgcSubVersion: null,
		MinUgcSubVersion: null,
		MaxPlayers: 4,
		MaxPlayerCalculationMode: 0,
		DisableMicAutoMute: false,
		DisableRoomComments: false,
		EncryptVoiceChat: false,
		ToxmodEnabled: false,
		LoadScreenLocked: false,
		AutoLocalizeRoom: false,
		LocalizationContext: {},
		RankedEntityId: '',
		Roles: [
			{
				AccountId: accountId,
				Role: Role.Creator,
				LastChangedByAccountId: null,
				InvitedRole: Role.None,
			},
		],
		Tags: [],
		SubRooms: [],
	}
	const inserted = await db
		.prepare(
			`INSERT INTO room (data)
		 SELECT json_set(?1, '$.RoomId', COALESCE(MAX(room_id), 0) + 1) FROM room
		 HAVING NOT EXISTS (SELECT 1 FROM room WHERE name_lower = lower(?2))
		 RETURNING data`
		)
		.bind(serializeRoom(room), name)
		.first<{ data: string }>()
	if (!inserted) return null
	const created = JSON.parse(inserted.data) as Room
	await db.batch(roomRoleWrites(db, Number(created.RoomId), created))
	// Studio's picker and empty-save loader support these modern Maker Room scenes,
	// not the legacy sandbox scene used by generic game subroom creation.
	const scene =
		ugcVersion === 2
			? '5d4e40d8-f289-4295-a6e1-4f907835007d'
			: 'a75f7547-79eb-47c6-8986-6767abcb4f92'
	return (
		(await createSubRoom(db, Number(created.RoomId), accountId, 'Home', scene))?.room ?? created
	)
}

/** Set a room's Description in place (the caller is responsible for the owner check). */
export async function setRoomDescription(
	db: D1Database,
	roomId: number,
	description: string
): Promise<void> {
	await db
		.prepare("UPDATE room SET data = json_set(data, '$.Description', ?2) WHERE room_id = ?1")
		.bind(roomId, description)
		.run()
}

/** A room's progression settings, as `GET /rooms/:id/experience` serves them. */
export interface RoomProgression {
	Enabled: boolean
	DailyLimit: number
}

/**
 * Read a room's progression settings off its blob: `progressionEnabled` and
 * `progressionDailyLimit`. A room that has never had them set reads as off with a 0 cap.
 */
export function roomProgression(room: Room): RoomProgression {
	const limit = room.progressionDailyLimit
	return {
		Enabled: room.progressionEnabled === true,
		DailyLimit: typeof limit === 'number' && Number.isFinite(limit) ? limit : 0,
	}
}

/**
 * Set a room's progression settings in place (the caller checks ownership first). These
 * are `progressionEnabled` / `progressionDailyLimit` on the blob; the per-player XP is in
 * `room_xp` (see room-xp-db.ts).
 */
export async function setRoomProgression(
	db: D1Database,
	roomId: number,
	enabled: boolean,
	dailyLimit: number
): Promise<void> {
	await db
		.prepare(
			`UPDATE room
			 SET data = json_set(data, '$.progressionEnabled', json(?2), '$.progressionDailyLimit', ?3)
			 WHERE room_id = ?1`
		)
		.bind(roomId, enabled ? 'true' : 'false', dailyLimit)
		.run()
}

/** Set a room's Name in place (the caller checks ownership + name uniqueness first). */
export async function setRoomName(db: D1Database, roomId: number, name: string): Promise<void> {
	await db
		.prepare("UPDATE room SET data = json_set(data, '$.Name', ?2) WHERE room_id = ?1")
		.bind(roomId, name)
		.run()
}

/**
 * Follow a username change on the account's dorms: every dorm it created that still carries an
 * owner-prefixed name (`@<username>'s Dorm`, the name {@link getOrCreateDormRoom} gives it) is
 * renamed after the new username. A custom dorm the player named stays as named: room names
 * can't start with `@` (see validation.ts), so only the server's own names match. Without this
 * the dorm kept the name it was provisioned under forever, sign-up's generated one included.
 * Answers how many dorms were renamed.
 */
export async function renameAutoNamedDorms(
	db: D1Database,
	accountId: number,
	username: string
): Promise<number> {
	const { meta } = await db
		.prepare(
			`UPDATE room SET data = json_set(data, '$.Name', ?2)
			 WHERE creator_account_id = ?1 AND is_dorm = 1 AND name_lower LIKE '@%''s dorm'`
		)
		.bind(accountId, `@${username}'s Dorm`)
		.run()
	return meta.changes
}

/** Set a room's ImageName in place (the caller is responsible for the owner check). */
export async function setRoomImage(
	db: D1Database,
	roomId: number,
	imageName: string
): Promise<void> {
	await db
		.prepare("UPDATE room SET data = json_set(data, '$.ImageName', ?2) WHERE room_id = ?1")
		.bind(roomId, imageName)
		.run()
}

/**
 * Stamp `BecameRRStudioRoomAt` the first time a Rec Room Studio build is stored for
 * this room. A room that already carries a timestamp keeps it: a later local build
 * is another cloud build, not a new moment of becoming a Studio room. A missing key
 * and a JSON null both count as unset (`json_type` is not `text`).
 */
export async function markRoomAsRecRoomStudio(
	db: D1Database,
	roomId: number,
	at: string
): Promise<void> {
	await db
		.prepare(
			`UPDATE room SET data = json_set(data, '$.BecameRRStudioRoomAt', ?2)
			 WHERE room_id = ?1 AND json_type(data, '$.BecameRRStudioRoomAt') IS NOT 'text'`
		)
		.bind(roomId, at)
		.run()
}

/**
 * Point one existing subroom save at a baked Unity asset, in place. Local Studio
 * builds attach to the save the room is already published from; they do not append
 * a new save row. Returns false when that save id is not this subroom's.
 */
export async function setSubRoomSaveUnityAssetId(
	db: D1Database,
	subRoomId: number,
	saveId: number,
	unityAssetId: string
): Promise<boolean> {
	const result = await db
		.prepare(
			`UPDATE subroom_save SET data = json_set(data, '$.UnityAssetId', ?3)
			 WHERE sub_room_data_save_id = ?1 AND sub_room_id = ?2`
		)
		.bind(saveId, subRoomId, unityAssetId)
		.run()
	return (result.meta.changes ?? 0) > 0
}

/**
 * Merge a set of top-level fields into a room's JSON blob and write it back. Used by
 * the room-settings mutations whose values include booleans (cloning, platform
 * restrictions) — rewriting the whole blob preserves proper JSON booleans, whereas a
 * `json_set` bind would store `true`/`false` as `1`/`0`. The caller supplies the
 * already-loaded, permission-checked room. Returns the updated room.
 */
export async function updateRoomFields(
	db: D1Database,
	roomId: number,
	room: Room,
	patch: Record<string, unknown>
): Promise<Room> {
	const updated: Room = { ...room, ...patch }
	await db.batch([
		db.prepare('UPDATE room SET data = ?2 WHERE room_id = ?1').bind(roomId, serializeRoom(updated)),
		...('Roles' in patch ? roomRoleWrites(db, roomId, updated) : []),
	])
	return updated
}

/**
 * Whether a role tier can only be taken by INVITATION — offered with
 * {@link inviteRoomRole} and accepted by the player themselves via
 * {@link answerRoomRoleInvite} — rather than granted outright.
 *
 * {@link Role.CoOwner} is the tier this rule exists for: nobody can force-add a co-owner,
 * it is always an invite the player accepts. {@link Role.Creator} is included because it is
 * strictly more than co-ownership — it would make no sense for the bigger grant to be the
 * one that skips the ceremony. Expressed as `>=` so a tier added between or above them is
 * covered by default: a new high-privilege role should have to be accepted until someone
 * decides otherwise, not be grantable because nobody updated this list.
 */
export function roleRequiresInvite(role: number): boolean {
	return role >= Role.CoOwner
}

/**
 * GRANT a room role outright — updating the target account's existing `Roles` entry or
 * appending one — and stamp `LastChangedByAccountId` with the editor. This is the owner's
 * half of role management, and it takes effect immediately: the helper tiers
 * ({@link Role.Host}, {@link Role.Moderator} and whatever else the client hands out) are the
 * owner's to give.
 *
 * Returns null, writing nothing, for a tier that {@link roleRequiresInvite} — nobody can
 * force-add a co-owner, whoever is asking. An owner cannot be demoted this way, and only
 * the owner may demote a co-owner, just as with {@link removeRoomRole}.
 * The rule lives HERE rather than in the route that
 * currently calls this, because it is an invariant of the room's `Roles` and not a policy of
 * one endpoint: the only way a `Role` of {@link Role.CoOwner} may ever appear on an entry is
 * {@link answerRoomRoleInvite} promoting an `InvitedRole` the room's owner offered.
 *
 * The caller supplies the already-loaded room (after its gate) to avoid a re-read; the whole
 * room JSON is rewritten. Any pending `InvitedRole` on the entry is left standing — a granted
 * Host with a co-owner invite open still has it to answer.
 */
export async function setRoomRole(
	db: D1Database,
	roomId: number,
	targetAccountId: number,
	role: number,
	changedByAccountId: number,
	room: Room
): Promise<Room | null> {
	if (roleRequiresInvite(role)) return null

	const roles = roomRoles(room)
	const existing = roles.find((r) => r.AccountId === targetAccountId)
	if (room.CreatorAccountId === targetAccountId || existing?.Role === Role.Creator) return null
	if (existing?.Role === Role.CoOwner && !isRoomOwner(room, changedByAccountId)) return null
	if (existing) {
		existing.Role = role
		existing.LastChangedByAccountId = changedByAccountId
	} else {
		roles.push({
			AccountId: targetAccountId,
			Role: role,
			LastChangedByAccountId: changedByAccountId,
			InvitedRole: Role.None,
		})
	}

	const updated: Room = { ...room, Roles: roles }
	await db.batch([
		db.prepare('UPDATE room SET data = ?2 WHERE room_id = ?1').bind(roomId, serializeRoom(updated)),
		...roomRoleWrites(db, roomId, updated),
	])
	return updated
}

/**
 * REVOKE a room role — dropping the target's `Roles` entry outright. This is how a room's
 * owner or a co-owner takes back a role they handed out, and it is the counterpart to
 * {@link setRoomRole}: there is no "demote to nothing" tier, because {@link Role.None} is the
 * resting value of a PENDING invite rather than a role somebody holds. An entry that confers
 * nothing should not exist, so a revoke removes the record.
 *
 * Two entries are protected, and both refuse by returning null without writing:
 *
 *  - The room's OWNER — `CreatorAccountId`, or a {@link Role.Creator} entry. Ownership is not
 *    a role to be taken away by anyone standing beside it; it moves through
 *    {@link transferRoomOwnership} and nowhere else. Without this a co-owner could remove the
 *    creator's entry, and on an older room whose creator has no entry at all they could not —
 *    so the check is on `CreatorAccountId` as well as on the tier.
 *  - A CO-OWNER entry, unless the caller is the room's owner. Co-owners are peers: letting one
 *    remove another means whichever of them asks first wins, and the room's owner is the only
 *    person who is not a peer of theirs. A co-owner may still revoke the helper tiers.
 *
 * Removing a role a player does not have is NOT a failure — the room comes back unchanged and
 * nothing is written. The caller asked for this player to hold no role, and they hold none;
 * answering an error would make a client retrying a removal look broken.
 *
 * Takes any pending `InvitedRole` with it, since the whole entry goes. That is the same
 * trade {@link answerRoomRoleInvite} makes when declining, and it means revoking a role from
 * someone who has a co-owner invite standing also withdraws the invite.
 *
 * `removedByAccountId` is not stamped anywhere — the entry it would be stamped on is the one
 * being deleted — and is read only to decide which of the two protections apply. The caller
 * supplies the already-loaded room (after its gate) to avoid a re-read; the whole room JSON
 * is rewritten.
 */
export async function removeRoomRole(
	db: D1Database,
	roomId: number,
	targetAccountId: number,
	removedByAccountId: number,
	room: Room
): Promise<Room | null> {
	if (room.CreatorAccountId === targetAccountId) return null

	const roles = roomRoles(room)
	const index = roles.findIndex((r) => r.AccountId === targetAccountId)
	if (index === -1) return room

	const entry = roles[index]
	if (entry.Role === Role.Creator) return null
	if (entry.Role === Role.CoOwner && !isRoomOwner(room, removedByAccountId)) return null

	roles.splice(index, 1)
	const updated: Room = { ...room, Roles: roles }
	await db.batch([
		db.prepare('UPDATE room SET data = ?2 WHERE room_id = ?1').bind(roomId, serializeRoom(updated)),
		...roomRoleWrites(db, roomId, updated),
	])
	return updated
}

/**
 * TRANSFER a room to a new owner: the recipient becomes {@link Role.Creator} and the
 * outgoing owner is left as {@link Role.CoOwner}, keeping their access to a room they built
 * without keeping the room.
 *
 * `CreatorAccountId` moves too, and it has to. It is the room's real owner field — every
 * gate short-circuits on it ({@link canManageRoom}, {@link isRoomOwner}), the "rooms I made"
 * lists select on it, and it is what the client shows. Moving only the `Roles` entries would
 * give the room two owners: the new one by role, the old one by `CreatorAccountId`, still
 * able to hand the room on again.
 *
 * Exempt from {@link roleRequiresInvite}, which otherwise means nobody is handed
 * {@link Role.Creator} without accepting it. This is not a grant made ABOUT someone by a
 * third party; it is the sole person who could already do anything at all to this room
 * giving it away. The recipient gets a room, not a liability, and requiring them to accept
 * would leave the room in a half-transferred state in the meantime.
 *
 * Returns null, writing nothing, for a DORM. A dorm is found by its owner
 * ({@link getDormRoom} selects on `creator_account_id AND is_dorm`), so transferring one
 * would hand somebody else's dorm to the recipient — who already has their own — and mint
 * the original owner a fresh empty one on next access, their build gone.
 *
 * The caller supplies the already-loaded room (after its owner check) to avoid a re-read;
 * the whole room JSON is rewritten. Pending invites on either entry are left standing.
 */
export async function transferRoomOwnership(
	db: D1Database,
	roomId: number,
	fromAccountId: number,
	toAccountId: number,
	room: Room
): Promise<Room | null> {
	if (room.IsDorm === true) return null

	const roles = roomRoles(room)
	// Both sides get an entry whether or not they had one: the outgoing owner may never have
	// been in `Roles` at all (the older rooms carry no entry for their creator), and the
	// recipient is usually a stranger to the room.
	const setRole = (accountId: number, role: number): void => {
		const existing = roles.find((r) => r.AccountId === accountId)
		if (existing) {
			existing.Role = role
			existing.LastChangedByAccountId = fromAccountId
		} else {
			roles.push({
				AccountId: accountId,
				Role: role,
				LastChangedByAccountId: fromAccountId,
				InvitedRole: Role.None,
			})
		}
	}
	setRole(toAccountId, Role.Creator)
	setRole(fromAccountId, Role.CoOwner)

	const updated: Room = { ...room, CreatorAccountId: toAccountId, Roles: roles }
	await db.batch([
		db.prepare('UPDATE room SET data = ?2 WHERE room_id = ?1').bind(roomId, serializeRoom(updated)),
		...roomRoleWrites(db, roomId, updated),
	])
	return updated
}

/**
 * ANSWER a standing room-role invite — accept it, or decline it with `role` 0.
 *
 * Accepting promotes the account's `Roles` entry from its pending `InvitedRole` to the real
 * `Role` and clears the pending one, so an accepted entry reads `Role: 30, InvitedRole: 0`
 * and the invite cannot be answered twice. `role` is what the ACCEPTING PLAYER asked for, and
 * it must equal the `InvitedRole` already on their entry. That equality is the whole security
 * of this call: the answer is made by the invited player themselves, so without it they could
 * answer an invite to Host by asking for Creator and award themselves the room. The invited
 * role is the server's own record of what the owner offered, written by
 * {@link inviteRoomRole}, and nothing the caller sends can move it.
 *
 * Declining (`role` 0 — not a real tier, so it can't be confused for one) REMOVES the entry
 * outright rather than just clearing `InvitedRole`: a declined invite should leave the room's
 * `Roles` as it was before the offer. Note that this takes any role the player already held
 * with it, so someone re-invited to a different tier who declines is left with nothing at
 * all. That is deliberate — an invite is answered as a whole — but it means a decline is not
 * a no-op for an existing member.
 *
 * Returns null — changing nothing — when there is no entry for the account, no invite
 * standing on it, or (when accepting) the requested role isn't the one offered. The three are
 * deliberately one answer: a caller probing for a higher role learns only that it didn't work.
 *
 * `LastChangedByAccountId` is left alone rather than restamped with the accepter: it names
 * who put this role on the entry, and that is the owner who offered it. The caller supplies
 * the already-loaded room to avoid a re-read; the whole room JSON is rewritten.
 */
export async function answerRoomRoleInvite(
	db: D1Database,
	roomId: number,
	accountId: number,
	role: number,
	room: Room
): Promise<Room | null> {
	const roles = roomRoles(room)
	const index = roles.findIndex((r) => r.AccountId === accountId)
	if (index === -1) return null

	const entry = roles[index]
	// `Role.None` is "nothing pending" — the resting state of every entry, and what an
	// already-answered invite leaves behind, so neither answer can be replayed.
	if (entry.InvitedRole === Role.None) return null
	// An invite can outlive an ownership transfer. Answering it must not remove or
	// demote the new owner's Creator entry; ownership moves only by transfer.
	if ((room.CreatorAccountId === accountId || entry.Role === Role.Creator) && role !== Role.Creator) {
		return null
	}

	if (role === Role.None) {
		roles.splice(index, 1)
	} else if (entry.InvitedRole !== role) {
		return null
	} else {
		entry.Role = entry.InvitedRole
		entry.InvitedRole = Role.None
	}

	const updated: Room = { ...room, Roles: roles }
	await db.batch([
		db.prepare('UPDATE room SET data = ?2 WHERE room_id = ?1').bind(roomId, serializeRoom(updated)),
		...roomRoleWrites(db, roomId, updated),
	])
	return updated
}

/**
 * INVITE an account to a room role — setting `InvitedRole` on their `Roles` entry (adding
 * the entry when they have none) and stamping `LastChangedByAccountId` with the inviter.
 *
 * `InvitedRole` is the PENDING half of a role entry: an invited account holds it until
 * they accept, at which point {@link answerRoomRoleInvite} promotes it to the real `Role`.
 * So an entry added here starts at {@link Role.None} — no role yet, only an offer — and an
 * account who already holds a role keeps it while a higher one is pending.
 *
 * Owners cannot be invited, and co-owners may only be invited by an owner: a lower
 * offer could otherwise bypass the same protections as a direct role change.
 * Like {@link answerRoomRoleInvite}, the caller supplies the already-loaded room to
 * avoid a re-read, and the whole room JSON is rewritten. Returns null on a protected target.
 */
export async function inviteRoomRole(
	db: D1Database,
	roomId: number,
	targetAccountId: number,
	invitedRole: number,
	changedByAccountId: number,
	room: Room
): Promise<Room | null> {
	const roles = roomRoles(room)
	const existing = roles.find((r) => r.AccountId === targetAccountId)
	if (room.CreatorAccountId === targetAccountId || existing?.Role === Role.Creator) return null
	if (existing?.Role === Role.CoOwner && !isRoomOwner(room, changedByAccountId)) return null
	if (existing) {
		existing.InvitedRole = invitedRole
		existing.LastChangedByAccountId = changedByAccountId
	} else {
		roles.push({
			AccountId: targetAccountId,
			Role: Role.None,
			LastChangedByAccountId: changedByAccountId,
			InvitedRole: invitedRole,
		})
	}
	const updated: Room = { ...room, Roles: roles }
	await db.batch([
		db.prepare('UPDATE room SET data = ?2 WHERE room_id = ?1').bind(roomId, serializeRoom(updated)),
		...roomRoleWrites(db, roomId, updated),
	])
	return updated
}

/**
 * Mutually-exclusive "main" room tags. The 2023 UI presents these as radio buttons, so
 * toggling one on clears any other main tag. Compared case-insensitively.
 *
 * Only the TOGGLE body obeys this — the newer whole-set body says outright which tags the
 * room has, and its genre is the `IsPrimaryGenre` flag rather than membership of this set.
 */
const MAIN_TAGS = new Set(['pvp', 'quest', 'game', 'hangout', 'art'])

/**
 * A tag's `Type` — the client's tag CATEGORY, echoed back as stored.
 *
 * `user` is what a player types or picks. `auto` is what the client derives about the room
 * and posts as `autoTag` (`limitsv2`, `beta`). `derived` is this server's own (`rro`).
 * A tag's category is orthogonal to whether it is the room's primary genre.
 */
export const RoomTagType = {
	user: 0,
	auto: 1,
	derived: 2,
} as const

/**
 * The tag changes ONE `PUT /rooms/{id}/tags` request asks for. Every field is optional and
 * they compose: a single request may replace the user tags, add a derived one and move the
 * genre, and it is applied as one write.
 */
export interface RoomTagEdit {
	/**
	 * The 2023 single-tag TOGGLE: the tag is added when the room lacks it and removed when
	 * it has it, and adding one of {@link MAIN_TAGS} clears the others.
	 */
	toggle?: string
	/**
	 * The whole set of USER tags, replacing every `Type: 0` tag the room carries. The
	 * derived tags (`auto`, `derived`) are not the client's to send and are left alone.
	 */
	tags?: string[]
	/**
	 * Tags to ensure present at `Type: 1`. Additive — nothing here removes an auto tag,
	 * since the client posts the ones it wants rather than the full set. A tag already on
	 * the room is re-categorised rather than duplicated.
	 */
	autoTags?: string[]
	/**
	 * The tag to flag as the room's genre. Added (as a user tag) when the room lacks it;
	 * every other tag keeps its place and loses the flag.
	 */
	primaryGenre?: string
}

/** A tag's name, lowercased — every comparison in here is case-insensitive. */
const tagKey = (t: RoomTag): string => String(t?.Tag).toLowerCase()

/**
 * Apply one request's worth of tag changes to a room and store the result. The caller
 * supplies the already-loaded (owner-checked) room, so nothing is re-read.
 *
 * The changes are composed into ONE set and written once: a request naming tags, an auto
 * tag and a genre is a single state for the room, and applying it in three writes would
 * let a reader (or a failure) land between them.
 *
 * Only `room_tag` is written — the room blob carries no tags at all, so the room row is
 * left alone.
 */
export async function applyRoomTagEdit(
	db: D1Database,
	roomId: number,
	room: Room,
	edit: RoomTagEdit
): Promise<Room> {
	const current = Array.isArray(room.Tags) ? (room.Tags as RoomTag[]) : []
	// Copies throughout: the room handed in is answered to the client, and the steps below
	// mutate what they build.
	let next: RoomTag[] = current.map((t) => ({ ...t }))

	if (edit.tags !== undefined) {
		// A SET, not a merge. The posted list is exactly the room's user tags afterwards; a
		// tag already there keeps its row (and its genre flag, until the genre step below
		// says otherwise) rather than being deleted and re-added.
		const posted = new Set(edit.tags.map((t) => t.toLowerCase()))
		next = [
			...next.filter((t) => t.Type !== RoomTagType.user && !posted.has(tagKey(t))),
			...edit.tags.map(
				(tag) =>
					next.find((t) => tagKey(t) === tag.toLowerCase()) ?? { Tag: tag, Type: RoomTagType.user }
			),
		]
	} else if (edit.toggle !== undefined) {
		// The 2023 client has no delete/patch endpoint, so the same call toggles: remove the
		// tag if present, add it otherwise. Adding a main tag is a radio pick, so it also
		// clears any other main tag. Removing the flagged tag takes the genre with it, which
		// is right — the room's genre WAS that tag.
		const lower = edit.toggle.toLowerCase()
		const existing = next.findIndex((t) => tagKey(t) === lower)
		if (existing !== -1) {
			next = next.filter((_, i) => i !== existing)
		} else {
			const kept = MAIN_TAGS.has(lower) ? next.filter((t) => !MAIN_TAGS.has(tagKey(t))) : next
			next = [...kept, { Tag: edit.toggle, Type: RoomTagType.user }]
		}
	}

	for (const auto of edit.autoTags ?? []) {
		const existing = next.find((t) => tagKey(t) === auto.toLowerCase())
		// A tag the room already carries is re-categorised in place rather than duplicated —
		// `tag` is the table's key, so there is only ever one row per name anyway.
		if (existing) existing.Type = RoomTagType.auto
		else next.push({ Tag: auto, Type: RoomTagType.auto })
	}

	if (edit.primaryGenre !== undefined) {
		const lower = edit.primaryGenre.toLowerCase()
		for (const tag of next) delete tag.IsPrimaryGenre
		const chosen = next.find((t) => tagKey(t) === lower)
		// A tag the room already carries keeps its category and simply becomes the genre;
		// one it doesn't is added as an ordinary user tag.
		if (chosen) chosen.IsPrimaryGenre = true
		else next.push({ Tag: edit.primaryGenre, Type: RoomTagType.user, IsPrimaryGenre: true })
	}

	return storeRoomTags(db, roomId, room, next)
}

/**
 * Write a room's whole tag set and answer the room carrying it, lowercased the way the
 * table holds it — so the caller replies with exactly what a re-read would give, without
 * paying for the re-read. `IsPrimaryGenre` survives only where it was set, and stays
 * absent (not false) everywhere else.
 */
async function storeRoomTags(
	db: D1Database,
	roomId: number,
	room: Room,
	tags: RoomTag[]
): Promise<Room> {
	await setRoomTags(db, roomId, tags)
	return {
		...room,
		Tags: tags.map((t) => {
			const stored: RoomTag = { Tag: t.Tag.toLowerCase(), Type: t.Type }
			if (t.IsPrimaryGenre) stored.IsPrimaryGenre = true
			return stored
		}),
	}
}

/** Find a subroom (by SubRoomId) inside an already-hydrated room's `SubRooms`, or undefined. */
export function findSubRoom(room: Room, subRoomId: number): SubRoom | undefined {
	const subRooms = Array.isArray(room.SubRooms) ? (room.SubRooms as SubRoom[]) : []
	return subRooms.find((s) => s.SubRoomId === subRoomId)
}

/** Fields from the client's room-save POST body. */
export interface SaveSubRoomDataInput {
	/**
	 * Who a subroom that has no creator yet is filed under. Defaults to the saver; staff
	 * saving into a room they don't manage pass the room's creator, so the save doesn't
	 * make them the subroom's creator.
	 */
	subRoomCreatorId?: number
	/** Uploaded blob key for this subroom's scene data (becomes `CurrentSave.DataBlob`). */
	subRoomDataFilename?: string
	/** `SubRoomData.Hash` — echoed back as the save response's `dataBlobHash`. */
	subRoomDataHash?: string
	/**
	 * `RoomData.Filename` — the uploaded ROOM-level metadata blob (a separate upload from the
	 * scene). It lands on the ROOM as `DataBlob`, not on the subroom: the client's `Room` has
	 * `DataBlob`/`DataBlobHash` and its `SubRoom` has no field for it (`RoomDataBlob`, where
	 * this once went, is not a key the client knows, and it dropped it silently).
	 */
	roomDataFilename?: string
	/** `RoomData.Hash` — stored beside it as the room's `DataBlobHash`; null when unsent. */
	roomDataHash?: string
	/**
	 * The save comment — a description of THIS revision, typed into the client's save box.
	 * It belongs to the save (and shows up in the `…/saves` history); it is not the room's
	 * public description, which only `PUT /rooms/:id/description` sets.
	 */
	description?: string
	persistenceVersion?: number
	omVersion?: number
	ugcSubVersion?: number
	inventionUsage?: string
	/** Optional baked-asset id; emitted on the save only when present. */
	unityAssetId?: string
	/** Studio assets used by spawned inventions, independent of the room's own build. */
	referencedUnityAssetIds?: string[]
	/** Uploaded JSON authoring manifest, distinct from a playable baked bundle. */
	unitySource?: { Filename: string; Hash: string | null }
	/**
	 * The client's `AutoPublish`. True publishes the save outright (the author wants it
	 * live now); false/absent stages it for a manual `publish_save`. Dorms ignore this and
	 * always publish.
	 */
	autoPublish?: boolean
}

/**
 * A subroom's `CurrentSave` — the `SubRoomDataSave` the client reads to find the scene
 * data blob to download. The loader looks ONLY here: a subroom with no `CurrentSave`
 * loads nothing, no matter what the (legacy, flat) `DataBlob` field says.
 */
export type SubRoomDataSave = Record<string, unknown>

/**
 * The scene-data blob key the client should download for a subroom. Prefers the
 * authoritative `CurrentSave.DataBlob` and falls back to the flat `DataBlob` that
 * subrooms written before `CurrentSave` existed (and the `0001_init.sql` dorm seed)
 * still carry. Shared so the `match` and `auth` room-instance payloads resolve the
 * blob the same way the client's own loader does.
 */
export function subRoomDataBlob(sub: SubRoom | undefined | null): string {
	const save = sub?.CurrentSave
	if (save && typeof save === 'object') {
		const blob = (save as SubRoomDataSave).DataBlob
		if (typeof blob === 'string' && blob !== '') return blob
	}
	return typeof sub?.DataBlob === 'string' ? sub.DataBlob : ''
}

/** Fields that vary between a real save and one reconstructed from the legacy shape. */
interface BuildSaveInput {
	subRoomId: unknown
	dataBlob: string | null
	dataBlobHash: string | null
	persistenceVersion: number
	omVersion?: number
	ugcSubVersion?: number
	savedByAccountId: unknown
	description: string
	createdAt: string
	unityAssetId?: string
}

/**
 * Build a `SubRoomDataSave` in the shape the client parses — the reference's `MapSave`
 * projection. The array fields start empty and must be PRESENT. `UnitySubAssets` is
 * filled in on read when this save's `UnityAssetId` has stored Studio bundles (see
 * {@link attachStudioUnityAssets}); referenced assets stay empty. `UnityAssetId` is
 * emitted only when the save actually carried one, exactly as the reference does.
 * There is deliberately no `DataBlobHash` of our own: the caller stores the hash the
 * client sent, and a save that carried none keeps it null.
 *
 * `SavedOnPlatform`/`SavedOnDeviceClass` are 0 — the reference fills them from the saving
 * player's live platform/device, which the save request doesn't carry and we don't track.
 *
 * Shared by the save path and the legacy-shape reconstruction so the two can't drift.
 */
function buildSubRoomSave(input: BuildSaveInput): SubRoomDataSave {
	const save: SubRoomDataSave = {
		UnitySubAssets: [],
		ReferencedUnityAssets: [],
		SubRoomId: input.subRoomId,
		DataBlob: input.dataBlob,
		// The client sends `SubRoomData.Hash` (usually null); the room-save response echoes
		// it as `dataBlobHash`. One observed room payload carries it on `CurrentSave` and
		// another omits it, so storing it and letting it ride along is the safe reading.
		DataBlobHash: input.dataBlobHash,
		ReferencedUnityAssetIds: [],
		PersistenceVersion: input.persistenceVersion,
		OMVersion: input.omVersion ?? 0,
		UgcSubVersion: input.ugcSubVersion ?? 0,
		SavedByAccountId: input.savedByAccountId,
		SavedOnPlatform: 0,
		SavedOnDeviceClass: 0,
		Description: input.description,
		Tags: [],
		ModerationState: 0,
		CreatedAt: input.createdAt,
	}
	if (input.unityAssetId) save.UnityAssetId = input.unityAssetId
	return save
}

/**
 * Build a save row from a subroom stored in the pre-`CurrentSave` shape, where the blob
 * key sat in the flat `DataBlob`/`DataSavedAt`/`PersistenceVersion` fields. Those
 * subrooms hold real saved content the client cannot see (it reads `CurrentSave` only),
 * so they get a save of their own rather than reading as never-saved. Mirrors backfill 2
 * of migration 0008 — keep the two in sync.
 *
 * Returns null when there is genuinely nothing saved, the honest answer for a fresh
 * subroom.
 */
function legacySubRoomSave(sub: SubRoom): SubRoomDataSave | null {
	const blob = sub.DataBlob
	if (typeof blob !== 'string' || blob === '') return null
	const savedAt = typeof sub.DataSavedAt === 'string' ? sub.DataSavedAt : new Date(0).toISOString()
	return buildSubRoomSave({
		subRoomId: sub.SubRoomId,
		dataBlob: blob,
		dataBlobHash: null,
		persistenceVersion: typeof sub.PersistenceVersion === 'number' ? sub.PersistenceVersion : 0,
		// The legacy shape never recorded who saved; the subroom's creator is the best
		// available answer (the save path is owner/co-owner gated).
		savedByAccountId: sub.CreatorAccountId ?? null,
		description: '',
		createdAt: savedAt,
	})
}

/**
 * The invention ids inside a room save's `InventionUsage`, in the order it lists them.
 *
 * The value is a base64 PROTOBUF message, recovered by reading real saves — there is no
 * schema, only field numbers:
 *
 *   1: varint            — 1 on every save seen; a format version by the look of it
 *   2: repeated message  — one per invention in the scene
 *        1: varint       — the invention id
 *        2: varint       — 1 on every save seen; probably how many times it is placed
 *
 * `CAESBgil2gEQARIFCIECEAE=` is `{ 1: 1, 2: [{ 1: 27941, 2: 1 }, { 1: 257, 2: 1 }] }`.
 *
 * Only the ids are read. Anything that doesn't parse — not base64, a truncated message, a
 * wire type this doesn't know — yields the ids found up to that point rather than
 * throwing: this is bookkeeping riding on a room save, and a format the client changes
 * must not be able to fail the save.
 */
export function decodeInventionUsage(inventionUsage: string): number[] {
	let bytes: Uint8Array
	try {
		bytes = Uint8Array.from(atob(inventionUsage), (ch) => ch.charCodeAt(0))
	} catch {
		return []
	}

	/** Walk one message's fields; false from `visit`, or anything malformed, stops the walk. */
	const walk = (
		buf: Uint8Array,
		visit: (field: number, value: number | Uint8Array) => void
	): void => {
		let at = 0
		const varint = (): number | null => {
			let value = 0
			for (let shift = 0; at < buf.length; shift += 7) {
				const byte = buf[at++]
				// Multiplication, not `<<`: ids past 2^31 would wrap as a 32-bit shift.
				value += (byte & 0x7f) * 2 ** shift
				if ((byte & 0x80) === 0) return value
			}
			return null
		}
		while (at < buf.length) {
			const key = varint()
			if (key === null) return
			const field = Math.floor(key / 8)
			const wireType = key % 8
			if (wireType === 0) {
				const value = varint()
				if (value === null) return
				visit(field, value)
			} else if (wireType === 2) {
				const length = varint()
				if (length === null || at + length > buf.length) return
				visit(field, buf.subarray(at, at + length))
				at += length
			} else {
				return
			}
		}
	}

	const ids: number[] = []
	walk(bytes, (field, entry) => {
		if (field !== 2 || typeof entry === 'number') return
		walk(entry, (inner, value) => {
			if (inner === 1 && typeof value === 'number' && Number.isSafeInteger(value)) ids.push(value)
		})
	})
	return ids
}

/**
 * Re-derive a room's `room_invention` rows from its subrooms: the union of the inventions
 * each subroom's last save reported in `InventionUsage`. An invention removed from the room
 * drops out on the next save — and the set is derived from EVERY subroom rather than the
 * one just saved, because the table is per room and a save of one subroom says nothing
 * about what the others still hold.
 *
 * A subroom's `InventionUsage` is whatever its latest save sent, staged or published, so
 * this is the room as its builders last left it, not strictly what players are loading.
 *
 * Every invention that entered or left the room then has its `NumPlayersHaveUsedInRoom`
 * resynced — the number of ROOMS it is in, which is what this server has to put behind
 * that field. Derived from the table, like `CheerCount` and `NumDownloads` from theirs, and
 * a `json_set` on the one key of the `invention` record (the `api` worker's table, same
 * database). Only the rows that changed are written, so the usual save — same inventions
 * as last time — costs one read.
 */
export async function syncRoomInventions(
	db: D1Database,
	roomId: number,
	room: Room
): Promise<void> {
	const subRooms = Array.isArray(room.SubRooms) ? (room.SubRooms as SubRoom[]) : []
	const now = new Set<number>()
	for (const sub of subRooms) {
		if (typeof sub.InventionUsage !== 'string') continue
		for (const id of decodeInventionUsage(sub.InventionUsage)) now.add(id)
	}

	const { results } = await db
		.prepare('SELECT invention_id FROM room_invention WHERE room_id = ?1')
		.bind(roomId)
		.all<{ invention_id: number }>()
	const before = new Set(results.map((r) => r.invention_id))
	const added = [...now].filter((id) => !before.has(id))
	const removed = [...before].filter((id) => !now.has(id))
	if (added.length === 0 && removed.length === 0) return

	// One batch, in order: the membership changes land before the counts are re-derived.
	await db.batch([
		...removed.map((id) =>
			db
				.prepare('DELETE FROM room_invention WHERE room_id = ?1 AND invention_id = ?2')
				.bind(roomId, id)
		),
		...added.map((id) =>
			db
				.prepare('INSERT OR IGNORE INTO room_invention (room_id, invention_id) VALUES (?1, ?2)')
				.bind(roomId, id)
		),
		...[...added, ...removed].map((id) =>
			db
				.prepare(
					`UPDATE invention SET data = json_set(data, '$.NumPlayersHaveUsedInRoom',
						(SELECT COUNT(*) FROM room_invention WHERE invention_id = ?1))
					 WHERE id = ?1`
				)
				.bind(id)
		),
	])
}

/** How many rooms an invention is used in — the stat `room_invention` exists to answer. */
export async function countRoomsUsingInvention(
	db: D1Database,
	inventionId: number
): Promise<number> {
	const row = await db
		.prepare('SELECT COUNT(*) AS n FROM room_invention WHERE invention_id = ?1')
		.bind(inventionId)
		.first<{ n: number }>()
	return row?.n ?? 0
}

/**
 * Persist a room-save against a specific subroom. Everything the save carries belongs to
 * that subroom's revision — nothing is written to the room. Returns the updated
 * (hydrated) room AND the save that was just created — the route answers with both — or
 * null when the room or subroom doesn't exist.
 *
 * Whether the save goes live is the client's call: `AutoPublish: true` publishes it
 * outright, otherwise it becomes the subroom's `staged_save_id` with the live
 * `current_save_id` untouched, so what players load doesn't change until the room's
 * creator publishes (see {@link publishSubRoomSave}). Dorms always publish — they have
 * no publish flow in the client.
 */
export async function saveSubRoomData(
	db: D1Database,
	roomId: number,
	subRoomId: number,
	accountId: number,
	input: SaveSubRoomDataInput
): Promise<{ room: Room; save: SubRoomDataSave } | null> {
	const room = await getRoomById(db, roomId)
	if (!room) return null
	// Read off the already-hydrated room rather than re-querying the subroom and its
	// save — getRoomById has both, and this path is write-heavy enough already.
	const sub = findSubRoom(room, subRoomId)
	if (!sub) return null

	// Populate the subroom's creator on first save — it starts null, and the
	// client NREs on a null CreatorAccountId.
	if (sub.CreatorAccountId == null) sub.CreatorAccountId = input.subRoomCreatorId ?? accountId

	// Append a new save row. The blob the loader downloads lives on the save — a subroom
	// whose current_save_id resolves to nothing loads nothing — so this never touches the
	// flat DataBlob field. Previous saves stay in the table as history.
	//
	// A staged save carries forward from the previous STAGED one when there is one, so a
	// creator's second edit builds on their first rather than on what's live.
	const staged =
		typeof sub.StagedSubRoomDataSaveId === 'number'
			? await getSubRoomSaveById(db, subRoomId, sub.StagedSubRoomDataSaveId)
			: null
	const previous =
		staged ??
		(sub.CurrentSave && typeof sub.CurrentSave === 'object'
			? (sub.CurrentSave as SubRoomDataSave)
			: undefined)
	const priorVersion = previous?.PersistenceVersion
	const priorBlob = previous?.DataBlob
	const saveData = buildSubRoomSave({
		subRoomId,
		// A save that carries no new blob (e.g. a description-only save) keeps the one
		// the subroom already loads from.
		dataBlob:
			input.subRoomDataFilename ??
			(typeof priorBlob === 'string' || priorBlob === null ? priorBlob : ''),
		dataBlobHash: input.subRoomDataHash ?? null,
		persistenceVersion:
			input.persistenceVersion ?? (typeof priorVersion === 'number' ? priorVersion : 0),
		omVersion:
			input.omVersion ?? (typeof previous?.OMVersion === 'number' ? previous.OMVersion : 0),
		ugcSubVersion:
			input.ugcSubVersion ??
			(typeof previous?.UgcSubVersion === 'number' ? previous.UgcSubVersion : 0),
		savedByAccountId: accountId,
		// The save comment — empty string, not null, when the save carries none (the
		// reference's `roomDesc ?? ""`).
		description: input.description ?? '',
		createdAt: new Date().toISOString(),
		unityAssetId: input.unitySource
			? (input.unityAssetId ?? crypto.randomUUID())
			: input.unityAssetId,
	})
	saveData.ReferencedUnityAssetIds = input.referencedUnityAssetIds ?? []
	// A live client save changes the scene data while reusing the baked Studio
	// asset. Its export manifest belongs to that asset and is needed again on the
	// save's immediate reload (prefabs/materials live in separate bundles).
	// A new Studio source upload must wait for its own cloud-build manifest.
	if (
		!input.unitySource &&
		typeof input.unityAssetId === 'string' &&
		typeof previous?.UnityAssetId === 'string' &&
		input.unityAssetId.toLowerCase() === previous.UnityAssetId.toLowerCase() &&
		previous.ServerData != null
	) {
		saveData.ServerData = previous.ServerData
	}
	if (
		!input.unitySource &&
		input.unityAssetId &&
		typeof previous?.UnityAssetId === 'string' &&
		input.unityAssetId.toLowerCase() === previous.UnityAssetId.toLowerCase() &&
		previous.StudioSourceAsset
	) {
		// The editable source belongs to the reused asset, just like its baked bundles.
		saveData.StudioSourceAsset = previous.StudioSourceAsset
	}
	if (input.unitySource) {
		saveData.StudioSourceAsset = input.unitySource
		saveData.SavedOnPlatform = null
		saveData.SavedOnDeviceClass = null
	}
	const save = await insertSubRoomSave(db, subRoomId, saveData)
	const saveId = Number(save.SubRoomDataSaveId)
	sub.DataSavedAt = new Date().toISOString()
	if (input.persistenceVersion !== undefined) sub.PersistenceVersion = input.persistenceVersion
	if (input.inventionUsage !== undefined) sub.InventionUsage = input.inventionUsage

	// The ONE thing a save writes on the ROOM: `RoomData`, the room-level metadata blob the
	// client uploads beside the scene. The client's `Room` reads it as `DataBlob` (with
	// `DataBlobHash`), so that is where it goes — a targeted `json_set` of those two keys,
	// never a rewrite of the room row. It used to be put on the subroom as `RoomDataBlob`,
	// which the client has no field for, so no save ever reached it.
	//
	// Everything else the save carries describes the SUBROOM's revision: `Description` is the
	// save comment shown in the `…/saves` history, `PersistenceVersion` and `InventionUsage`
	// describe the scene just saved. They used to be copied onto the room as well, which
	// meant each save silently replaced the room's public description with the save comment.
	// The room's own fields are edited through their own routes (`PUT /rooms/:id/description`
	// and friends).
	const roomWrites: D1PreparedStatement[] = []
	if (input.roomDataFilename) {
		const hash = input.roomDataHash ?? null
		room.DataBlob = input.roomDataFilename
		room.DataBlobHash = hash
		roomWrites.push(
			db
				.prepare(
					"UPDATE room SET data = json_set(data, '$.DataBlob', ?2, '$.DataBlobHash', ?3) WHERE room_id = ?1"
				)
				.bind(roomId, input.roomDataFilename, hash)
		)
	}

	// Publish outright when the client asked to (`AutoPublish`), or for a dorm — a dorm is
	// the player's own private space with no publish step in the client, so staging one
	// would leave their edits permanently invisible. Otherwise stage it and wait for
	// `publish_save`. One round trip for the rest of the save.
	const publishNow = input.autoPublish === true || room.IsDorm === true
	await db.batch([
		...roomWrites,
		publishNow
			? db
					.prepare(
						'UPDATE subroom SET current_save_id = ?2, staged_save_id = NULL WHERE sub_room_id = ?1'
					)
					.bind(subRoomId, saveId)
			: db
					.prepare('UPDATE subroom SET staged_save_id = ?2 WHERE sub_room_id = ?1')
					.bind(subRoomId, saveId),
		db
			.prepare('UPDATE subroom SET data = ?2 WHERE sub_room_id = ?1')
			.bind(subRoomId, serializeSubRoom(sub, roomId)),
	])

	// Re-hydrate so the returned room reflects the just-saved subroom.
	await attachSubRooms(db, [room])
	// The one thing a save records OUTSIDE the subroom and its save row: which inventions
	// the room now has in it. Its own table, so the room row is still not rewritten.
	await syncRoomInventions(db, roomId, room)
	return { room, save }
}

/**
 * Publish one of a subroom's saves by id: make it the `current_save_id` players load.
 * This is the manual step every non-dorm room save waits on ({@link saveSubRoomData}
 * only stages). Because it takes an explicit id it doubles as restore-a-save — the id
 * can be any save in the subroom's history, not just the staged one.
 *
 * The staging slot is cleared only when the save being published IS the staged one, so
 * restoring an older version doesn't silently discard newer unpublished work.
 *
 * The id is looked up scoped to the subroom, so one subroom can't publish another's save
 * (ids are globally unique, so an unscoped lookup would happily resolve).
 *
 * Returns the updated (hydrated) room, or a reason: `not_found` (no such room/subroom) /
 * `unknown_save` (no such save on this subroom).
 */
export async function publishSubRoomSave(
	db: D1Database,
	roomId: number,
	subRoomId: number,
	saveId: number
): Promise<{ ok: true; room: Room } | { ok: false; reason: 'not_found' | 'unknown_save' }> {
	const sub = await getSubRoom(db, roomId, subRoomId)
	if (!sub) return { ok: false, reason: 'not_found' }
	if (!(await getSubRoomSaveById(db, subRoomId, saveId))) {
		return { ok: false, reason: 'unknown_save' }
	}

	await db
		.prepare(
			`UPDATE subroom SET current_save_id = ?2,
			   staged_save_id = CASE WHEN staged_save_id = ?2 THEN NULL ELSE staged_save_id END
			 WHERE sub_room_id = ?1`
		)
		.bind(subRoomId, saveId)
		.run()

	const room = await getRoomById(db, roomId)
	if (!room) return { ok: false, reason: 'not_found' }
	return { ok: true, room }
}

/**
 * Complete the self-hosted Studio save review. There is no external automated
 * moderation service here. Only unreviewed/pending saves are approved; a staff
 * decision or escalation must survive retries. This never publishes a staged save.
 */
export async function requestSubRoomSaveModeration(
	db: D1Database,
	roomId: number,
	subRoomId: number,
	saveId: number
): Promise<Room | null> {
	if (!(await getSubRoom(db, roomId, subRoomId))) return null
	if (!(await getSubRoomSaveById(db, subRoomId, saveId))) return null
	await db.batch([
		db
			.prepare(
				`UPDATE subroom_save SET data = json_set(data, '$.ModerationState', 2)
				 WHERE sub_room_id = ?1 AND sub_room_data_save_id = ?2
				 AND COALESCE(json_extract(data, '$.ModerationState'), 0) IN (0, 1)`
			)
			.bind(subRoomId, saveId),
		db
			.prepare(
				`UPDATE subroom SET data = json_set(data, '$.LastModeratedSaveModerationState',
				 (SELECT json_extract(data, '$.ModerationState') FROM subroom_save
				  WHERE sub_room_id = ?1 AND sub_room_data_save_id = ?2))
				 WHERE room_id = ?3 AND sub_room_id = ?1`
			)
			.bind(subRoomId, saveId, roomId),
	])
	return getRoomById(db, roomId)
}

/** Fields from the client's subroom `modify` form (each applied only when supplied). */
export interface ModifySubRoomInput {
	name?: string
	accessibility?: number
	maxPlayers?: number
}

/**
 * Modify a subroom's settings in place — its Name, Accessibility, and MaxPlayers
 * (the fields the client's subroom `modify` form carries). Only the supplied fields
 * are changed; the subroom row is updated in the `subroom` table. Returns the updated
 * (hydrated) room, or null when the room or subroom doesn't exist.
 *
 * A changed `MaxPlayers` is pushed onto the subroom's LIVE instances too (see
 * {@link resyncInstanceCapacity}): each instance carries a copy of the cap it enforces,
 * and this is the write that makes that copy stale.
 */
export async function modifySubRoom(
	db: D1Database,
	roomId: number,
	subRoomId: number,
	input: ModifySubRoomInput
): Promise<Room | null> {
	const sub = await getSubRoom(db, roomId, subRoomId)
	if (!sub) return null

	if (input.name !== undefined) sub.Name = input.name
	if (input.accessibility !== undefined) sub.Accessibility = input.accessibility
	const capacityChanged = input.maxPlayers !== undefined && input.maxPlayers !== sub.MaxPlayers
	if (input.maxPlayers !== undefined) sub.MaxPlayers = input.maxPlayers
	await updateSubRoom(db, sub)
	if (capacityChanged) await resyncInstanceCapacity(db, roomId, subRoomId, input.maxPlayers!)

	return getRoomById(db, roomId)
}

/**
 * Clone an existing subroom into a new subroom of the same room, owned by
 * `accountId`. The copy keeps the source's scene/settings (and its saved data
 * blobs, so it loads identical content) but gets a fresh globally-unique SubRoomId
 * minted from the `subroom` table's autoincrement sequence. Returns the updated
 * (hydrated) room and the new subroom, or null when the room or source subroom
 * doesn't exist.
 */
export async function cloneSubRoom(
	db: D1Database,
	roomId: number,
	subRoomId: number,
	accountId: number
): Promise<{ room: Room; subRoom: SubRoom } | null> {
	const source = await getSubRoom(db, roomId, subRoomId)
	if (!source) return null

	const subRoom = await insertSubRoom(db, roomId, { ...source, CreatorAccountId: accountId })
	const room = await getRoomById(db, roomId)
	if (!room) return null
	return { room, subRoom }
}

/** Fallback scene, used only when a room has no existing subroom to inherit from. */
const DEFAULT_SUBROOM_SCENE = '76d98498-60a1-430c-ab76-b54a29b7a163'

/**
 * The scene a brand-new subroom inherits: the room's own first (existing) subroom —
 * lowest SubRoomId — read from the subroom table. Falls back to the base sandbox scene
 * only when the room has no subrooms yet.
 */
async function baseSubRoomScene(db: D1Database, roomId: number): Promise<string> {
	const row = await db
		.prepare('SELECT data FROM subroom WHERE room_id = ?1 ORDER BY sub_room_id LIMIT 1')
		.bind(roomId)
		.first<{ data: string }>()
	const scene = row ? (JSON.parse(row.data) as SubRoom).UnitySceneId : undefined
	return typeof scene === 'string' ? scene : DEFAULT_SUBROOM_SCENE
}

/**
 * Create a new (empty) subroom in a room, owned by `accountId` and named `name`. It
 * inherits the room's existing subroom scene (see {@link baseSubRoomScene}) with a clean
 * save, and gets a fresh globally-unique SubRoomId. Returns the updated (hydrated) room
 * and the new subroom, or null when the room doesn't exist.
 */
export async function createSubRoom(
	db: D1Database,
	roomId: number,
	accountId: number,
	name: string,
	initialScene?: string
): Promise<{ room: Room; subRoom: SubRoom } | null> {
	const room = await getRoomById(db, roomId)
	if (!room) return null

	const subRoom = await insertSubRoom(db, roomId, {
		Name: name,
		CreatorAccountId: accountId,
		UnitySceneId: initialScene ?? (await baseSubRoomScene(db, roomId)),
		MaxPlayers: 4,
		Accessibility: Accessibility.Unlisted,
		IsSandbox: true,
		LastModeratedSaveModerationState: 0,
		ShouldAutoStageSaves: true,
		// Rooms 2 validates CurrentSave.OMVersion even when the scene uses its built-in
		// empty template. No blob or uploaded Studio bundle is needed for that template.
		...(room.UgcVersion === 2
			? {
					CurrentSave: buildSubRoomSave({
						subRoomId: 0,
						dataBlob: null,
						dataBlobHash: null,
						persistenceVersion: 0,
						// 20260323.14's built-in object-model template format (0xC6).
						omVersion: 198,
						savedByAccountId: accountId,
						description: '',
						createdAt: new Date().toISOString(),
					}),
				}
			: {}),
	})
	// Refresh the hydrated SubRooms so the returned room includes the one just inserted.
	await attachSubRooms(db, [room])
	return { room, subRoom }
}

/**
 * Delete a subroom from a room. Refuses to remove a room's only subroom (that would
 * leave it with no scene to load). Any saved-data blob the subroom pointed at is left in
 * R2 (like {@link deleteRoom} leaves a room's images). Returns the updated (hydrated)
 * room on success, or a reason: `not_found` (no such subroom) / `last_subroom`.
 */
export async function deleteSubRoom(
	db: D1Database,
	roomId: number,
	subRoomId: number
): Promise<{ ok: true; room: Room } | { ok: false; reason: 'not_found' | 'last_subroom' }> {
	const subRooms = await getSubRooms(db, roomId)
	if (!subRooms.some((s) => s.SubRoomId === subRoomId)) return { ok: false, reason: 'not_found' }
	if (subRooms.length <= 1) return { ok: false, reason: 'last_subroom' }

	await db.batch([
		db
			.prepare('DELETE FROM subroom WHERE room_id = ?1 AND sub_room_id = ?2')
			.bind(roomId, subRoomId),
		// The saves go with it — nothing can reference them once the subroom is gone.
		// The blobs they point at are left in R2, like a deleted room's images.
		db.prepare('DELETE FROM subroom_save WHERE sub_room_id = ?1').bind(subRoomId),
		// So do its permission overrides — subroom ids are minted from one global
		// sequence, but leaving orphans would still be dead rows nothing can reach.
		db.prepare('DELETE FROM subroom_permission WHERE sub_room_id = ?1').bind(subRoomId),
	])

	const room = await getRoomById(db, roomId)
	if (!room) return { ok: false, reason: 'not_found' }
	return { ok: true, room }
}

/**
 * Move a subroom from one room to another (`POST …/subrooms/{subRoomId}/move`). A subroom
 * is its own row keyed by a globally-unique id, and its saves and permission overrides hang
 * off that id rather than the room's, so the move is one column: `room_id`. The saves,
 * the current/staged pointers and the permissions all travel with it untouched. The
 * subroom's `RoomId` is re-injected from the column on read, so the blob needs nothing.
 *
 * Refuses to move a room's only subroom, for the reason {@link deleteSubRoom} refuses to
 * delete it: the room would be left with no scene to load. The caller checks the target
 * room exists and that it may manage both rooms — this only checks the subroom's side.
 *
 * Returns the SOURCE room, hydrated, which no longer lists the subroom — that is what the
 * client re-renders from — or a reason: `not_found` (no such subroom in that room) /
 * `last_subroom`.
 */
export async function moveSubRoom(
	db: D1Database,
	roomId: number,
	subRoomId: number,
	newRoomId: number
): Promise<{ ok: true; room: Room } | { ok: false; reason: 'not_found' | 'last_subroom' }> {
	const subRooms = await getSubRooms(db, roomId)
	if (!subRooms.some((s) => s.SubRoomId === subRoomId)) return { ok: false, reason: 'not_found' }
	if (subRooms.length <= 1) return { ok: false, reason: 'last_subroom' }

	await db
		.prepare('UPDATE subroom SET room_id = ?3 WHERE room_id = ?1 AND sub_room_id = ?2')
		.bind(roomId, subRoomId, newRoomId)
		.run()

	const room = await getRoomById(db, roomId)
	if (!room) return { ok: false, reason: 'not_found' }
	return { ok: true, room }
}

interface RoomRow {
	data: string
	visits: number
	cheers: number
	favorites: number
	/** Active boost units; absent on the ranking stubs ({@link RANK_COLUMNS}). */
	boosts?: number
}

/**
 * The columns every room read selects. `visits`, `cheers` and `favorites` are
 * authoritative for the room's `Stats.VisitCount`/`CheerCount`/`FavoriteCount` (the blob
 * keeps them at 0 — see {@link storedStats}), so they have to come back with the blob on
 * every read; a join aliases them (`r.data AS data`), see {@link COUNTER_COLUMNS}. `boosts`
 * is the room's active boost units (`room_boost`), served as `BoostCount`.
 */
const ROOM_COLUMNS = `data, visits, cheers, favorites, ${activeBoostsSql('room')} AS boosts`

/** The counter columns of {@link ROOM_COLUMNS} as a join selects them, aliased to the row's names. */
const COUNTER_COLUMNS = `r.visits AS visits, r.cheers AS cheers, r.favorites AS favorites, ${activeBoostsSql('r')} AS boosts`

/**
 * The rooms a public feed may consider, as a SQL predicate: public, not a dorm, and not
 * opted out of lists — the same test {@link isListable} makes in memory, pushed down so
 * the blobs of the rooms that fail it never cross the wire. `IS NOT 1` rather than `= 0`
 * because a blob missing the key extracts as NULL, which the JS `!== true` accepts.
 *
 * The feeds all scanned the whole table and threw most of it away: a server's rooms are
 * mostly DORMS (one per account, private by construction), so a scan read megabytes of
 * blob to rank a hundred rooms. `idx_room_public` covers the first two terms, so this
 * visits only the rooms that can actually be served.
 *
 * The in-memory filter STAYS wherever this is used. It costs nothing once the set is
 * small, and it — not the SQL — remains the definition of listable: a blob with a
 * surprising type in one of these fields (`"1"` for `Accessibility`, say) would satisfy
 * the column's integer affinity while failing `=== 1` in JS, and the feeds must agree
 * with {@link isListable} rather than with SQLite.
 */
const LISTABLE_WHERE = 'is_dorm IS NOT 1 AND accessibility = 1 AND exclude_from_lists IS NOT 1'

/**
 * The wider half of {@link LISTABLE_WHERE}: public and not a dorm, without the
 * `ExcludeFromLists` term. What `idx_room_public` covers, and the base of
 * {@link SEARCHABLE_WHERE}.
 */
const PUBLIC_WHERE = 'is_dorm IS NOT 1 AND accessibility = 1'

/**
 * What SEARCH considers — the same test {@link isSearchable} makes in memory, pushed down
 * like {@link LISTABLE_WHERE} is for the feeds. `ExcludeFromSearch` is a room's own flag,
 * independent of `ExcludeFromLists`: a room can opt out of the browse feeds and still be
 * findable by name, or be in every feed and unfindable by name. So the two searching reads
 * ({@link searchRooms}, {@link autocompleteRoomSearch}) select on this and NOT on the
 * listable predicate; `idx_room_public` still narrows them to the public rooms, and the
 * search term is checked against the rows it fetched. The in-memory filter stays, for the
 * same reason it does with the feeds.
 */
const SEARCHABLE_WHERE = `${PUBLIC_WHERE} AND exclude_from_search IS NOT 1`

/**
 * The columns a scan-then-rank feed selects in place of {@link ROOM_COLUMNS}: a STUB room
 * holding only the fields the feeds filter and sort on, not the whole blob. The feeds rank
 * every listable room to serve one page, so reading the full blobs moved every listable
 * room's JSON over the wire and through `JSON.parse` for the handful that get served; the
 * page's full rooms are then read by id ({@link loadRankedPage}).
 *
 * `->` rather than `json_extract` because it hands back JSON, so `json_object` embeds each
 * value with its JSON type intact — `true` stays `true`, not 1, and a `"1"` stays a string.
 * That is what lets {@link isListable} and friends run on the stub unchanged and remain the
 * definition of listable. A missing key comes back as null, which every test below reads
 * the same as absent. A feed that starts reading a new field off the room has to add it
 * here, or it reads null.
 */
const RANK_COLUMNS = `json_object(${[
	'RoomId',
	'IsDorm',
	'Accessibility',
	'ExcludeFromLists',
	'CreatorAccountId',
	'CreatedAt',
	'IsRRO',
	'Stats',
]
	.map((key) => `'${key}', data -> '$.${key}'`)
	.join(', ')}) AS data, visits, cheers, favorites`

/**
 * The full rooms behind a page of {@link RANK_COLUMNS} stubs, in the stubs' order, parsed
 * like any room read (not yet hydrated). A room deleted between the two reads is dropped
 * rather than served as a stub.
 */
async function loadRankedPage(db: D1Database, stubs: Room[]): Promise<Room[]> {
	const ids = stubs.map(roomIdOf)
	if (ids.length === 0) return []
	const rows = await selectInChunks<RoomRow>(
		db,
		ids,
		(placeholders) => `SELECT ${ROOM_COLUMNS} FROM room WHERE room_id IN (${placeholders})`
	)
	const byId = new Map(parseAll(rows).map((room) => [roomIdOf(room), room]))
	return ids.map((id) => byId.get(id)).filter((room): room is Room => room !== undefined)
}

/**
 * Keys on the client's room DTO that nothing here stores, defaulted on every read so the
 * key is PRESENT rather than absent — the seed blobs and every room written since predate
 * them, so they can't come from the data:
 *
 * - `BoostCount` — the room's active boost units. Every room read selects them
 *   ({@link ROOM_COLUMNS}); this only covers a room built in code rather than read.
 * - `CurrentSnapshotId` — the room's published snapshot. Nothing takes snapshots, so it is
 *   null, which is also what the reference serves for a room that has none.
 * - `CCU` — concurrent users. No live-population counter exists here, so it is null, which
 *   is what the reference serves when it has no number rather than 0 (a 0 reads as "nobody
 *   is in here" in the browse feeds).
 *
 * Defaulted rather than assigned, so a stored value wins if any is ever really written
 * (a blob keeps whatever `serializeRoom` last put in it).
 */
function attachRoomDtoDefaults(room: Room): void {
	room.BoostCount ??= 0
	room.CurrentSnapshotId ??= null
	room.CCU ??= null
}

/**
 * Parse a room row: the stored blob with the counters the columns own folded back in.
 * `visits`/`cheers`/`favorites` are real columns, so a room read straight from the DB —
 * a full read or a ranking stub alike — carries the live counts; nothing is derived.
 */
const parseRow = (row: RoomRow): Room => {
	const room = JSON.parse(row.data) as Room
	room.Stats = {
		...storedStats(room.Stats),
		VisitCount: row.visits ?? 0,
		CheerCount: row.cheers ?? 0,
		FavoriteCount: row.favorites ?? 0,
	}
	if (row.boosts !== undefined) room.BoostCount = row.boosts
	attachRoomDtoDefaults(room)
	return room
}

const parseOne = (row: RoomRow | null): Room | null => (row ? parseRow(row) : null)
const parseAll = (rows: RoomRow[]): Room[] => rows.map(parseRow)

/**
 * Run one `… IN (…)` query per chunk and concatenate the rows. `sql` is handed the
 * placeholder list for its chunk (`?1,?2,…`), which always restarts at `?1` because each
 * chunk is its own statement.
 *
 * Rows come back in chunk order, and each chunk is ordered by whatever `sql` says. Callers
 * that group by a key stay correct as long as a key's rows can't straddle two chunks —
 * true for both callers here, which chunk BY that key.
 */
async function selectInChunks<Row>(
	db: D1Database,
	ids: number[],
	sql: (placeholders: string) => string
): Promise<Row[]> {
	const pages = await Promise.all(
		chunkForBinds(ids).map((chunk) =>
			db
				.prepare(sql(chunk.map((_, i) => `?${i + 1}`).join(',')))
				.bind(...chunk)
				.all<Row>()
		)
	)
	return pages.flatMap((page) => page.results)
}

// ---- Subrooms -------------------------------------------------------------
// Subrooms are their own table (globally-unique autoincrement `sub_room_id`); a
// room's `SubRooms` array is reconstructed on read and never stored in the room blob.

/** A stored subroom — the parsed JSON blob (its client shape). */
export type SubRoom = Record<string, unknown>

interface SubRoomRow {
	sub_room_id: number
	room_id: number
	data: string
	current_save_id: number | null
	staged_save_id: number | null
}

/** The columns every subroom read needs — the blob plus its two save pointers. */
const SUBROOM_COLUMNS = 'sub_room_id, room_id, data, current_save_id, staged_save_id'

/**
 * Materialize a subroom row into its client shape, with the columns authoritative.
 * `CurrentSave` is left undefined here and filled in by {@link attachCurrentSaves} — it
 * lives in `subroom_save`, and resolving it per row would be a query each. Callers must
 * go through the helpers below so the key is never missing: the client reads the scene
 * blob from `CurrentSave` and nowhere else, so a subroom without one loads nothing.
 */
const parseSubRoomRow = (row: SubRoomRow): SubRoom => ({
	...(JSON.parse(row.data) as SubRoom),
	SubRoomId: row.sub_room_id,
	RoomId: row.room_id,
	// Served from the column, not the blob — the creator's unpublished save (unused for
	// now, but the client expects the key present).
	StagedSubRoomDataSaveId: row.staged_save_id,
})

/**
 * Serialize a subroom for storage — drop the id/room columns and the save fields that
 * are columns or their own table, so the blob never holds a stale copy of either.
 */
const serializeSubRoom = (sub: SubRoom, roomId: number): string => {
	const {
		SubRoomId: _id,
		RoomId: _room,
		CurrentSave: _save,
		StagedSubRoomDataSaveId: _staged,
		...rest
	} = sub
	return JSON.stringify({ ...rest, RoomId: roomId })
}

/**
 * Serialize a room for a full-blob write, dropping the parts that belong to another table
 * so the blob can never hold a stale copy: hydrated `SubRooms` (the `subroom` table's job),
 * `Tags` (the `room_tag` table's job — see {@link setRoomTags}), and the engagement
 * counters, which are zeroed rather than dropped so the key stays present (the
 * `visits`/`cheers`/`favorites` columns' job — see {@link parseRow}).
 *
 * Because `Tags` is dropped here, a write that means to CHANGE a room's tags has to write
 * the table itself; passing a room with a new `Tags` array through this silently discards
 * it.
 */
const serializeRoom = (room: Room): string => {
	const { SubRooms: _subRooms, Tags: _tags, Badges: _badges, Stats: stats, ...rest } = room
	return JSON.stringify({ ...rest, Stats: storedStats(stats) })
}

/**
 * Fill in each subroom's `CurrentSave` from `subroom_save`, in ONE query for the whole
 * batch. Every subroom ends up with the key present — null when it points at no save
 * (never saved) or the pointer dangles — because the client's loader reads it directly.
 *
 * `rows` must line up with `subs` positionally; the pointer lives on the row, not the
 * parsed blob.
 */
async function attachCurrentSaves(
	db: D1Database,
	subs: SubRoom[],
	rows: SubRoomRow[]
): Promise<void> {
	const saveIds = [...new Set(rows.map((r) => r.current_save_id).filter((id) => id != null))]
	const byId = new Map<number, SubRoomDataSave>()
	if (saveIds.length > 0) {
		// Chunked: a save row carries a whole scene, so these are fetched by id rather than
		// scanned, and the id list can exceed D1's bound-parameter cap once enough rooms are
		// hydrated at once.
		const results = await selectInChunks<SubRoomSaveRow>(
			db,
			saveIds,
			(placeholders) =>
				`SELECT sub_room_data_save_id, sub_room_id, data FROM subroom_save
				 WHERE sub_room_data_save_id IN (${placeholders})`
		)
		for (const r of results) byId.set(r.sub_room_data_save_id, parseSubRoomSaveRow(r))
	}
	subs.forEach((sub, i) => {
		const id = rows[i]!.current_save_id
		sub.CurrentSave = id == null ? null : (byId.get(id) ?? null)
	})
	const saves = subs
		.map((sub) => sub.CurrentSave)
		.filter((save): save is SubRoomDataSave => typeof save === 'object' && save !== null)
	await attachStudioUnityAssets(db, saves)
}

/**
 * Fill `UnitySubAssets` on saves that point at a stored Studio build (rows of
 * `unity_asset`). Maker-pen saves have no `UnityAssetId` and are left untouched,
 * including their empty arrays; so is a save whose asset has no stored build —
 * the scene blob still loads, and the bundle list stays empty.
 *
 * Only Studio (UGC) builds are folded in — rows whose filename passes
 * {@link isStudioBundleFilename}. A FIRST-PARTY bundle loaded by hand under
 * `unity/<roomId>/` shares the table but must stay out of this list: the 2025 client
 * resolves it through `POST /unity_assets/baked/bulk` (which serves both kinds), and
 * handed it inline in this five-key shape it stops asking, cannot name the file, and
 * loads nothing. That broke every imported first-party room when the splice moved from
 * the Studio-only table to `unity_asset`.
 *
 * Only main bundles are listed. Stripped bundles stay in the bucket.
 */
export async function attachStudioUnityAssets(
	db: D1Database,
	saves: SubRoomDataSave[]
): Promise<void> {
	// The cloud build partitions prefab/material exports into separate bundles.
	// The main scene keeps external references to them, so the loader must receive
	// every export, including shared dependencies, before it instantiates the scene.
	const assetIds = (save: SubRoomDataSave): string[] => {
		if (typeof save.UnityAssetId !== 'string' || save.UnityAssetId === '') return []
		const serverData = save.ServerData as { Exports?: unknown } | null | undefined
		const exports = Array.isArray(serverData?.Exports) ? serverData.Exports : []
		const ids = new Set([save.UnityAssetId.toLowerCase()])
		for (const item of exports) {
			const id = (item as { u?: unknown } | null)?.u
			if (typeof id === 'string' && id !== '') ids.add(id.toLowerCase())
		}
		return [...ids]
	}
	const referencedIds = (save: SubRoomDataSave): string[] =>
		Array.isArray(save.ReferencedUnityAssetIds)
			? [
					...new Set(
						save.ReferencedUnityAssetIds.filter((id): id is string => typeof id === 'string').map(
							(id) => id.toLowerCase()
						)
					),
				]
			: []
	const ids = [...new Set(saves.flatMap((save) => [...assetIds(save), ...referencedIds(save)]))]
	if (ids.length === 0) return
	const builds = (await listUnityAssetBuilds(db, ids)).filter((build) =>
		isStudioBundleFilename(build.Filename)
	)
	// Rows come back with the id lowercased; a save may spell its GUID either way.
	const byAsset = new Map<string, UnityAssetBuild[]>()
	for (const build of builds) {
		const list = byAsset.get(build.UnityAssetId) ?? []
		list.push(build)
		byAsset.set(build.UnityAssetId, list)
	}
	for (const save of saves) {
		if (referencedIds(save).length > 0)
			save.ReferencedUnityAssets = bakedUnityAssets(
				referencedIds(save).flatMap((assetId) => byAsset.get(assetId) ?? [])
			)
		const id = save.UnityAssetId
		if (typeof id !== 'string') continue
		const baked = bakedUnityAssets(assetIds(save).flatMap((assetId) => byAsset.get(assetId) ?? []))
		if (baked.length === 0) continue
		save.UnitySubAssets = baked
	}
}

// ---- Room tags ------------------------------------------------------------
// A room's tags live in `room_tag`, not in the room blob (see ROOM_SCHEMA_DDL). The blob
// is stripped on write and the array is re-attached on read, so there is exactly one
// place a tag is stored — and a tag lookup is an indexed query rather than a scan that
// parses every room to ask.

/**
 * One of a room's tags, as the client's room DTO carries it.
 *
 * `IsPrimaryGenre` is PRESENT ONLY on the one tag that is the room's genre — the key is
 * left off the others rather than sent as false, which is the shape the client sends and
 * reads back. At most one tag in an array carries it; see {@link setPrimaryGenreTag}.
 */
export interface RoomTag {
	Tag: string
	Type: number
	IsPrimaryGenre?: boolean
}

interface RoomTagRow {
	room_id: number
	tag: string
	type: number
	is_primary_genre: number
}

/** Project a stored tag row, adding `IsPrimaryGenre` only when the row is flagged. */
function toRoomTag(row: RoomTagRow): RoomTag {
	const tag: RoomTag = { Tag: row.tag, Type: row.type }
	if (row.is_primary_genre) tag.IsPrimaryGenre = true
	return tag
}

/** Group tag rows by RoomId, preserving the order they arrived in (alphabetical by tag). */
function groupTags(rows: RoomTagRow[]): Map<number, RoomTag[]> {
	const byRoom = new Map<number, RoomTag[]>()
	for (const row of rows) {
		const list = byRoom.get(row.room_id) ?? []
		list.push(toRoomTag(row))
		byRoom.set(row.room_id, list)
	}
	return byRoom
}

/**
 * Every tag of the given rooms, keyed by RoomId, in ONE query however many rooms are
 * asked about. An empty `roomIds` reads nothing rather than every tag in the table — an
 * empty `IN ()` isn't valid SQL, and "no rooms asked about" must not come to mean "all of
 * them".
 *
 * The ids go in as ONE JSON array (`json_each`), so the list can be any length without
 * meeting D1's 100-parameter cap, and every lookup is a seek on the `(room_id, tag)` key:
 * the rows read are the rows returned. Past the cap this used to read the WHOLE table and
 * narrow in memory, so any caller with more than a hundred rooms pulled every tag on the
 * server to keep a handful — the query's row count tracked the table, not the request.
 *
 * Tags come back alphabetical, so a room's array is stable between reads.
 */
async function tagsByRoom(db: D1Database, roomIds: number[]): Promise<Map<number, RoomTag[]>> {
	const ids = [...new Set(roomIds)]
	if (ids.length === 0) return new Map()

	const { results } = await db
		.prepare(
			`SELECT room_id, tag, type, is_primary_genre FROM room_tag
			 WHERE room_id IN (SELECT value FROM json_each(?1)) ORDER BY tag`
		)
		.bind(JSON.stringify(ids))
		.all<RoomTagRow>()
	return groupTags(results)
}

/** The ids of every room carrying `tag` (lowercase), off the tag index. */
async function roomIdsWithTag(db: D1Database, tag: string): Promise<Set<number>> {
	const { results } = await db
		.prepare('SELECT room_id FROM room_tag WHERE tag = ?1')
		.bind(tag)
		.all<{ room_id: number }>()
	return new Set(results.map((row) => row.room_id))
}

/**
 * Fill in each room's `Tags` from `room_tag`. Every room ends up with the key PRESENT —
 * an empty array when it carries none — because the client's DTO has a non-nullable
 * `Tags` and the blob no longer supplies one.
 */
async function attachTags(db: D1Database, rooms: Room[]): Promise<void> {
	const byRoom = await tagsByRoom(db, [...new Set(rooms.map(roomIdOf))])
	for (const room of rooms) room.Tags = byRoom.get(roomIdOf(room)) ?? []
}

/**
 * Parse room rows AND attach their tags — the read every scan-then-rank feed starts from.
 *
 * Those feeds filter and sort BEFORE they hydrate (ranking a room doesn't need its
 * subrooms), but several of them rank ON tags, so the tags have to be present earlier than
 * {@link hydrateRooms} would put them. One extra query for the whole batch.
 */
async function parseAllWithTags(db: D1Database, rows: RoomRow[]): Promise<Room[]> {
	const rooms = parseAll(rows)
	await attachTags(db, rooms)
	return rooms
}

/**
 * Replace a room's tags with the given set, in one batch. A replace and not a merge: the
 * only writer ({@link toggleRoomTag}) computes the whole set it wants, so a removed tag is
 * a write with that tag left out.
 *
 * Tags are stored LOWERCASED, which is what makes the index a usable lookup key — every
 * comparison in this module was already case-insensitive, so nothing downstream can tell
 * the difference. A room tagged `Horror` reads back `horror`.
 */
export async function setRoomTags(db: D1Database, roomId: number, tags: RoomTag[]): Promise<void> {
	const statements = [db.prepare('DELETE FROM room_tag WHERE room_id = ?1').bind(roomId)]
	for (const { Tag, Type, IsPrimaryGenre } of tags) {
		statements.push(
			db
				.prepare(
					`INSERT INTO room_tag (room_id, tag, type, is_primary_genre) VALUES (?1, ?2, ?3, ?4)
					 ON CONFLICT (room_id, tag) DO UPDATE SET type = ?3, is_primary_genre = ?4`
				)
				.bind(roomId, String(Tag).toLowerCase(), Number(Type) || 0, IsPrimaryGenre ? 1 : 0)
		)
	}
	await db.batch(statements)
}

/**
 * A room read narrowed to the rooms carrying EVERY one of `tagSets` — one set per tag the
 * caller requires, and a room matches a set by carrying ANY tag in it (which is how a
 * term's aliases work: `#recroomoriginal` accepts `rro`). An empty `tagSets` reads every
 * room.
 *
 * A JOIN driven from `room_tag`, not a `WHERE EXISTS`, and the difference is the whole
 * point of the table. EXPLAIN QUERY PLAN on the seeded database:
 *
 *   WHERE EXISTS …   SCAN room · SEARCH room_tag USING COVERING INDEX (room_id=? AND tag=?)
 *   JOIN from tags   SEARCH room_tag USING INDEX idx_room_tag_tag (tag=?)
 *                    SEARCH room USING INDEX idx_rooms_room_id (room_id=?)
 *
 * The EXISTS form still walks every room and probes the index once per room, so it costs
 * what the in-memory filter it replaced cost. The join searches the tag index FIRST and
 * then looks up only the rooms that matched, which is what makes a category row cheap.
 */
function roomsByTagsQuery(
	tagSets: string[][],
	where = '',
	columns = ROOM_COLUMNS,
	derivedOnly: ReadonlySet<string> = new Set()
): { sql: string; binds: string[] } {
	// `where` is the caller's row filter ({@link LISTABLE_WHERE} or {@link SEARCHABLE_WHERE}) —
	// unqualified, which is unambiguous under either shape below. It matters most when
	// `tagSets` is EMPTY: that branch is the full scan every pseudo-tag feed still runs.
	const filter = where === '' ? '' : ` WHERE ${where}`
	if (tagSets.length === 0) return { sql: `SELECT ${columns} FROM room${filter}`, binds: [] }

	const binds: string[] = []
	const joins = tagSets.map((tags, i) => {
		// A tag in `derivedOnly` matches only its server-derived row (Type 2), not a user tag
		// of the same name.
		const matches = tags
			.map((tag, j) => {
				const n = `?${binds.length + j + 1}`
				return derivedOnly.has(tag)
					? `(tag = ${n} AND type = ${RoomTagType.derived})`
					: `tag = ${n}`
			})
			.join(' OR ')
		binds.push(...tags)
		return `JOIN (SELECT DISTINCT room_id FROM room_tag WHERE ${matches}) f${i}
		         ON f${i}.room_id = room.room_id`
	})
	// `data` and the counters — in {@link ROOM_COLUMNS} or the ranking stub
	// {@link RANK_COLUMNS} — are unqualified but unambiguous: the joined subqueries expose
	// only `room_id`. The table keeps its own name (no alias): ROOM_COLUMNS' boost count
	// correlates on `room.room_id`.
	return { sql: `SELECT ${columns} FROM room ${joins.join(' ')}${filter}`, binds }
}

/** Parse subroom rows and resolve their `CurrentSave` in one batched query. */
async function parseSubRoomRows(db: D1Database, rows: SubRoomRow[]): Promise<SubRoom[]> {
	const subs = rows.map(parseSubRoomRow)
	await attachCurrentSaves(db, subs, rows)
	return subs
}

/** Attach each room's `SubRooms` array from the subroom table (one batched query). */
async function attachSubRooms(db: D1Database, rooms: Room[]): Promise<void> {
	const ids = rooms.map((r) => Number(r.RoomId)).filter((n) => Number.isFinite(n))
	if (ids.length === 0) {
		for (const room of rooms) room.SubRooms = []
		return
	}
	// Chunked by ROOM, so all of a room's subrooms land in one chunk and stay ordered
	// relative to each other — the grouping below depends on that.
	const results = await selectInChunks<SubRoomRow>(
		db,
		ids,
		(placeholders) =>
			`SELECT ${SUBROOM_COLUMNS} FROM subroom
			 WHERE room_id IN (${placeholders}) ORDER BY sub_room_id`
	)
	const subs = await parseSubRoomRows(db, results)
	const byRoom = new Map<number, SubRoom[]>()
	results.forEach((r, i) => {
		const list = byRoom.get(r.room_id) ?? []
		list.push(subs[i]!)
		byRoom.set(r.room_id, list)
	})
	for (const room of rooms) room.SubRooms = byRoom.get(Number(room.RoomId)) ?? []
}

// ---- Room stats -----------------------------------------------------------
// A room's engagement counters are COLUMNS on `room` — `visits`, `cheers`, `favorites` —
// read back with the blob on every read ({@link parseRow}) and never stored in the blob
// (see {@link serializeRoom}). Each is bumped by an atomic `col = col ± 1` UPDATE: visits
// by {@link recordRoomVisit} on each matchmake, cheers/favorites by the toggles below in
// the same batch as the per-player `interaction` row they mirror. A read-modify-write of
// the whole room would drop concurrent updates, and deriving the counts by aggregating
// `interaction` on every read (as this once did) cost a scan of the whole table per feed
// call. `VisitorCount` (distinct visitors) is still left as the blob has it:
// `interaction.last_visited_at` is stamped per player by {@link recordRoomVisit}, but not
// for dorms, so counting those rows would under-report a dorm's visitors.

/** The counters a room starts life with (and the shape the client expects). */
const ZERO_STATS = { CheerCount: 0, FavoriteCount: 0, VisitorCount: 0, VisitCount: 0 }

/** A room's RoomId, or 0 for a blob without one. */
const roomIdOf = (room: Room): number => (typeof room.RoomId === 'number' ? room.RoomId : 0)

/**
 * The `Stats` object to persist: whatever the room carried, with the counters the
 * columns/tables own back at 0 so the blob never holds a stale copy of them.
 */
function storedStats(stats: unknown): Record<string, unknown> {
	const stored =
		typeof stats === 'object' && stats !== null ? (stats as Record<string, unknown>) : {}
	return { ...ZERO_STATS, ...stored, CheerCount: 0, FavoriteCount: 0, VisitCount: 0 }
}

/**
 * Count one visit to a room — the `match` worker calls this on every successful
 * matchmake (see its `enterRoom`), which is the only way a player ever lands in a room.
 * A blind `visits = visits + 1` UPDATE: it's the whole write, so simultaneous visitors
 * can't clobber each other, and an unknown room id simply matches nothing.
 *
 * Also stamps the player's `interaction.last_visited_at`, which is what puts the room on
 * their visited history ({@link getVisitedRooms}, `lists`' "recently visited" row). This
 * is the ONLY writer of `last_visited_at` — cheering or favoriting a room is not a visit.
 * Dorms are left off the history (they are counted in `visits`, but nobody needs their
 * own dorm, or a friend's, listed as somewhere they went). The upsert leaves
 * `cheered`/`favorited` alone; selecting from `room` keeps an unknown id from leaving
 * an orphan row behind.
 */
export async function recordRoomVisit(
	db: D1Database,
	roomId: number,
	playerId: number
): Promise<void> {
	await db.batch([
		db.prepare('UPDATE room SET visits = visits + 1 WHERE room_id = ?1').bind(roomId),
		db
			.prepare(
				`INSERT INTO interaction (player_id, room_id, last_visited_at)
				 SELECT ?1, room_id, ?3 FROM room WHERE room_id = ?2 AND is_dorm IS NOT 1
				 ON CONFLICT(player_id, room_id) DO UPDATE SET last_visited_at = excluded.last_visited_at`
			)
			.bind(playerId, roomId, new Date().toISOString()),
	])
}

/** Hydrate a single room's `SubRooms` and `Tags` (no-op for null). */
async function hydrateRoom(db: D1Database, room: Room | null): Promise<Room | null> {
	if (room) await hydrateRooms(db, [room])
	return room
}

/**
 * Hydrate many rooms' `SubRooms` and `Tags` (one batched query each). `Stats` needs no
 * hydration: its counters came off the row with the blob ({@link parseRow}).
 *
 * `Tags` is re-attached even for the feeds that already did so before ranking
 * ({@link parseAllWithTags}) — it is one query for the page slice and it guarantees the key
 * is present on every room this module hands out, whichever path produced it.
 */
async function hydrateRooms(db: D1Database, rooms: Room[]): Promise<Room[]> {
	for (const room of rooms) {
		// Studio enumerates these collections directly when opening Room Settings.
		for (const field of [
			'LoadScreens',
			'PromoImages',
			'PromoExternalContent',
			'RestrictedCircuitsAllowListNames',
		]) {
			if (!Array.isArray(room[field])) room[field] = []
		}
		// An unpublished room has no publication date; an empty string fails the
		// game's Nullable<DateTime> decoder and discards the entire owned-room list.
		if (room.PublishedAt === '') room.PublishedAt = null
	}
	await Promise.all([attachSubRooms(db, rooms), attachTags(db, rooms), attachBadges(db, rooms)])
	return rooms
}

/** Published room-linked image badges; drafts remain on the creator's Studio shelf. */
async function attachBadges(db: D1Database, rooms: Room[]): Promise<void> {
	if (!rooms.length) return
	// `custom_avatar_item` is owned by api's migrations (0015, badge index 0035), both long
	// applied to the shared database; this no longer probes `sqlite_master` for it.
	// Served by `idx_custom_avatar_item_badge_room` (api migrations/0035), a PARTIAL index over
	// `outfit_type = 1000` keyed by the `json_extract(data,'$.CustomBadgeMetadata.RoomId')`
	// expression. SQLite matches both only as written: drop or rephrase either term and this
	// goes back to scanning every custom avatar item on every room page.
	const rows = await db
		.prepare(
			"SELECT data,json_extract(data,'$.CustomBadgeMetadata.RoomId') AS room_id FROM custom_avatar_item WHERE outfit_type=1000 AND accessibility<>0 AND json_array_length(json_extract(data,'$.CurrentSaves'))>0 AND json_extract(data,'$.CustomBadgeMetadata.RoomId') IN (SELECT value FROM json_each(?))"
		)
		.bind(JSON.stringify(rooms.map(roomIdOf)))
		.all<{ data: string; room_id: number }>()
	for (const room of rooms)
		room.Badges = rows.results
			.filter((r) => r.room_id === roomIdOf(room))
			.map((r) => JSON.parse(r.data))
}

/** A single subroom of a room (columns authoritative), or null if it doesn't exist. */
export async function getSubRoom(
	db: D1Database,
	roomId: number,
	subRoomId: number
): Promise<SubRoom | null> {
	const row = await db
		.prepare(`SELECT ${SUBROOM_COLUMNS} FROM subroom WHERE room_id = ?1 AND sub_room_id = ?2`)
		.bind(roomId, subRoomId)
		.first<SubRoomRow>()
	if (!row) return null
	return (await parseSubRoomRows(db, [row]))[0]!
}

/** All of a room's subrooms, ordered by SubRoomId. */
export async function getSubRooms(db: D1Database, roomId: number): Promise<SubRoom[]> {
	const { results } = await db
		.prepare(`SELECT ${SUBROOM_COLUMNS} FROM subroom WHERE room_id = ?1 ORDER BY sub_room_id`)
		.bind(roomId)
		.all<SubRoomRow>()
	return parseSubRoomRows(db, results)
}

// ---- Subroom saves --------------------------------------------------------

interface SubRoomSaveRow {
	sub_room_data_save_id: number
	sub_room_id: number
	data: string
}

/** Materialize a save row, with its two id columns authoritative over the blob. */
const parseSubRoomSaveRow = (row: SubRoomSaveRow): SubRoomDataSave => ({
	...(JSON.parse(row.data) as SubRoomDataSave),
	SubRoomDataSaveId: row.sub_room_data_save_id,
	SubRoomId: row.sub_room_id,
})

/** Serialize a save for storage — the id columns own those two fields, not the blob. */
const serializeSubRoomSave = (save: SubRoomDataSave): string => {
	const { SubRoomDataSaveId: _id, SubRoomId: _sub, ...rest } = save
	return JSON.stringify(rest)
}

/**
 * Insert a save for a subroom, minting a fresh globally-unique `SubRoomDataSaveId` from
 * the table's autoincrement sequence. Returns the stored save with its new id.
 */
async function insertSubRoomSave(
	db: D1Database,
	subRoomId: number,
	save: SubRoomDataSave
): Promise<SubRoomDataSave> {
	const row = await db
		.prepare(
			'INSERT INTO subroom_save (sub_room_id, data) VALUES (?1, ?2) RETURNING sub_room_data_save_id'
		)
		.bind(subRoomId, serializeSubRoomSave(save))
		.first<{ sub_room_data_save_id: number }>()
	return { ...save, SubRoomDataSaveId: row!.sub_room_data_save_id, SubRoomId: subRoomId }
}

/**
 * A subroom's save history, newest first. Unlike the old inline model this is real
 * history: every save is its own row and none are overwritten.
 */
export async function getSubRoomSaves(
	db: D1Database,
	subRoomId: number
): Promise<SubRoomDataSave[]> {
	const { results } = await db
		.prepare(
			`SELECT sub_room_data_save_id, sub_room_id, data FROM subroom_save
			 WHERE sub_room_id = ?1 ORDER BY sub_room_data_save_id DESC`
		)
		.bind(subRoomId)
		.all<SubRoomSaveRow>()
	const saves = results.map(parseSubRoomSaveRow)
	await attachStudioUnityAssets(db, saves)
	return saves
}

/**
 * A single save by its globally-unique id, scoped to the subroom that owns it (the
 * restore-a-save lookup). Null when the id is unknown or belongs to another subroom.
 */
export async function getSubRoomSaveById(
	db: D1Database,
	subRoomId: number,
	saveId: number
): Promise<SubRoomDataSave | null> {
	const row = await db
		.prepare(
			`SELECT sub_room_data_save_id, sub_room_id, data FROM subroom_save
			 WHERE sub_room_data_save_id = ?1 AND sub_room_id = ?2`
		)
		.bind(saveId, subRoomId)
		.first<SubRoomSaveRow>()
	if (!row) return null
	const save = parseSubRoomSaveRow(row)
	await attachStudioUnityAssets(db, [save])
	return save
}

// ---- Subroom permissions --------------------------------------------------

/**
 * One entry of a subroom's permission table, in the client's own shape. `Value` is a
 * STRING, not a boolean — usually `"True"`/`"False"`, but a permission whose UI isn't a
 * True/False picker carries something else, so it is stored and served verbatim. `Role`
 * is the tier the entry applies to (0 = everyone, 30 = co-owner, …). `Permission` + `Role`
 * identify an entry: the client PUTs the pair it wants changed. A stored override also
 * supplies higher roles until a nearer override replaces it.
 *
 * `Override` is the row's own existence, not data: the client's UI is a checkbox ("is
 * this permission overridden in this subroom?") plus a True/False picker for the value.
 * Unchecking it means "fall back to the inherited value or default", so an entry arriving
 * with `Override: false` DELETES the stored row rather than storing anything. Every stored
 * entry reads back `Override: true` at its own role; inherited manager rows use `false`.
 * Those resolved values are not persisted as overrides.
 */
export interface RoomPermission {
	Permission: string
	Role: number
	Override: boolean
	Type: number
	Value: string
}

interface RoomPermissionRow {
	permission: string
	role: number
	type: number
	value: string
}

const toRoomPermission = (row: RoomPermissionRow): RoomPermission => ({
	// A stored row IS the override — the table holds nothing else (see RoomPermission).
	Override: true,
	Permission: row.permission,
	Role: row.role,
	Type: row.type,
	Value: row.value,
})

/** The permission columns, in the order the read/copy statements use. */
const PERMISSION_COLUMNS = 'permission, role, type, value'

/**
 * A subroom's stored permission overrides, in the order they were first set. Empty for a
 * subroom whose owner has never overridden a permission — the photon access token then
 * serves its defaults untouched.
 */
export async function getSubRoomPermissions(
	db: D1Database,
	subRoomId: number
): Promise<RoomPermission[]> {
	const { results } = await db
		.prepare(
			`SELECT ${PERMISSION_COLUMNS} FROM subroom_permission WHERE sub_room_id = ?1 ORDER BY rowid`
		)
		.bind(subRoomId)
		.all<RoomPermissionRow>()
	return results.map(toRoomPermission)
}

/**
 * Apply permission changes to a subroom, keyed by (`Permission`, `Role`). Only the pairs
 * supplied are touched; every other stored entry is left alone.
 *
 * `Override` decides which way an entry goes, mirroring the checkbox the client draws
 * next to each permission: true STORES the `Value` for that pair (overwriting whatever
 * was there), false CLEARS it, so the pair falls back to the inherited value or default.
 * Clearing a pair that was never overridden is a no-op.
 */
export async function setSubRoomPermissions(
	db: D1Database,
	subRoomId: number,
	permissions: RoomPermission[]
): Promise<void> {
	if (permissions.length === 0) return
	const upsert = db.prepare(
		`INSERT INTO subroom_permission (sub_room_id, ${PERMISSION_COLUMNS})
		 VALUES (?1, ?2, ?3, ?4, ?5)
		 ON CONFLICT (sub_room_id, permission, role)
		 DO UPDATE SET type = excluded.type, value = excluded.value`
	)
	const clear = db.prepare(
		'DELETE FROM subroom_permission WHERE sub_room_id = ?1 AND permission = ?2 AND role = ?3'
	)
	await db.batch(
		permissions.map((p) =>
			p.Override
				? upsert.bind(subRoomId, p.Permission, p.Role, p.Type, p.Value)
				: clear.bind(subRoomId, p.Permission, p.Role)
		)
	)
}

/**
 * Copy a subroom's permission overrides onto another subroom — a clone inherits the
 * source's permission table along with its scene and settings. Replaces any entry the
 * destination already holds for the same (permission, role).
 */
async function copySubRoomPermissions(
	db: D1Database,
	fromSubRoomId: number,
	toSubRoomId: number
): Promise<void> {
	await db
		.prepare(
			`INSERT OR REPLACE INTO subroom_permission (sub_room_id, ${PERMISSION_COLUMNS})
			 SELECT ?2, ${PERMISSION_COLUMNS} FROM subroom_permission WHERE sub_room_id = ?1`
		)
		.bind(fromSubRoomId, toSubRoomId)
		.run()
}

/**
 * Insert a subroom for a room, minting a fresh globally-unique SubRoomId from the
 * table's autoincrement sequence. Returns the created subroom (with its new id).
 */
export async function insertSubRoom(
	db: D1Database,
	roomId: number,
	sub: SubRoom
): Promise<SubRoom> {
	const row = await db
		.prepare('INSERT INTO subroom (room_id, data) VALUES (?1, ?2) RETURNING sub_room_id')
		.bind(roomId, serializeSubRoom(sub, roomId))
		.first<{ sub_room_id: number }>()
	const subRoomId = row!.sub_room_id
	const created: SubRoom = {
		...sub,
		SubRoomId: subRoomId,
		RoomId: roomId,
		CurrentSave: null,
		StagedSubRoomDataSaveId: null,
	}
	// The permission overrides follow the copy too — they live in their own table (keyed by
	// the id the caller is cloning FROM), so unlike the rest of the settings they aren't
	// carried by the blob. A fresh subroom (`createSubRoom`) passes no id and copies nothing.
	if (typeof sub.SubRoomId === 'number') {
		await copySubRoomPermissions(db, sub.SubRoomId, subRoomId)
	}
	// A copied subroom (room clone, subroom clone) carries the source's save. It gets its
	// OWN row — a save belongs to exactly one subroom, so sharing the source's id would
	// make the copy's content follow the source's future saves.
	if (sub.CurrentSave && typeof sub.CurrentSave === 'object') {
		const copy = await insertSubRoomSave(db, subRoomId, sub.CurrentSave as SubRoomDataSave)
		await setCurrentSave(db, subRoomId, Number(copy.SubRoomDataSaveId))
		created.CurrentSave = copy
	}
	return created
}

/** Overwrite a subroom's stored data blob in place. */
async function updateSubRoom(db: D1Database, sub: SubRoom): Promise<void> {
	await db
		.prepare('UPDATE subroom SET data = ?2 WHERE sub_room_id = ?1')
		.bind(sub.SubRoomId, serializeSubRoom(sub, Number(sub.RoomId)))
		.run()
}

/** Point a subroom at its live/published save, clearing any staged one. */
async function setCurrentSave(db: D1Database, subRoomId: number, saveId: number): Promise<void> {
	await db
		.prepare(
			'UPDATE subroom SET current_save_id = ?2, staged_save_id = NULL WHERE sub_room_id = ?1'
		)
		.bind(subRoomId, saveId)
		.run()
}

/**
 * Seed a room together with its subrooms — inserts the room (SubRooms stripped from the
 * blob) and each embedded subroom into the `subroom` table, preserving explicit ids. Any
 * subroom carrying a `CurrentSave` gets it inserted into `subroom_save` and pointed at,
 * mirroring 0008's backfill the way this mirrors 0007's.
 */
export async function seedRoomWithSubRooms(db: D1Database, room: Room): Promise<void> {
	const roomId = Number(room.RoomId)
	const subRooms = Array.isArray(room.SubRooms) ? (room.SubRooms as SubRoom[]) : []
	const seeded = await db
		.prepare('INSERT OR IGNORE INTO room (data) VALUES (?1)')
		.bind(serializeRoom(room))
		.run()
	// An ignored insert left an existing room in place; its role rows are already its own.
	if (seeded.meta.changes > 0) await db.batch(roomRoleWrites(db, roomId, room))
	// `serializeRoom` drops `Tags`, so a seeded room's tags have to go to their own table or
	// they'd vanish — the same step the migration's backfill takes for the imported rooms.
	if (Array.isArray(room.Tags) && room.Tags.length > 0) {
		await setRoomTags(db, roomId, room.Tags as RoomTag[])
	}
	for (const sub of subRooms) {
		const subRoomId = Number(sub.SubRoomId)
		await db
			.prepare('INSERT INTO subroom (sub_room_id, room_id, data) VALUES (?1, ?2, ?3)')
			.bind(subRoomId, roomId, serializeSubRoom(sub, roomId))
			.run()
		const seeded = sub.CurrentSave ?? legacySubRoomSave(sub)
		if (seeded && typeof seeded === 'object') {
			const save = await insertSubRoomSave(db, subRoomId, seeded as SubRoomDataSave)
			await setCurrentSave(db, subRoomId, Number(save.SubRoomDataSaveId))
		}
	}
}

/** Look up a single room by its RoomId. */
export async function getRoomById(db: D1Database, roomId: number): Promise<Room | null> {
	return hydrateRoom(
		db,
		parseOne(
			await db
				.prepare(`SELECT ${ROOM_COLUMNS} FROM room WHERE room_id = ?1`)
				.bind(roomId)
				.first<RoomRow>()
		)
	)
}

/**
 * Delete a room and every player's interaction (cheer/favorite/visit) with it, in one
 * batch. Deliberately leaves transient `room_instance`/`presence` rows (they expire on
 * their own) and any images taken in the room (those live in the api/img world and
 * outlast the room). Authorization and removing the room image from the CDN bucket are
 * the caller's responsibility (see the DELETE /rooms/:id route).
 */
export async function deleteRoom(db: D1Database, roomId: number): Promise<void> {
	await db.batch([
		db.prepare('DELETE FROM room WHERE room_id = ?1').bind(roomId),
		db.prepare('DELETE FROM interaction WHERE room_id = ?1').bind(roomId),
		// Tag rows outlive the blob otherwise, and would keep answering `#tag` searches and
		// category rows for a room nobody can open.
		db.prepare('DELETE FROM room_tag WHERE room_id = ?1').bind(roomId),
		db.prepare('DELETE FROM room_role WHERE room_id = ?1').bind(roomId),
		// Saves and permission overrides first — both are keyed by subroom, so they'd be
		// unreachable once the subrooms themselves are gone.
		db
			.prepare(
				'DELETE FROM subroom_save WHERE sub_room_id IN (SELECT sub_room_id FROM subroom WHERE room_id = ?1)'
			)
			.bind(roomId),
		db
			.prepare(
				'DELETE FROM subroom_permission WHERE sub_room_id IN (SELECT sub_room_id FROM subroom WHERE room_id = ?1)'
			)
			.bind(roomId),
		db.prepare('DELETE FROM subroom WHERE room_id = ?1').bind(roomId),
		// Each player's saved data for the room: keyed by room, meaningless without it.
		db.prepare('DELETE FROM playerdata WHERE room_id = ?1').bind(roomId),
	])
}

/** Look up a single room by name (case-insensitive exact match). */
export async function getRoomByName(db: D1Database, name: string): Promise<Room | null> {
	return hydrateRoom(
		db,
		parseOne(
			await db
				.prepare(`SELECT ${ROOM_COLUMNS} FROM room WHERE name_lower = ?1`)
				.bind(name.toLowerCase())
				.first<RoomRow>()
		)
	)
}

/**
 * Look up multiple rooms by RoomId.
 *
 * Every id is bound into one query, so the CALLER must keep the list within D1's cap of 100
 * bound parameters — `/rooms/bulk` rejects a longer request with a 400 rather than have this
 * split it, since a client asking about more than a hundred rooms at once is asking the
 * wrong question.
 */
export async function getRoomsByIds(db: D1Database, ids: number[]): Promise<Room[]> {
	if (ids.length === 0) return []
	const placeholders = ids.map((_, i) => `?${i + 1}`).join(',')
	const { results } = await db
		.prepare(`SELECT ${ROOM_COLUMNS} FROM room WHERE room_id IN (${placeholders})`)
		.bind(...ids)
		.all<RoomRow>()
	return hydrateRooms(db, parseAll(results))
}

/** All rooms created by an account (e.g. their dorm). */
export async function getRoomsByCreator(db: D1Database, accountId: number): Promise<Room[]> {
	const { results } = await db
		.prepare(`SELECT ${ROOM_COLUMNS} FROM room WHERE creator_account_id = ?1`)
		.bind(accountId)
		.all<RoomRow>()
	return hydrateRooms(db, parseAll(results))
}

/**
 * How many rooms an account has made, for the per-account room cap. The player's own
 * dorm (their oldest, see {@link getDormRoom}) doesn't count: every player gets one
 * auto-provisioned, so counting it would silently cost them a slot they never asked for.
 * Custom dorms cloned after it DO count, or cloning dorms would get around the cap.
 */
export async function countRoomsByCreator(db: D1Database, accountId: number): Promise<number> {
	const row = await db
		.prepare(
			`SELECT COUNT(*) AS n FROM room
			 WHERE creator_account_id = ?1
			   AND room_id <> COALESCE(
			     (SELECT MIN(room_id) FROM room WHERE creator_account_id = ?1 AND is_dorm = 1), -1
			   )`
		)
		.bind(accountId)
		.first<{ n: number }>()
	return row?.n ?? 0
}

/**
 * Every room an account works on: the ones it CREATED plus the ones whose `Roles` name it
 * (Host, Moderator or CoOwner). Every role tier counts, unlike {@link canManageRoom}'s
 * owner-or-co-owner gate: this is "you have a job in this room", not "you may administer
 * it".
 *
 * The creator half used to be excluded — a room's `Roles` carries its creator too, and the
 * client shows "rooms you own" and "rooms you contribute to" as separate lists, so the
 * exclusion kept this from repeating `createdby/me`. It also made the list EMPTY for every
 * account that had only ever built its own rooms, which is most of them, so the screen
 * behind it showed nothing at all. Repeating `createdby/me` is the better failure, and
 * overlap is what a client that renders one list wants anyway.
 *
 * Dorms stay out unless `includeDorms` is set. `contributedby/me` sets it: the 2026 client
 * lists a player's dorms there — the provisioned one and any custom dorm cloned from a
 * dorm — while `ownedby/me` leaves them out. A room matching BOTH halves appears once — the
 * roles half is an EXISTS, not a join.
 *
 * A PENDING invite is not a job. An invited account holds a `Roles` entry with `Role` 0 and
 * the offer on `InvitedRole` until it answers, and that entry is indexed like any other —
 * so without the `role <> 0` guard a room showed up in the player's "rooms you contribute
 * to" (and, through `ownedby/me`, was considered for "rooms you own") the moment someone
 * invited them, before they had accepted anything. Only a held role counts here; the offer
 * reaches them as a `RoomCoOwnerInvited` message, not through this list.
 *
 * Roles live inside the room blob, so the roles half reads `room_role`, the trigger-kept
 * index of them, rather than a `json_each` over every room's `$.Roles` (which scanned and
 * parsed the whole table on every call). Both halves are index lookups, and SQLite runs
 * the OR as a multi-index union. A room with no `Roles` has no `room_role` rows, so it
 * only reaches the list if the account created it.
 */
export async function getContributedRooms(
	db: D1Database,
	accountId: number,
	{ includeDorms = false }: { includeDorms?: boolean } = {}
): Promise<Room[]> {
	const { results } = await db
		.prepare(
			`SELECT ${ROOM_COLUMNS} FROM room
			 WHERE (creator_account_id = ?1
			    OR room_id IN (SELECT room_id FROM room_role WHERE account_id = ?1 AND role <> ?2))
			   AND (?3 OR is_dorm IS NOT 1)`
		)
		.bind(accountId, Role.None, includeDorms ? 1 : 0)
		.all<RoomRow>()
	return hydrateRooms(db, parseAll(results))
}

/**
 * An account's public, non-dorm rooms — the publicly viewable "rooms owned by
 * <player>" list (excludes private rooms, dorms, and list-excluded rooms).
 */
export async function getPublicRoomsByCreator(db: D1Database, accountId: number): Promise<Room[]> {
	return (await getRoomsByCreator(db, accountId)).filter(isListable)
}

/**
 * A player's showcased rooms (`GET /showcase/:playerId`), in the order they picked them.
 * Picked rooms are checked when they're SET (www's account page), but a room can stop being
 * public afterwards, so the read narrows to {@link isListable} as every public profile list
 * does — otherwise making a showcased room private would leave it on the profile. Only rooms
 * the player CREATED are served (the write refuses others too; this keeps the rule in one
 * read even if a row was written some other way). A room deleted since is simply absent.
 */
export async function getShowcasedRooms(db: D1Database, accountId: number): Promise<Room[]> {
	const ids = await getShowcasedRoomIds(db, accountId)
	const byId = new Map((await getRoomsByIds(db, ids)).map((r) => [roomIdOf(r), r] as const))
	return ids.flatMap((id) => {
		const room = byId.get(id)
		return room && room.CreatorAccountId === accountId && isListable(room) ? [room] : []
	})
}

/**
 * Rooms the player has favorited (interaction.favorited = 1), most recently
 * interacted first. Joins the `interaction` table to `rooms`, so a favorited room
 * no longer in D1 is simply absent. Paginated via skip/take; returns a bare array
 * of rooms (the client's room-source loaders expect a plain list).
 */
export async function getFavoritedRooms(
	db: D1Database,
	playerId: number,
	skip: number,
	take: number
): Promise<Room[]> {
	const { results } = await db
		.prepare(
			`SELECT r.data AS data, ${COUNTER_COLUMNS}
			 FROM interaction i
			 JOIN room r ON r.room_id = i.room_id
			 WHERE i.player_id = ?1 AND i.favorited = 1
			 ORDER BY i.last_visited_at DESC`
		)
		.bind(playerId)
		.all<RoomRow>()
	return hydrateRooms(db, parseAll(results).slice(skip, skip + take))
}

/**
 * Rooms the player has visited (an interaction row with a `last_visited_at`),
 * most recent first. Like favorites, it joins `interaction` to `rooms`, so a
 * visited room no longer in D1 is simply absent. Paginated via skip/take; returns
 * a bare array of rooms (the client's room-source loaders expect a plain list).
 *
 * This is the player's OWN history, so nothing is filtered on accessibility: their
 * unpublished builds and the private rooms they were invited into are theirs to see.
 * Anyone else reading it goes through {@link getPublicVisitedRooms}.
 */
export async function getVisitedRooms(
	db: D1Database,
	playerId: number,
	skip: number,
	take: number
): Promise<Room[]> {
	return visitedRooms(db, playerId, skip, take, false)
}

/**
 * {@link getVisitedRooms} as SOMEONE ELSE sees it — a profile, which anyone can look at —
 * narrowed to the rooms that are {@link isListable}. A visit is recorded wherever the
 * player goes, so the unfiltered history names their unpublished builds and the private
 * rooms they were invited into; served whole, it leaked a room its owner hasn't released,
 * and `GET /rooms/{id}` is not gated, so the id alone was enough to open it. The same test
 * the public `ownedby/{accountId}` profile list applies, so a room that opted out of lists
 * stays off this one too. Paginated AFTER the filter, so a page is a page of what the
 * viewer may see rather than a page with holes in it.
 */
export async function getPublicVisitedRooms(
	db: D1Database,
	playerId: number,
	skip: number,
	take: number
): Promise<Room[]> {
	return visitedRooms(db, playerId, skip, take, true)
}

async function visitedRooms(
	db: D1Database,
	playerId: number,
	skip: number,
	take: number,
	listableOnly: boolean
): Promise<Room[]> {
	// The listable predicate is pushed down (see LISTABLE_WHERE) so the blobs of the
	// rooms a friend may not see never leave D1; the in-memory filter remains the
	// definition, as everywhere else it is used.
	const { results } = await db
		.prepare(
			`SELECT r.data AS data, ${COUNTER_COLUMNS}
			 FROM interaction i
			 JOIN room r ON r.room_id = i.room_id
			 WHERE i.player_id = ?1 AND i.last_visited_at IS NOT NULL
			 ${listableOnly ? `AND r.${LISTABLE_WHERE.replaceAll(' AND ', ' AND r.')}` : ''}
			 ORDER BY i.last_visited_at DESC`
		)
		.bind(playerId)
		.all<RoomRow>()
	const rooms = parseAll(results)
	const visible = listableOnly ? rooms.filter(isListable) : rooms
	return hydrateRooms(db, visible.slice(skip, skip + take))
}

/**
 * How many distinct rooms the player has visited — the length of the full
 * {@link getVisitedRooms} list, counted in D1. Joined to `room` like the list, so a
 * visited room that no longer exists is not counted.
 */
export async function countVisitedRooms(db: D1Database, playerId: number): Promise<number> {
	const row = await db
		.prepare(
			`SELECT COUNT(DISTINCT i.room_id) AS n
			 FROM interaction i
			 JOIN room r ON r.room_id = i.room_id
			 WHERE i.player_id = ?1 AND i.last_visited_at IS NOT NULL`
		)
		.bind(playerId)
		.first<{ n: number }>()
	return row?.n ?? 0
}

/** A player's interaction state with a room. */
export interface Interaction {
	Cheered: boolean
	Favorited: boolean
}

interface InteractionRow {
	cheered: number
	favorited: number
}

const toInteraction = (row: InteractionRow | null): Interaction => ({
	Cheered: row?.cheered === 1,
	Favorited: row?.favorited === 1,
})

/** Read a player's interaction with a room (defaults to all-false if none). */
export async function getInteraction(
	db: D1Database,
	playerId: number,
	roomId: number
): Promise<Interaction> {
	return toInteraction(
		await db
			.prepare('SELECT cheered, favorited FROM interaction WHERE player_id = ?1 AND room_id = ?2')
			.bind(playerId, roomId)
			.first<InteractionRow>()
	)
}

/** The `room` counter column an interaction flag is mirrored by. */
const COUNTER_OF = { cheered: 'cheers', favorited: 'favorites' } as const

/**
 * Upsert+toggle a single boolean column, returning the resulting interaction.
 *
 * The room's counter moves in the same batch (one transaction): +1 when the flag lands
 * on, -1 when it lands off, read off the row the first statement just wrote. A toggle
 * always flips the flag, so the move is always exactly one, and concurrent toggles by
 * different players each apply their own ±1 to the column rather than racing a
 * read-modify-write. An unknown room id simply matches no `room` row.
 */
async function toggleInteraction(
	db: D1Database,
	playerId: number,
	roomId: number,
	column: 'cheered' | 'favorited'
): Promise<Interaction> {
	// First interaction defaults the toggled column to 1; subsequent calls flip it.
	// `last_visited_at` is left alone: only entering the room ({@link recordRoomVisit})
	// is a visit, so a room cheered from a feed stays off the visited history.
	const counter = COUNTER_OF[column]
	const [toggled] = await db.batch<InteractionRow>([
		db
			.prepare(
				`INSERT INTO interaction (player_id, room_id, ${column})
				 VALUES (?1, ?2, 1)
				 ON CONFLICT(player_id, room_id)
				 DO UPDATE SET ${column} = NOT ${column}
				 RETURNING cheered, favorited`
			)
			.bind(playerId, roomId),
		db
			.prepare(
				`UPDATE room SET ${counter} = ${counter} + CASE
				   WHEN (SELECT ${column} FROM interaction WHERE player_id = ?1 AND room_id = ?2) = 1
				   THEN 1 ELSE -1 END
				 WHERE room_id = ?2`
			)
			.bind(playerId, roomId),
	])
	return toInteraction(toggled?.results[0] ?? null)
}

/** Toggle the player's cheer on a room, returning the resulting interaction. */
export async function toggleCheer(
	db: D1Database,
	playerId: number,
	roomId: number
): Promise<Interaction> {
	return toggleInteraction(db, playerId, roomId, 'cheered')
}

/** Toggle the player's favorite on a room, returning the resulting interaction. */
export async function toggleFavorite(
	db: D1Database,
	playerId: number,
	roomId: number
): Promise<Interaction> {
	return toggleInteraction(db, playerId, roomId, 'favorited')
}

/**
 * Explicitly clear a single interaction flag on a room (the DELETE counterpart to
 * the cheer/favorite toggles). Idempotent: only clears an existing interaction row
 * and never creates one, so clearing a flag on a room the player never interacted
 * with doesn't add a spurious visited/favorited entry. Returns the interaction.
 *
 * The room's counter drops by one only when the flag was actually set — a repeated
 * DELETE changes nothing and must not count down again — so the decrement is gated on
 * the flag's state BEFORE the clear, in the same batch.
 */
async function clearInteraction(
	db: D1Database,
	playerId: number,
	roomId: number,
	column: 'cheered' | 'favorited'
): Promise<Interaction> {
	const counter = COUNTER_OF[column]
	const [, , after] = await db.batch<InteractionRow>([
		db
			.prepare(
				`UPDATE room SET ${counter} = ${counter} - 1
				 WHERE room_id = ?2 AND EXISTS (
				   SELECT 1 FROM interaction WHERE player_id = ?1 AND room_id = ?2 AND ${column} = 1
				 )`
			)
			.bind(playerId, roomId),
		db
			.prepare(`UPDATE interaction SET ${column} = 0 WHERE player_id = ?1 AND room_id = ?2`)
			.bind(playerId, roomId),
		db
			.prepare('SELECT cheered, favorited FROM interaction WHERE player_id = ?1 AND room_id = ?2')
			.bind(playerId, roomId),
	])
	return toInteraction(after?.results[0] ?? null)
}

/** Clear the player's cheer on a room (DELETE cheer), returning the interaction. */
export async function removeCheer(
	db: D1Database,
	playerId: number,
	roomId: number
): Promise<Interaction> {
	return clearInteraction(db, playerId, roomId, 'cheered')
}

/** Clear the player's favorite on a room (DELETE favorite), returning the interaction. */
export async function removeFavorite(
	db: D1Database,
	playerId: number,
	roomId: number
): Promise<Interaction> {
	return clearInteraction(db, playerId, roomId, 'favorited')
}

/**
 * Search-tag aliases: a queried `#tag` also matches these stored tag names.
 * The client's pinned filters don't always match how rooms are tagged (e.g. it
 * searches `recroomoriginal`, but rooms are tagged `rro`).
 */
const TAG_ALIASES: Record<string, string[]> = {
	recroomoriginal: ['rro'],
}

/**
 * Tags the hot feed honours only in their server-derived form (Type 2). Anyone can add a
 * user tag named `rro` to their room; that must not put it in the RRO chip's feed.
 */
const DERIVED_ONLY_FEED_TAGS: ReadonlySet<string> = new Set(['rro'])

/** A room's tag names, lowercased (empty when it has no Tags array). */
function roomTags(room: Room): string[] {
	const tags = room.Tags
	if (!Array.isArray(tags)) return []
	return tags
		.map((t) => (t as Record<string, unknown> | null)?.Tag)
		.filter((v): v is string => typeof v === 'string')
		.map((v) => v.toLowerCase())
}

/**
 * Search public, non-dorm rooms not opted out of search. The query is split into terms
 * (space/`+`): `#tag` terms match the room's Tags; plain terms match the room name
 * (substring). All terms must match. Returns a paginated `{ Results, TotalResults }`.
 * The rows narrow in SQL — public, non-dorm, searchable ({@link SEARCHABLE_WHERE}), and by
 * name where SQL can — over ids and names alone; only the served page's rooms are read.
 *
 * `#community` is the one tag term that isn't a tag lookup — see {@link COMMUNITY_TAG}.
 */
export async function searchRooms(
	db: D1Database,
	query: string,
	skip: number,
	take: number
): Promise<{ Results: Room[]; TotalResults: number }> {
	const q = query.trim().toLowerCase()
	if (q === '') return { Results: [], TotalResults: 0 }
	const terms = q.split(/[\s+]+/).filter(Boolean)

	// The `#tag` terms narrow in SQL — one EXISTS per term, because a room has to carry
	// EVERY tag asked for, and each term expands to its aliases (`#recroomoriginal` accepts
	// `rro`). Only the rooms that survive have their blobs read, which is what `room_tag` is
	// for: a tag search no longer parses every room in the database to ask.
	//
	// `#community` is held out of that query: no room CARRIES the tag (the browse chip posts
	// it to the hot feed as a pseudo-tag, and the search box sends the same term), so asking
	// `room_tag` for it matches nothing and the whole search comes back empty. It filters on
	// who MADE the room instead, below.
	const tagTerms = terms.filter((t) => t.startsWith('#')).map((t) => t.slice(1))
	const communityOnly = tagTerms.includes(COMMUNITY_TAG)
	const tagSets = tagTerms
		.filter((tag) => tag !== COMMUNITY_TAG)
		.map((tag) => [tag, ...(TAG_ALIASES[tag] ?? [])])
	// The scan reads three small values per room, never the blob: it has to consider every
	// searchable room, but serves one page of them, and selecting `data` (plus the boost
	// subquery, once per row) shipped ~4.7MB out of D1 on every search to serve a dozen rooms.
	// The page's full rooms are read by id afterwards ({@link loadRankedPage}).
	//
	// The plain terms narrow in SQL where they can. An ASCII term is a substring test on
	// `name_lower`, which `idx_room_search_name` holds for exactly the searchable rooms, so
	// the hinted scan walks index entries alone and reads a row only for a name that matched
	// (~1ms against ~45-90ms on production). The planner won't pick that index by itself —
	// it prefers `idx_room_public`, which reads every row to test `exclude_from_search` — so
	// the hint is load-bearing wherever it appears below; it is left off under a tag join,
	// where the tags drive.
	// A NON-ASCII term can't narrow there: `name_lower` is SQLite's `lower()`, which folds
	// ASCII only, so `café` would miss a room named `CAFÉ` that the match below finds.
	const nameTerms = terms.filter((t) => !t.startsWith('#'))
	const sqlTerms = nameTerms.filter((t) => /^[\x20-\x7e]+$/.test(t))
	const tagBindCount = tagSets.flat().length
	const where = [
		SEARCHABLE_WHERE,
		...sqlTerms.map((_, i) => `instr(name_lower, ?${tagBindCount + i + 1}) > 0`),
	].join(' AND ')

	// The usual search — plain ASCII terms, nothing else — never leaves the index until it
	// knows its page. Both statements walk `idx_room_search_name` entries alone: one counts
	// the matches, the other orders them by rowid (which every index entry carries) and
	// reads a row only for the `take` it serves. A one-letter search matches most of the
	// catalogue, and used to fetch every one of those rows to serve a hundred.
	if (tagSets.length === 0 && !communityOnly && sqlTerms.length === nameTerms.length) {
		const limit = `?${sqlTerms.length + 1} OFFSET ?${sqlTerms.length + 2}`
		const [count, page] = await db.batch<RoomRow & { total: number }>([
			db
				.prepare(
					`SELECT COUNT(*) AS total FROM room INDEXED BY idx_room_search_name WHERE ${where}`
				)
				.bind(...sqlTerms),
			db
				.prepare(
					`SELECT ${ROOM_COLUMNS} FROM room WHERE room.rowid IN (
					   SELECT s.rowid FROM room s INDEXED BY idx_room_search_name
					   WHERE ${where} ORDER BY s.rowid LIMIT ${limit})
					 ORDER BY room.rowid`
				)
				.bind(...sqlTerms, Math.max(0, take), Math.max(0, skip)),
		])
		return {
			Results: await hydrateRooms(db, parseAll(page.results).filter(isSearchable)),
			TotalResults: count.results[0]?.total ?? 0,
		}
	}

	// Everything else — a tag term, `#community`, a non-ASCII term — scans ids and names and
	// pages in memory; the tag joins keep those scans to the rooms carrying the tags.
	const columns = 'room.rowid AS row_id, room.room_id AS room_id, name, creator_account_id'
	const { sql, binds } =
		tagSets.length === 0 && sqlTerms.length > 0
			? {
					sql: `SELECT ${columns} FROM room INDEXED BY idx_room_search_name WHERE ${where}`,
					binds: [] as string[],
				}
			: roomsByTagsQuery(tagSets, where, columns)
	const { results } = await db
		.prepare(sql)
		.bind(...binds, ...sqlTerms)
		.all<{
			row_id: number
			room_id: number
			name: string | null
			creator_account_id: number | null
		}>()
	let rows = results

	// The same test the hot feed's `community` chip applies: every room a player made, which
	// is every room the Coach account doesn't own. It narrows the other terms rather than
	// replacing them, so `#community horror` is still a name search within player-made rooms.
	if (communityOnly) rows = rows.filter((r) => r.creator_account_id !== COACH_ACCOUNT_ID)

	// Every plain term is matched here, in JS's lowercasing — the definition of a match. For
	// the ASCII terms the SQL above already agreed; this is what catches the rest.
	for (const term of nameTerms) {
		rows = rows.filter((r) => typeof r.name === 'string' && r.name.toLowerCase().includes(term))
	}

	// By rowid, like the page above: the order rooms were made in, which is room id order
	// but for rooms inserted with an id of their own choosing.
	const ids = rows.sort((x, y) => x.row_id - y.row_id).map((r) => r.room_id)
	const page = ids.slice(skip, skip + take).map((RoomId): Room => ({ RoomId }))
	return {
		Results: await hydrateRooms(db, (await loadRankedPage(db, page)).filter(isSearchable)),
		TotalResults: ids.length,
	}
}

/**
 * Searchable rooms whose name BEGINS with `query` (case-insensitive), alphabetically, at
 * most `take` — the website's header search, which asks on every pause in typing.
 *
 * Not {@link searchRooms}: that is the game's search, a SUBSTRING match no index can
 * serve, so it reads every searchable room per call. This is a range seek on
 * `idx_room_search_name` (`>= q AND < q+U+10FFFF`, as {@link searchAccounts} does for
 * usernames), walked in `ORDER BY` order so the LIMIT stops it: D1 bills `take` rows
 * however many rooms exist. The WHERE repeats {@link SEARCHABLE_WHERE} verbatim because
 * SQLite only uses a partial index whose condition the query states; the LIKE is a
 * residual so `%`/`_` match literally. Rooms come back un-hydrated (no subrooms, tags or
 * badges) — the caller draws a name, a picture and the counters.
 */
export async function searchRoomsByName(
	db: D1Database,
	query: string,
	take: number
): Promise<Room[]> {
	const q = query.trim().toLowerCase()
	if (q === '' || take <= 0) return []
	const { results } = await db
		.prepare(
			`SELECT ${ROOM_COLUMNS} FROM room
			 WHERE ${SEARCHABLE_WHERE}
			   AND name_lower >= ?1 AND name_lower < ?2 AND name_lower LIKE ?3 ESCAPE '\\'
			 ORDER BY name_lower LIMIT ?4`
		)
		.bind(q, prefixUpperBound(q), `${escapeLike(q)}%`, take)
		.all<RoomRow>()
	return parseAll(results).filter(isSearchable)
}

/**
 * Search suggestions for the box the player is typing in
 * (`GET /rooms/autocomplete_search`) — a list of plain STRINGS, not rooms.
 *
 * Everything suggested is something the follow-up `/rooms/search` will actually find,
 * which is the whole point of the endpoint: a suggestion that returns nothing is worse
 * than no suggestion. So the candidates are drawn from the two things that search matches
 * — room NAMES for a plain term, and TAGS for a `#tag` term — over the same public,
 * non-dorm, searchable rooms search itself considers. A room opted out of search must not
 * leak through its name or tags as a suggestion. A tag comes back with its `#` so
 * submitting the suggestion verbatim searches by tag rather than for a room called "horror".
 *
 * A query starting with `#` is asking for tags, so only tags are suggested. Otherwise
 * names come first (the likelier intent), then tags, and within each, matches that START
 * with the query come before ones that merely contain it. Ties break alphabetically, so
 * the same query always suggests the same things in the same order.
 *
 * Matching is case-insensitive and suggestions are de-duplicated case-insensitively, but
 * each is returned in its stored casing — search doesn't care, and the player reads these.
 * Narrowed in SQL to the same rooms {@link searchRooms} considers; the matching itself is
 * in memory, like search's.
 */
export async function autocompleteRoomSearch(
	db: D1Database,
	query: string,
	take: number
): Promise<string[]> {
	const q = query.trim().toLowerCase()
	if (q === '' || take <= 0) return []

	const { results } = await db
		.prepare(`SELECT ${ROOM_COLUMNS} FROM room WHERE ${SEARCHABLE_WHERE}`)
		.all<RoomRow>()
	// Tags attached up front: suggestions are drawn from them, and this reads every candidate
	// room for its NAME regardless, so the tags cost one extra query rather than a second scan.
	const rooms = (await parseAllWithTags(db, results)).filter(isSearchable)

	const tagQuery = q.startsWith('#')
	const term = tagQuery ? q.slice(1) : q
	if (term === '') return []

	// Lowercased suggestion → [rank, the casing to serve it in]. Lower rank sorts first.
	const found = new Map<string, [number, string]>()
	const offer = (value: string, rank: number) => {
		const key = value.toLowerCase()
		const existing = found.get(key)
		if (existing === undefined || existing[0] > rank) found.set(key, [rank, value])
	}

	for (const room of rooms) {
		if (!tagQuery && typeof room.Name === 'string') {
			const name = room.Name.toLowerCase()
			if (name.startsWith(term)) offer(room.Name, 0)
			else if (name.includes(term)) offer(room.Name, 1)
		}
		for (const tag of roomTags(room)) {
			if (tag.startsWith(term)) offer(`#${tag}`, tagQuery ? 0 : 2)
			else if (tag.includes(term)) offer(`#${tag}`, tagQuery ? 1 : 3)
		}
	}

	return [...found.entries()]
		.sort(([aKey, [aRank]], [bKey, [bRank]]) => aRank - bRank || aKey.localeCompare(bKey))
		.slice(0, take)
		.map(([, [, value]]) => value)
}

/**
 * Engagement score used to order the hot feed (cheers weigh most, then favorites).
 * Cheers/favorites are the `room` row's counter columns, which {@link parseRow} folds
 * into `Stats` on a ranking stub as on a full room, so the feeds rank without reading
 * `interaction` at all.
 */
function hotScore(room: Room): number {
	const stats = room.Stats as Record<string, unknown> | null | undefined
	const count = (key: string): number => (typeof stats?.[key] === 'number' ? stats[key] : 0)
	return count('CheerCount') * 3 + count('FavoriteCount') * 2 + count('VisitorCount')
}

/**
 * The browse screen's "New" chip posts `tag=new` to the hot feed, but `new` is a
 * PSEUDO-tag: no room carries it. It means "recently created by a player", so it
 * selects the non-RRO rooms and orders them newest-first instead of by population.
 */
const NEW_TAG = 'new'

/**
 * The browse screen's "Community" chip posts `tag=community`, another PSEUDO-tag no
 * room carries. It means "made by a player", which here is every room whose creator
 * isn't the Coach account — the system account that owns the seeded Rec Room rooms.
 * Unlike {@link NEW_TAG} it only filters: the page keeps the feed's normal
 * live-population ordering.
 *
 * The chip reaches {@link searchRooms} too, as the tag term `#community` — the search box
 * carries the same word — so both feeds have to know it names no tag.
 */
const COMMUNITY_TAG = 'community'

/** The system account (`Coach`) that owns the seeded first-party rooms. */
const COACH_ACCOUNT_ID = 1

/**
 * True if the room is a Rec Room Original. `IsRRO` is the flag the client renders a
 * virtual "RRO" tag from; the auto-derived `rro` tag is checked too so a room that only
 * carries the tag isn't mistaken for player-made. The tag is checked by id against
 * `rroTagged` ({@link roomIdsWithTag}) rather than off the room, so a caller ranking tagless
 * stubs needn't load every room's tags to ask.
 */
function isRRO(room: Room, rroTagged: Set<number>): boolean {
	return room.IsRRO === true || rroTagged.has(roomIdOf(room))
}

/**
 * True when the room may appear in a browse or discovery feed at all: public, not a dorm,
 * and not opted out of lists. Every feed below starts from this, so a room that opts out
 * cannot come back through a row that forgot to check.
 */
function isListable(room: Room): boolean {
	return room.IsDorm !== true && room.Accessibility === 1 && room.ExcludeFromLists !== true
}

/**
 * True when the room may come back from a SEARCH: public, not a dorm, and not opted out of
 * search. The search-side twin of {@link isListable} — `ExcludeFromSearch` is its own flag,
 * so neither test implies the other; see {@link SEARCHABLE_WHERE}.
 */
function isSearchable(room: Room): boolean {
	return room.IsDorm !== true && room.Accessibility === 1 && room.ExcludeFromSearch !== true
}

/**
 * True when the room is a PLAYER's rather than one of this server's stock ones — the same
 * test {@link COMMUNITY_TAG} applies, since the Coach account owns every seeded room.
 *
 * A different question from {@link isRRO}, which asks whether a room is a Rec Room
 * Original. The two agree on the data as it stands (every seeded room is Coach-owned AND
 * flagged `rro`), but the discovery rows ask this one: a stock room that was never flagged
 * still isn't something a player built.
 */
function isPlayerMade(room: Room): boolean {
	return room.CreatorAccountId !== COACH_ACCOUNT_ID
}

/** A room's CreatedAt as epoch millis; 0 (i.e. oldest) when it's missing or unparseable. */
function createdAt(room: Room): number {
	const ts = typeof room.CreatedAt === 'string' ? Date.parse(room.CreatedAt) : NaN
	return Number.isNaN(ts) ? 0 : ts
}

/**
 * The "hot" rooms feed: public, non-dorm rooms not excluded from lists, ordered
 * by how many players are in them RIGHT NOW (live presence summed across the
 * room's instances), and optionally filtered to a single `tag` (with the same
 * aliases as search). "Hot" is a live-population feed, so current players lead;
 * rooms nobody is in — and the all-zero seed data — fall back to the stored
 * engagement score, then to RoomId order so paging stays stable. Paginated via
 * skip/take; returns `{ Results, TotalResults }` like search. The listable filter runs in
 * SQL ({@link LISTABLE_WHERE}); the ranking is in memory.
 *
 * `tag=new` and `tag=community` are the filters that aren't tag lookups — see
 * {@link NEW_TAG} and {@link COMMUNITY_TAG}.
 */
export async function getHotRooms(
	db: D1Database,
	tag: string,
	skip: number,
	take: number
): Promise<{ Results: Room[]; TotalResults: number }> {
	const t = tag.trim().toLowerCase()

	// A REAL tag narrows in SQL — this is the query `room_tag` exists for, and the one a
	// discovery category row runs: only the rooms carrying the tag have their blobs read.
	// The two pseudo-tags below name no tag at all, so they still scan.
	const isPseudo = t === '' || t === NEW_TAG || t === COMMUNITY_TAG
	const { sql, binds } = roomsByTagsQuery(
		isPseudo ? [] : [[t, ...(TAG_ALIASES[t] ?? [])]],
		LISTABLE_WHERE,
		RANK_COLUMNS,
		DERIVED_ONLY_FEED_TAGS
	)
	const { results } = await db
		.prepare(sql)
		.bind(...binds)
		.all<RoomRow>()
	// No tags on the stubs: nothing below ranks on them, and the served page gets its own
	// from `hydrateRooms`. Attaching them here read ALL of `room_tag` on every call once a
	// feed had more than a hundred candidates, which every pseudo-tag feed does.
	let rooms = parseAll(results).filter(isListable)

	if (t === NEW_TAG) {
		// Newest player-made rooms first; RoomId (which is minted in creation order)
		// breaks ties so rooms created in the same instant still page stably.
		const rroTagged = await roomIdsWithTag(db, 'rro')
		const fresh = rooms
			.filter((r) => !isRRO(r, rroTagged))
			.sort((a, b) => createdAt(b) - createdAt(a) || roomIdOf(b) - roomIdOf(a))
		return {
			Results: await hydrateRooms(db, await loadRankedPage(db, fresh.slice(skip, skip + take))),
			TotalResults: fresh.length,
		}
	}

	// `community` is a pseudo-tag: it filters on who MADE the room rather than on any tag,
	// so it can't be pushed into the tag query above. A real tag already narrowed there.
	if (t === COMMUNITY_TAG) {
		rooms = rooms.filter((r) => r.CreatorAccountId !== COACH_ACCOUNT_ID)
	}

	const players = await countPlayersByRoom(db)
	const playerCount = (r: Room): number => players.get(roomIdOf(r)) ?? 0
	rooms.sort(
		(a, b) =>
			playerCount(b) - playerCount(a) || hotScore(b) - hotScore(a) || roomIdOf(a) - roomIdOf(b)
	)
	return {
		Results: await hydrateRooms(db, await loadRankedPage(db, rooms.slice(skip, skip + take))),
		TotalResults: rooms.length,
	}
}

/**
 * When each room's live scene was last PUBLISHED, as epoch millis keyed by RoomId: the
 * newest `CurrentSave.CreatedAt` across the room's subrooms.
 *
 * Published, not merely saved. A staged save bumps the subroom's `DataSavedAt` but changes
 * nothing anyone else can load, so ordering by that would float rooms whose visible content
 * never moved — only `current_save_id`, what the loader actually serves, counts here.
 *
 * A room with no published save is ABSENT from the map rather than mapped to 0, so the
 * caller can tell "never published" from "published at the epoch" and choose its own
 * fallback.
 *
 * LISTABLE rooms only — the one caller ranks nothing else. Driven from `room` so the walk
 * starts on `idx_room_public` and reaches only those rooms' subrooms (`idx_subroom_room`).
 * Starting from `subroom` instead scans the whole table, and most of it is dorms: one per
 * account, each costing a read past its subroom blob plus a save lookup and JSON parse,
 * all for rows the caller then throws away.
 *
 * The join order is FORCED (`CROSS JOIN` pins it in SQLite; `INDEXED BY` pins the indexes).
 * Merely listing `room` first is not enough: the planner reorders a plain JOIN, and it
 * chose to scan `subroom` anyway and look each room up last — every dorm's subroom, save
 * and room blob read to keep a tenth of them (132,690 rows and 450-1500ms on production,
 * against 13,332 rows and ~48ms in this order).
 */
async function lastPublishedAtByRoom(db: D1Database): Promise<Map<number, number>> {
	// `json_extract` rather than parsing the row: only the save's timestamp is wanted, so
	// the rest of the save record never has to cross the wire.
	const { results } = await db
		.prepare(
			`SELECT s.room_id AS room_id, json_extract(sv.data, '$.CreatedAt') AS created_at
			 FROM room r INDEXED BY idx_room_public
			 CROSS JOIN subroom s INDEXED BY idx_subroom_room ON s.room_id = r.room_id
			 CROSS JOIN subroom_save sv ON sv.sub_room_data_save_id = s.current_save_id
			 WHERE ${LISTABLE_WHERE}`
		)
		.all<{ room_id: number; created_at: string | null }>()

	const latest = new Map<number, number>()
	for (const row of results) {
		const ts = typeof row.created_at === 'string' ? Date.parse(row.created_at) : NaN
		if (Number.isNaN(ts)) continue
		const seen = latest.get(row.room_id)
		if (seen === undefined || ts > seen) latest.set(row.room_id, ts)
	}
	return latest
}

/**
 * The "recently updated" discovery row: listable, player-made rooms ordered by when their
 * live scene was last PUBLISHED, newest first.
 *
 * The Coach account's rooms are left out for the reason {@link COMMUNITY_TAG} leaves them
 * out — they are this server's stock rooms, and a row about what people have been building
 * should not be a row about the seed data.
 *
 * A room that has never published a save falls back to its own `CreatedAt`: creating a room
 * IS its first update, and on a fresh server that is the only timestamp any room has, so
 * dropping them would leave the row empty. RoomId — minted in creation order — breaks ties
 * newest-first so paging stays stable.
 *
 * Paginated via skip/take, `{ Results, TotalResults }` like the hot feed. The listable
 * filter runs in SQL ({@link LISTABLE_WHERE}); the ranking is in memory.
 */
export async function getRecentlyUpdatedRooms(
	db: D1Database,
	skip: number,
	take: number
): Promise<{ Results: Room[]; TotalResults: number }> {
	const { results } = await db
		.prepare(`SELECT ${RANK_COLUMNS} FROM room WHERE ${LISTABLE_WHERE}`)
		.all<RoomRow>()
	const rooms = parseAll(results).filter((r) => isListable(r) && isPlayerMade(r))

	const published = await lastPublishedAtByRoom(db)
	const updatedAt = (r: Room): number => published.get(roomIdOf(r)) ?? createdAt(r)
	rooms.sort((a, b) => updatedAt(b) - updatedAt(a) || roomIdOf(b) - roomIdOf(a))

	return {
		Results: await hydrateRooms(db, await loadRankedPage(db, rooms.slice(skip, skip + take))),
		TotalResults: rooms.length,
	}
}

/**
 * The "new" discovery row: listable, player-made rooms newest FIRST by creation time.
 *
 * Close to the browse screen's `tag=new` chip (see {@link NEW_TAG}) but not the same test:
 * the chip drops Rec Room Originals, this drops the Coach account's rooms. Both mean
 * "player-made" and agree on the data as it stands — the discovery rows deliberately all
 * use ownership ({@link isPlayerMade}) so one row cannot include a room its sibling row
 * excludes.
 *
 * Paginated via skip/take, `{ Results, TotalResults }` like the hot feed. RoomId breaks
 * ties, newest first, so rooms created in the same instant still page stably.
 */
export async function getNewRooms(
	db: D1Database,
	skip: number,
	take: number
): Promise<{ Results: Room[]; TotalResults: number }> {
	const { results } = await db
		.prepare(`SELECT ${RANK_COLUMNS} FROM room WHERE ${LISTABLE_WHERE}`)
		.all<RoomRow>()
	const rooms = parseAll(results)
		.filter((r) => isListable(r) && isPlayerMade(r))
		.sort((a, b) => createdAt(b) - createdAt(a) || roomIdOf(b) - roomIdOf(a))

	return {
		Results: await hydrateRooms(db, await loadRankedPage(db, rooms.slice(skip, skip + take))),
		TotalResults: rooms.length,
	}
}

/**
 * Recommended rooms feed: public, non-dorm rooms not excluded from lists, ranked
 * by engagement (same score as the hot feed). Unlike the hot feed this returns a
 * bare array — the client's recommendation room-source loader expects a plain
 * list, like the other `*by/me`/base sources. The `splitTest*` A/B params the
 * client passes don't change the result. Paginated via skip/take; the listable filter runs
 * in SQL ({@link LISTABLE_WHERE}); the ranking is in memory.
 */
export async function getRecommendedRooms(
	db: D1Database,
	skip: number,
	take: number
): Promise<Room[]> {
	const { results } = await db
		.prepare(`SELECT ${RANK_COLUMNS} FROM room WHERE ${LISTABLE_WHERE}`)
		.all<RoomRow>()
	const page = parseAll(results)
		.filter(isListable)
		.sort((a, b) => hotScore(b) - hotScore(a) || roomIdOf(a) - roomIdOf(b))
		.slice(skip, skip + take)
	return hydrateRooms(db, await loadRankedPage(db, page))
}

/**
 * Trending ("rising") rooms — the listable rooms someone is standing in RIGHT NOW, busiest
 * first. What the `rising` carousel is filled from.
 *
 * This is the one feed where live presence FILTERS rather than merely ranks: the hot feed
 * sorts by head-count but still lists the empty rooms underneath it, and a carousel of
 * rooms nobody is in is not trending. So a quiet server serves an EMPTY carousel rather
 * than falling back to stored engagement — a room with no one in it has not risen.
 *
 * Ties break the way the hot feed's do (stored engagement, then RoomId), so equally busy
 * rooms page stably.
 */
export async function getTrendingRooms(
	db: D1Database,
	skip: number,
	take: number
): Promise<{ Results: Room[]; TotalResults: number }> {
	const players = await countPlayersByRoom(db)
	// Nobody anywhere: nothing can be trending, and the room table needn't be read at all.
	if (players.size === 0) return { Results: [], TotalResults: 0 }

	const { results } = await db
		.prepare(`SELECT ${RANK_COLUMNS} FROM room WHERE ${LISTABLE_WHERE}`)
		.all<RoomRow>()
	const playerCount = (r: Room): number => players.get(roomIdOf(r)) ?? 0
	const rooms = parseAll(results)
		.filter((r) => isListable(r) && playerCount(r) > 0)
		.sort(
			(a, b) =>
				playerCount(b) - playerCount(a) || hotScore(b) - hotScore(a) || roomIdOf(a) - roomIdOf(b)
		)

	return {
		Results: await hydrateRooms(db, await loadRankedPage(db, rooms.slice(skip, skip + take))),
		TotalResults: rooms.length,
	}
}

/** Compact room projection carried by a featured-room group. */
export interface FeaturedRoom {
	RoomId: number
	RoomName: string
	ImageName: string
	IsRecRoomApproved: boolean
	ExcludeFromLists: boolean
	ExcludeFromSearch: boolean
}

/** A time-boxed group of featured rooms, as returned by `/featuredrooms/current`. */
export interface FeaturedRoomGroup {
	FeaturedRoomGroupId: number
	name: string
	StartAt: string
	EndAt: string
	Rooms: FeaturedRoom[]
}

/** How many rooms one featured group carries. See {@link getFeaturedRooms}. */
export const FEATURED_ROOM_LIMIT = 10

/**
 * Featured rooms group: public, non-dorm rooms not excluded from lists, in random
 * order. There's no editorial curation behind this yet, so "featured" is just a
 * random shuffle of the eligible rooms wrapped in a single always-active group.
 * Eligibility is filtered in SQL ({@link LISTABLE_WHERE}); the rest is in memory.
 *
 * At most {@link FEATURED_ROOM_LIMIT} rooms — a featured group is a short editorial
 * selection, not the whole room list. The cap is applied AFTER the shuffle, so it is a
 * random SAMPLE that varies between requests; a `LIMIT` in the SQL would instead pin the
 * same handful of rooms forever and make the shuffle cosmetic.
 */
export async function getFeaturedRooms(db: D1Database): Promise<FeaturedRoomGroup> {
	const { results } = await db
		.prepare(`SELECT ${RANK_COLUMNS} FROM room WHERE ${LISTABLE_WHERE}`)
		.all<RoomRow>()
	const candidates = parseAll(results).filter(isListable)
	// Fisher–Yates shuffle so the feed varies between requests.
	for (let i = candidates.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1))
		;[candidates[i], candidates[j]] = [candidates[j], candidates[i]]
	}
	candidates.length = Math.min(candidates.length, FEATURED_ROOM_LIMIT)
	// The stubs carry none of the fields the group shows, so the sample is read in full.
	const rooms = await loadRankedPage(db, candidates)

	const str = (v: unknown): string => (typeof v === 'string' ? v : '')
	const num = (v: unknown): number => (typeof v === 'number' ? v : 0)
	return {
		FeaturedRoomGroupId: 1,
		name: 'Featured Rooms',
		StartAt: '2025-12-01T11:01:00Z',
		EndAt: '9999-12-08T11:00:00Z',
		Rooms: rooms.map((r) => ({
			RoomId: num(r.RoomId),
			RoomName: str(r.Name),
			ImageName: str(r.ImageName),
			IsRecRoomApproved: r.IsRecRoomApproved === true,
			ExcludeFromLists: r.ExcludeFromLists === true,
			ExcludeFromSearch: r.ExcludeFromSearch === true,
		})),
	}
}

/**
 * Rooms similar to a target room: public, non-dorm rooms (excluding the target)
 * that share at least one non-system tag with it, ranked by shared-tag count then
 * engagement. Returns a paginated `{ Results, TotalResults }` (the client's
 * RoomSimilarity source expects an object, not a bare array); empty if the target
 * isn't in D1 or carries no tag but system ones. Eligibility is filtered in SQL ({@link LISTABLE_WHERE}); the
 * tag ranking is in memory.
 */
export async function getSimilarRooms(
	db: D1Database,
	roomId: number,
	skip: number,
	take: number
): Promise<{ Results: Room[]; TotalResults: number }> {
	const empty = { Results: [] as Room[], TotalResults: 0 }
	const target = await getRoomById(db, roomId)
	if (!target) return empty
	// SYSTEM tags (`Type` 1: `limitsv2`, `beta`) say nothing about what a room is LIKE — the
	// client stamps them on thousands of rooms to describe the build they were made with —
	// so they are left out on both sides: off the target's list here, and off the matched
	// rows in the query (a player can type `beta` as a user tag, and that must not match
	// every room carrying the system one). A room with only system tags has no similar rooms.
	const targetTags = new Set(
		(Array.isArray(target.Tags) ? (target.Tags as RoomTag[]) : [])
			.filter((t) => typeof t?.Tag === 'string' && t.Type !== RoomTagType.auto)
			.map((t) => t.Tag.toLowerCase())
	)
	if (targetTags.size === 0) return empty

	// Ranking is by SHARED TAG COUNT, which `room_tag` answers on its own: the tag index
	// finds the rows carrying any of the target's tags, and counting them per room is the
	// shared count (the key is (room_id, tag), so a room can't count a tag twice). Only rooms
	// sharing a tag are read at all. This used to read every listable room AND every tag in
	// the table to work the same thing out in memory. The tags go in as one JSON array, so
	// a heavily tagged room can't hit D1's bound-parameter cap.
	//
	// `INDEXED BY idx_room_public` is load-bearing. Left to itself the planner joins through
	// `idx_rooms_room_id`, which fetches the row — and parses the blob — of EVERY room sharing
	// a tag before the listable filter throws it out. The system tags (`limitsv2`, `beta`) sit
	// on thousands of private rooms, so that was ~9,300 rows fetched to serve ~1,000. The
	// partial index holds only public non-dorm rooms, so the rest are rejected in the index:
	// ~90ms to ~22ms on production, same rows.
	const { results } = await db
		.prepare(
			`SELECT ${RANK_COLUMNS}, s.shared AS shared FROM room r INDEXED BY idx_room_public
			 JOIN (SELECT room_id, COUNT(*) AS shared FROM room_tag
			       WHERE tag IN (SELECT value FROM json_each(?1)) AND type != ${RoomTagType.auto}
			       GROUP BY room_id) s
			   ON s.room_id = r.room_id
			 WHERE ${LISTABLE_WHERE} AND r.room_id != ?2`
		)
		.bind(JSON.stringify([...targetTags]), roomId)
		.all<RoomRow & { shared: number }>()

	const scored = results
		.map((row) => ({ room: parseRow(row), shared: row.shared }))
		.filter((x) => isListable(x.room))

	scored.sort(
		(a, b) =>
			b.shared - a.shared ||
			hotScore(b.room) - hotScore(a.room) ||
			roomIdOf(a.room) - roomIdOf(b.room)
	)
	const rooms = scored.map((x) => x.room)
	return {
		Results: await hydrateRooms(db, await loadRankedPage(db, rooms.slice(skip, skip + take))),
		TotalResults: rooms.length,
	}
}

/**
 * "Base" rooms — the template rooms tagged `base` that the client offers as
 * starting points when creating a room. Unlike the public feeds these are
 * returned regardless of accessibility (most base rooms aren't publicly listed).
 * Ordered by RoomId for stable paging. Paginated via skip/take; returns a bare
 * array. Small dataset, so done in memory.
 */
export async function getBaseRooms(db: D1Database, skip: number, take: number): Promise<Room[]> {
	// Selected in SQL off the tag index — a handful of rooms out of the whole table, so this
	// is the clearest case for narrowing before the blobs are read.
	const { sql, binds } = roomsByTagsQuery([['base']])
	const { results } = await db
		.prepare(sql)
		.bind(...binds)
		.all<RoomRow>()
	return hydrateRooms(
		db,
		parseAll(results)
			.sort((a, b) => roomIdOf(a) - roomIdOf(b))
			.slice(skip, skip + take)
	)
}

/** The seeded template dorm (RoomId 1) that personal dorms are cloned from. */
const DORM_TEMPLATE_ROOM_ID = 1

/** A player's username from the shared accounts table (for naming their dorm), or null. */
export async function getUsername(db: D1Database, accountId: number): Promise<string | null> {
	const row = await db
		.prepare('SELECT data FROM account WHERE account_id = ?1')
		.bind(accountId)
		.first<{ data: string }>()
	if (!row) return null
	const account = JSON.parse(row.data) as { username?: string }
	return typeof account.username === 'string' ? account.username : null
}

/**
 * A player's personal dorm room (owned by them, IsDorm), or null if none yet. A player can
 * own several dorms (cloning one keeps `IsDorm`), so this is the OLDEST — the one
 * provisioned for them — never a custom dorm cloned later.
 */
export async function getDormRoom(db: D1Database, accountId: number): Promise<Room | null> {
	return hydrateRoom(
		db,
		parseOne(
			await db
				.prepare(
					`SELECT ${ROOM_COLUMNS} FROM room
					 WHERE creator_account_id = ?1 AND is_dorm = 1
					 ORDER BY room_id LIMIT 1`
				)
				.bind(accountId)
				.first<RoomRow>()
		)
	)
}

/**
 * Blank the scene on a player's dorm by publishing a NEW save with an empty `DataBlob` (and a
 * null `DataBlobHash`) on top of the dorm's most recent one. A dorm saved by a newer client
 * won't load in the 2023 one, and this puts it back to the empty dorm. Nothing is erased: the
 * new save copies every other field of the newest one, and that save stays in the history, so
 * `publish_save` with `previousSaveId` restores the dorm as it was.
 *
 * Dorms always publish, so the newest save is the one `CurrentSave` serves, and the new save
 * goes live the same way — `current_save_id`, with any staged save dropped.
 *
 * The dorm cleared is the one the player plays in: the dorm they picked through `rooms`
 * `PUT /dormroom/me` while it is still theirs (see {@link getPickedDormRoom}), otherwise their
 * provisioned (oldest) dorm. Nothing is provisioned here.
 *
 * Null when the player has no dorm. `previousSaveId` is the newest save beforehand (null when
 * the dorm has never been saved); `saveId` is the blank save made here, null when there was
 * no blob to clear and so nothing was written.
 */
export async function clearDormSaveBlob(
	db: D1Database,
	settings: KVNamespace,
	accountId: number
): Promise<{ roomId: number; previousSaveId: number | null; saveId: number | null } | null> {
	const picked = await getPickedDormRoom(db, settings, accountId)
	const dorm = picked
		? { room_id: Number(picked.RoomId) }
		: await db
				.prepare(
					// The oldest dorm, as `getDormRoom` picks it — not a custom dorm cloned later.
					'SELECT room_id FROM room WHERE creator_account_id = ?1 AND is_dorm = 1 ORDER BY room_id LIMIT 1'
				)
				.bind(accountId)
				.first<{ room_id: number }>()
	if (!dorm) return null

	const latest = await db
		.prepare(
			`SELECT s.sub_room_data_save_id AS id, s.sub_room_id AS subRoomId,
			        json_extract(s.data, '$.DataBlob') AS blob
			   FROM subroom_save s JOIN subroom r ON r.sub_room_id = s.sub_room_id
			  WHERE r.room_id = ?1
			  ORDER BY s.sub_room_data_save_id DESC LIMIT 1`
		)
		.bind(dorm.room_id)
		.first<{ id: number; subRoomId: number; blob: string | null }>()
	if (!latest || !latest.blob) {
		return { roomId: dorm.room_id, previousSaveId: latest?.id ?? null, saveId: null }
	}

	const save = await db
		.prepare(
			`INSERT INTO subroom_save (sub_room_id, data)
			 SELECT sub_room_id, json_set(data, '$.DataBlob', '', '$.DataBlobHash', NULL,
			                              '$.Description', 'Cleared by staff', '$.CreatedAt', ?2)
			   FROM subroom_save WHERE sub_room_data_save_id = ?1
			 RETURNING sub_room_data_save_id AS id`
		)
		.bind(latest.id, new Date().toISOString())
		.first<{ id: number }>()
	if (!save) return { roomId: dorm.room_id, previousSaveId: latest.id, saveId: null }
	await db
		.prepare(
			'UPDATE subroom SET current_save_id = ?2, staged_save_id = NULL WHERE sub_room_id = ?1'
		)
		.bind(latest.subRoomId, save.id)
		.run()
	return { roomId: dorm.room_id, previousSaveId: latest.id, saveId: save.id }
}

/**
 * The player's personal dorm room, created on first access. Cloned from the
 * seeded template dorm (RoomId 1) but owned by the player and flagged IsDorm — so
 * matchmaking routes them into their own dorm and they can save it via the
 * owner-gated room-save. Idempotent: returns the existing dorm once created.
 *
 * NOTE: this is the one place the match worker writes to the rooms table (the
 * `rooms` worker otherwise owns the schema).
 */
/** The player-settings key holding the dorm the player picked (`rooms` `PUT /dormroom/me`). */
export const DORM_ROOM_SETTING_KEY = 'DormRoomId'

/**
 * Whether the player may call this room their dorm: it is a dorm (`IsDorm` — the provisioned
 * one or a custom dorm cloned from one) and they created or co-own it.
 */
export function isPickableDorm(room: Room | null, accountId: number): room is Room {
	return room !== null && room.IsDorm === true && canManageRoom(room, accountId)
}

/**
 * Whether this is a PLAYER's dorm — a dorm room some player (not the Coach, who owns the
 * template and any stock dorm) created. Dorms are stored Unlisted, but a player's dorm is
 * their own space: `match` `canEnterRoom` admits to it only the people it admits to an
 * unpublished room (owner, role holders, invitees). It is still SERVED to anyone by `rooms`
 * `GET /rooms/:id` — the client needs to resolve the room; it is entering it that is gated.
 */
export function isPlayerDorm(room: Room): boolean {
	return (
		room.IsDorm === true &&
		typeof room.CreatorAccountId === 'number' &&
		room.CreatorAccountId !== COACH_ACCOUNT_ID
	)
}

/**
 * The dorm the player picked through `rooms` `PUT /dormroom/me`, while it is still a dorm
 * they run. Null when they never picked one, or the pick went stale (the room was deleted,
 * or they lost their role on it), or KV is unreachable — every caller has a fallback.
 */
export async function getPickedDormRoom(
	db: D1Database,
	settings: KVNamespace,
	accountId: number
): Promise<Room | null> {
	const stored = await readPlayerSettings(settings, accountId).catch(() => null)
	const picked = Number.parseInt(stored?.[DORM_ROOM_SETTING_KEY] ?? '', 10)
	if (Number.isNaN(picked)) return null
	const room = await getRoomById(db, picked)
	return isPickableDorm(room, accountId) ? room : null
}

/**
 * The player's dorm as everything else sees it — `rooms` `GET /dormroom/me`, `match`
 * `/matchmake/dorm`, and the staff dorm clear alike. The dorm they picked REPLACES their
 * provisioned one (see {@link getPickedDormRoom}); otherwise it is the provisioned dorm,
 * created here on first access, so the player always has a dorm to go to.
 */
export async function getPlayerDormRoom(
	db: D1Database,
	settings: KVNamespace,
	accountId: number
): Promise<Room> {
	return (await getPickedDormRoom(db, settings, accountId)) ?? getOrCreateDormRoom(db, accountId)
}

/**
 * Renomme le dortoir provisionné d'un compte après un changement de pseudo : son nom
 * porte le pseudo du propriétaire (`@<username>'s Dorm`), sinon il reste figé sur
 * l'ancien — c'est ce qui a laissé un dortoir au pseudo de quelqu'un d'autre.
 *
 * Les instances en cours et la présence active portent une COPIE du nom, donc elles
 * suivent dans le même lot. Le filtre `name LIKE '@%'` ne vise que les dortoirs : un nom
 * de chambre saisi par un joueur ne peut pas commencer par `@` (voir validation.ts).
 */
export async function renameDormRoom(
	db: D1Database,
	accountId: number,
	username: string
): Promise<void> {
	const name = `@${username}'s Dorm`
	// Au mieux : un pseudo changé ne doit jamais échouer parce qu'un dortoir n'a pas pu
	// suivre (base sans ces tables, dortoir absent). La mise à jour du compte, elle, est
	// déjà écrite quand on arrive ici.
	try {
		await db.batch([
			db
				.prepare(
					`UPDATE room SET data = json_set(data, '$.Name', ?2)
				  WHERE creator_account_id = ?1 AND is_dorm = 1 AND name LIKE '@%'`
				)
				.bind(accountId, name),
			db
				.prepare(
					`UPDATE room_instance SET data = json_set(data, '$.name', ?2)
				  WHERE json_extract(data, '$.roomId') IN
				        (SELECT room_id FROM room WHERE creator_account_id = ?1 AND is_dorm = 1)`
				)
				.bind(accountId, name),
			db
				.prepare(
					`UPDATE presence SET data = json_set(data, '$.roomInstance.name', ?2)
				  WHERE json_extract(data, '$.accountId') = ?1`
				)
				.bind(accountId, name),
		])
	} catch {
		// Rien à faire : le dortoir sera renommé au prochain démarrage du serveur de jeu
		// (getOrCreateDormRoom) ou par une reprise manuelle.
	}
}

export async function getOrCreateDormRoom(db: D1Database, accountId: number): Promise<Room> {
	const existing = await getDormRoom(db, accountId)
	if (existing) return existing

	const template = await getRoomById(db, DORM_TEMPLATE_ROOM_ID)
	const idRow = await db
		.prepare('SELECT COALESCE(MAX(room_id), 1) + 1 AS next FROM room')
		.first<{ next: number }>()
	const roomId = idRow?.next ?? 2

	// Reuse the template's subroom (scene/capacity), owned by the player, starting
	// from a clean save. Fall back to the base dorm scene if the template is absent.
	const templateSub =
		template && Array.isArray(template.SubRooms) && template.SubRooms.length > 0
			? (template.SubRooms[0] as Record<string, unknown>)
			: { SubRoomId: 1, UnitySceneId: '76d98498-60a1-430c-ab76-b54a29b7a163', MaxPlayers: 4 }

	// Named after the owner: `@<username>'s Dorm` (falls back to the account id).
	const username = (await getUsername(db, accountId)) ?? `Player${accountId}`

	const room: Room = {
		...(template ?? { Accessibility: Accessibility.Unlisted }),
		RoomId: roomId,
		Name: `@${username}'s Dorm`,
		CreatorAccountId: accountId,
		IsDorm: true,
		// The template dorm is Coach's and developer-owned; the player's copy is neither.
		IsDeveloperOwned: false,
		Roles: [
			{
				AccountId: accountId,
				Role: Role.Creator,
				LastChangedByAccountId: null,
				InvitedRole: Role.None,
			},
		],
		// Counters start at zero rather than inheriting the template dorm's (see cloneRoom).
		Stats: storedStats(template?.Stats),
		CreatedAt: new Date().toISOString(),
	}
	// serializeRoom drops any SubRooms carried over from the template; the dorm's own
	// subroom is inserted into the subroom table below with a fresh globally-unique id.
	await db.batch([
		db.prepare('INSERT INTO room (data) VALUES (?1)').bind(serializeRoom(room)),
		...roomRoleWrites(db, roomId, room),
	])
	const subRoom = await insertSubRoom(db, roomId, { ...templateSub, CreatorAccountId: accountId })
	room.SubRooms = [subRoom]
	// The template carries these (it was parsed), but a dorm minted without one wouldn't.
	attachRoomDtoDefaults(room)
	return room
}
